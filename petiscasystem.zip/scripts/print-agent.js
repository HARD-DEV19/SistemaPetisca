const http = require('http');
const fs = require('fs');
const path = require('path');
const { exec } = require('child_process');

const PORT = 17321;

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') {
    res.writeHead(200);
    res.end();
    return;
  }

  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'online' }));
  } else if (req.method === 'GET' && req.url === '/printers') {
    exec('powershell -Command "Get-WmiObject -Query \\"SELECT Name FROM Win32_Printer\\" | Select-Object -ExpandProperty Name"', (error, stdout) => {
      if (error) {
        res.writeHead(500);
        res.end(JSON.stringify({ error: 'Failed to list printers' }));
        return;
      }
      const printers = stdout.split('\n').map(p => p.trim()).filter(p => p);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(printers));
    });
  } else if (req.method === 'POST' && req.url === '/print') {
    let body = '';
    req.on('data', chunk => body += chunk.toString());
    req.on('end', () => {
      try {
        const { printerName, text } = JSON.parse(body);
        if (!printerName || !text) {
          res.writeHead(400);
          res.end(JSON.stringify({ error: 'Missing printerName or text' }));
          return;
        }
        sendToPrinter(text, printerName);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'queued' }));
      } catch (e) {
        res.writeHead(400);
        res.end(JSON.stringify({ error: 'Invalid JSON' }));
      }
    });
  } else {
    res.writeHead(404);
    res.end();
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`================================================`);
  console.log(` AGENTE DE IMPRESSAO LOCAL INICIADO NA PORTA ${PORT}`);
  console.log(`================================================`);
  console.log(` Mantenha esta janela aberta para imprimir.`);
  console.log(` O agente agora e apenas um canal de comunicacao.`);
  console.log(` O sistema web formata e envia os comandos diretos.`);
});

function sendToPrinter(text, printerName) {
  const tempFile = path.join(process.cwd(), `print_${Date.now()}.txt`);
  fs.writeFileSync(tempFile, text, 'utf8');
  
  setTimeout(() => {
    try { fs.unlinkSync(tempFile); } catch(e) {}
  }, 10000);

  const psScript = `
Add-Type -TypeDefinition @"
using System;
using System.Runtime.InteropServices;
public class RawPrinterHelper {
    [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Ansi)]
    public class DOCINFOA {
        [MarshalAs(UnmanagedType.LPStr)] public string pDocName;
        [MarshalAs(UnmanagedType.LPStr)] public string pOutputFile;
        [MarshalAs(UnmanagedType.LPStr)] public string pDataType;
    }
    [DllImport("winspool.Drv", EntryPoint = "OpenPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool OpenPrinter([MarshalAs(UnmanagedType.LPStr)] string szPrinter, out IntPtr hPrinter, IntPtr pd);
    [DllImport("winspool.Drv", EntryPoint = "ClosePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool ClosePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "StartDocPrinterA", SetLastError = true, CharSet = CharSet.Ansi, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartDocPrinter(IntPtr hPrinter, int level, [In, MarshalAs(UnmanagedType.LPStruct)] DOCINFOA di);
    [DllImport("winspool.Drv", EntryPoint = "EndDocPrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndDocPrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "StartPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool StartPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "EndPagePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool EndPagePrinter(IntPtr hPrinter);
    [DllImport("winspool.Drv", EntryPoint = "WritePrinter", SetLastError = true, ExactSpelling = true, CallingConvention = CallingConvention.StdCall)]
    public static extern bool WritePrinter(IntPtr hPrinter, IntPtr pBytes, int dwCount, out int dwWritten);
    public static bool SendBytesToPrinter(string szPrinterName, byte[] pBytes) {
        IntPtr pUnmanagedBytes = new IntPtr(0);
        int nLength = pBytes.Length;
        pUnmanagedBytes = Marshal.AllocCoTaskMem(nLength);
        Marshal.Copy(pBytes, 0, pUnmanagedBytes, nLength);
        bool bSuccess = false;
        IntPtr hPrinter = new IntPtr(0);
        DOCINFOA di = new DOCINFOA();
        di.pDocName = "RAW Document";
        di.pDataType = "RAW";
        if (OpenPrinter(szPrinterName.Normalize(), out hPrinter, IntPtr.Zero)) {
            if (StartDocPrinter(hPrinter, 1, di)) {
                if (StartPagePrinter(hPrinter)) {
                    int dwWritten = 0;
                    bSuccess = WritePrinter(hPrinter, pUnmanagedBytes, nLength, out dwWritten);
                    EndPagePrinter(hPrinter);
                }
                EndDocPrinter(hPrinter);
            }
            ClosePrinter(hPrinter);
        }
        Marshal.FreeCoTaskMem(pUnmanagedBytes);
        return bSuccess;
    }
}
"@
[RawPrinterHelper]::SendBytesToPrinter('${printerName}', [System.IO.File]::ReadAllBytes('${tempFile}'))
  `;

  const psFile = path.join(process.cwd(), `print_${Date.now()}.ps1`);
  fs.writeFileSync(psFile, psScript, 'utf8');

  exec(`powershell -ExecutionPolicy Bypass -File "${psFile}"`, (error) => {
    try { fs.unlinkSync(psFile); } catch(e) {}
    if (error) {
      console.error(`Erro ao imprimir na impressora ${printerName}:`, error);
    } else {
      console.log(`Impresso com sucesso na impressora ${printerName}`);
    }
  });
}
