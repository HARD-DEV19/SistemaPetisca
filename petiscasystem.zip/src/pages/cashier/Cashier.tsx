import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, doc, updateDoc, addDoc, query, where, orderBy, getDocs, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Calculator, CheckCircle, Printer, Clock, ArrowLeft, Trash2, DollarSign, LogOut } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../../contexts/AuthContext';
import { printOrderWithFallback } from '../../lib/print';

export default function Cashier() {
  const { userData } = useAuth();
  const [activeTab, setActiveTab] = useState<'caixa' | 'mesas'>('caixa');
  
  // Caixa State
  const [currentSession, setCurrentSession] = useState<any | null>(null);
  const [movements, setMovements] = useState<any[]>([]);
  const [transactions, setTransactions] = useState<any[]>([]);
  const [initialAmount, setInitialAmount] = useState(0);
  const [movementData, setMovementData] = useState({ type: 'out', amount: 0, reason: '' });
  const [isMovementModalOpen, setIsMovementModalOpen] = useState(false);

  // Mesas State
  const [tables, setTables] = useState<any[]>([]);
  const [selectedTable, setSelectedTable] = useState<any | null>(null);
  const [currentOrder, setCurrentOrder] = useState<any | null>(null);
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [paymentMethod, setPaymentMethod] = useState('credit');
  const [selectedItems, setSelectedItems] = useState<string[]>([]);
  
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = useRef(false);

  // Add Item State
  const [isAddItemModalOpen, setIsAddItemModalOpen] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [selectedCategory, setSelectedCategory] = useState('food');

  // Fetch Products
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  // Fetch Tables
  useEffect(() => {
    const unsubTables = onSnapshot(collection(db, 'tables'), (snapshot) => {
      setTables(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)).sort((a: any, b: any) => a.number - b.number));
    });
    return () => unsubTables();
  }, []);

  // Fetch Current Session
  useEffect(() => {
    const q = query(collection(db, 'cashRegisterSessions'), where('status', '==', 'open'));
    const unsub = onSnapshot(q, (snapshot) => {
      if (!snapshot.empty) {
        setCurrentSession({ id: snapshot.docs[0].id, ...snapshot.docs[0].data() });
      } else {
        setCurrentSession(null);
      }
    });
    return () => unsub();
  }, []);

  // Fetch Movements and Transactions for Current Session
  useEffect(() => {
    if (currentSession) {
      const qMov = query(collection(db, 'cashMovements'), where('sessionId', '==', currentSession.id));
      const unsubMov = onSnapshot(qMov, (snapshot) => {
        setMovements(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });

      // We need to fetch transactions that happened during this session.
      // A simple way is to fetch transactions where createdAt >= session.openedAt
      const qTrans = query(collection(db, 'transactions'), where('createdAt', '>=', currentSession.openedAt));
      const unsubTrans = onSnapshot(qTrans, (snapshot) => {
        setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });

      return () => {
        unsubMov();
        unsubTrans();
      };
    } else {
      setMovements([]);
      setTransactions([]);
    }
  }, [currentSession]);

  const currentTable = tables.find(t => t.id === selectedTable?.id) || null;
  const currentOrderId = currentTable?.currentOrderId;

  useEffect(() => {
    if (currentOrderId) {
      const unsubOrder = onSnapshot(doc(db, 'orders', currentOrderId), (doc) => {
        if (doc.exists()) setCurrentOrder({ id: doc.id, ...doc.data() });
      });
      const q = query(collection(db, 'orderItems'), where('orderId', '==', currentOrderId));
      const unsubItems = onSnapshot(q, (snapshot) => {
        setOrderItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });
      return () => {
        unsubOrder();
        unsubItems();
      };
    } else {
      setCurrentOrder(null);
      setOrderItems([]);
      setSelectedItems([]);
    }
  }, [currentOrderId]);

  // --- CAIXA FUNCTIONS ---
  const handleOpenRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!userData) return;
    try {
      await addDoc(collection(db, 'cashRegisterSessions'), {
        openedAt: new Date().toISOString(),
        openedBy: userData.name,
        initialAmount,
        status: 'open'
      });
      toast.success('Caixa aberto com sucesso!');
    } catch (error) {
      toast.error('Erro ao abrir caixa');
    }
  };

  const handleCloseRegister = async () => {
    if (!currentSession || !userData) return;
    if (confirm('Deseja realmente fechar o caixa? Certifique-se de que os valores conferem.')) {
      try {
        await updateDoc(doc(db, 'cashRegisterSessions', currentSession.id), {
          status: 'closed',
          closedAt: new Date().toISOString(),
          closedBy: userData.name,
          finalAmount: calculateTotalInDrawer()
        });
        toast.success('Caixa fechado com sucesso!');
      } catch (error) {
        toast.error('Erro ao fechar caixa');
      }
    }
  };

  const handleAddMovement = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!currentSession || !userData) return;
    try {
      await addDoc(collection(db, 'cashMovements'), {
        sessionId: currentSession.id,
        type: movementData.type,
        amount: movementData.amount,
        reason: movementData.reason,
        date: new Date().toISOString(),
        performedBy: userData.name
      });
      toast.success('Movimentação registrada!');
      setIsMovementModalOpen(false);
      setMovementData({ type: 'out', amount: 0, reason: '' });
    } catch (error) {
      toast.error('Erro ao registrar movimentação');
    }
  };

  const calculateTotalInDrawer = () => {
    if (!currentSession) return 0;
    let total = currentSession.initialAmount;
    
    // Add cash transactions (sales paid in cash)
    const cashSales = transactions.filter(t => t.paymentMethod === 'cash' && t.status === 'paid');
    total += cashSales.reduce((acc, t) => acc + t.amount, 0);

    // Add/Subtract movements
    movements.forEach(m => {
      if (m.type === 'in') total += m.amount;
      if (m.type === 'out') total -= m.amount;
    });

    return total;
  };

  // --- MESAS FUNCTIONS ---
  const toggleItemSelection = (itemId: string) => {
    setSelectedItems(prev => 
      prev.includes(itemId) ? prev.filter(id => id !== itemId) : [...prev, itemId]
    );
  };

  const selectedTotal = orderItems
    .filter(item => selectedItems.includes(item.id))
    .reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const unpaidTotal = orderItems
    .filter(item => item.status !== 'paid' && item.status !== 'cancelled')
    .reduce((acc, item) => acc + (item.price * item.quantity), 0);

  const handlePrint = (isPreBill = false, itemsToPrint = orderItems, skipSubmittingState = false) => {
    if (!currentOrder || !currentTable || (!skipSubmittingState && isSubmittingRef.current)) return;
    
    if (!skipSubmittingState) {
      isSubmittingRef.current = true;
      setIsSubmitting(true);
    }
    
    try {
      const itemsHtml = itemsToPrint.map(item => `
        <tr>
          <td class="qty">${item.quantity}x</td>
          <td>${item.productName}</td>
          <td class="price">R$ ${(item.price * item.quantity).toFixed(2)}</td>
        </tr>
      `).join('');

      const paymentMethodNames: Record<string, string> = {
        credit: 'Crédito',
        debit: 'Débito',
        pix: 'Pix',
        cash: 'Dinheiro'
      };

      const total = itemsToPrint.reduce((acc, item) => acc + (item.price * item.quantity), 0);
      const taxa = total * 0.1;
      const totalComTaxa = total + taxa;

      const content = `
        <div class="text-center border-b">
          <h2 class="text-xl bold">PETISCA PEIXE</h2>
          <p>${isPreBill ? 'Conferência de Mesa' : 'Cupom Não Fiscal'}</p>
          <p>${new Date().toLocaleString('pt-BR')}</p>
        </div>
        <div class="border-b">
          <p class="bold text-lg">${currentTable.number === 0 ? 'BAR' : `MESA ${currentTable.number}`}</p>
          <p>Pedido #${currentOrder.id.slice(0, 8)}</p>
        </div>
        <div class="border-b">
          <table>
            ${itemsHtml}
          </table>
        </div>
        <div class="flex border-b text-lg bold">
          <span>SUBTOTAL</span>
          <span>R$ ${total.toFixed(2)}</span>
        </div>
        <div class="flex border-b text-lg bold">
          <span>TAXA (10%)</span>
          <span>R$ ${taxa.toFixed(2)}</span>
        </div>
        <div class="flex border-b text-xl bold">
          <span>TOTAL</span>
          <span>R$ ${totalComTaxa.toFixed(2)}</span>
        </div>
        <div class="text-center">
          ${!isPreBill ? `<p>Pagamento: ${paymentMethodNames[paymentMethod] || paymentMethod}</p>` : '<p>Aguardando Pagamento</p>'}
          <p>Obrigado pela preferência!</p>
        </div>
      `;

      const printReq = {
        pedidoId: currentOrder.id.slice(0, 8),
        itens: itemsToPrint.map(i => ({
          nome: i.productName,
          setor: i.type,
          quantidade: i.quantity,
          preco: i.price,
          observacao: i.notes
        })),
        imprimirCaixa: true,
        tipo: isPreBill ? 'preconta' : 'cupom',
        total: total,
        pagamento: !isPreBill ? (paymentMethodNames[paymentMethod] || paymentMethod) : undefined,
        mesa: currentTable.number === 0 ? 'BAR' : currentTable.number.toString()
      };

      // Create print job for agent
      addDoc(collection(db, 'printJobs'), {
        ...printReq,
        status: 'pending',
        createdAt: new Date().toISOString()
      }).catch(err => console.error('Failed to create print job', err));

      // Also try to print directly with fallback to HTML
      printOrderWithFallback(printReq, content);

      toast.success(isPreBill ? 'Enviando para impressão...' : 'Enviando comprovante...');
    } finally {
      if (!skipSubmittingState) {
        setTimeout(() => {
          isSubmittingRef.current = false;
          setIsSubmitting(false);
        }, 500);
      }
    }
  };

  const handleCloseOrder = async () => {
    if (!currentTable || !currentOrder || isSubmittingRef.current) return;
    if (!currentSession) {
      toast.error('Abra o caixa primeiro para registrar pagamentos.');
      return;
    }
    
    const itemsToPay = selectedItems.length > 0 
      ? orderItems.filter(item => selectedItems.includes(item.id))
      : orderItems.filter(item => item.status !== 'paid' && item.status !== 'cancelled');

    if (itemsToPay.length === 0) {
      toast.error('Selecione itens para pagar');
      return;
    }

    if (confirm('Deseja imprimir o comprovante desta venda?')) {
      handlePrint(false, itemsToPay, true);
    }

    isSubmittingRef.current = true;
    setIsSubmitting(true);
    const totalToPay = itemsToPay.reduce((acc, item) => acc + (item.price * item.quantity), 0);
    const validItemsCount = orderItems.filter(item => item.status !== 'cancelled').length;
    const isPartial = itemsToPay.length < validItemsCount;

    try {
      // 1. Create Transaction
      await addDoc(collection(db, 'transactions'), {
        type: 'receivable',
        amount: totalToPay,
        description: `Venda ${currentTable.number === 0 ? 'Bar' : `Mesa ${currentTable.number}`}${isPartial ? ' (Parcial)' : ''}`,
        status: 'paid',
        dueDate: new Date().toISOString(),
        paidDate: new Date().toISOString(),
        category: 'sales',
        orderId: currentOrder.id,
        paymentMethod,
        createdAt: new Date().toISOString()
      });

      // 2. Handle Items
      for (const item of itemsToPay) {
        await updateDoc(doc(db, 'orderItems', item.id), {
          status: 'paid',
          paidAt: new Date().toISOString()
        });
      }

      // 3. Update Order Total and Status
      const remainingItems = orderItems.filter(item => !itemsToPay.some(i => i.id === item.id) && item.status !== 'paid' && item.status !== 'cancelled');
      
      if (remainingItems.length === 0) {
        await updateDoc(doc(db, 'orders', currentOrder.id), {
          status: 'closed',
          closedAt: new Date().toISOString()
        });

        await updateDoc(doc(db, 'tables', currentTable.id), {
          status: 'free',
          currentOrderId: null
        });
        toast.success('Mesa finalizada com sucesso!');
        setSelectedTable(null);
      } else {
        const currentPaid = currentOrder.paidAmount || 0;
        await updateDoc(doc(db, 'orders', currentOrder.id), {
          paidAmount: currentPaid + totalToPay
        });
        toast.success('Pagamento parcial registrado!');
        setSelectedItems([]);
      }

    } catch (error: any) {
      console.error(error);
      toast.error('Erro ao processar pagamento: ' + (error.message || String(error)));
    } finally {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  const handleCancelItem = async (itemId: string) => {
    if (confirm('Tem certeza que deseja cancelar este item?')) {
      try {
        const itemToCancel = orderItems.find(i => i.id === itemId);
        if (!itemToCancel) return;

        await updateDoc(doc(db, 'orderItems', itemId), {
          status: 'cancelled',
          cancelledAt: new Date().toISOString()
        });

        // Update Order Total
        if (currentOrder) {
          await updateDoc(doc(db, 'orders', currentOrder.id), {
            total: Math.max(0, (currentOrder.total || 0) - (itemToCancel.price * itemToCancel.quantity))
          });
        }

        // Return Stock
        const productRef = doc(db, 'products', itemToCancel.productId);
        const productSnap = await getDoc(productRef);
        
        if (productSnap.exists()) {
          const productData = productSnap.data();
          if (!productData.isComposite) {
            if (productData.stock !== undefined) {
              await updateDoc(productRef, { stock: (productData.stock || 0) + itemToCancel.quantity });
              
              await addDoc(collection(db, 'stockMovements'), {
                productId: itemToCancel.productId,
                productName: itemToCancel.productName,
                type: 'in',
                quantity: itemToCancel.quantity,
                reason: 'adjustment',
                date: new Date().toISOString(),
                orderId: currentOrder?.id
              });
            }
          } else {
            const qRecipe = query(collection(db, 'recipes'), where('productId', '==', itemToCancel.productId));
            const recipeSnap = await getDocs(qRecipe);
            if (!recipeSnap.empty) {
              const recipeData = recipeSnap.docs[0].data();
              if (recipeData.ingredients && Array.isArray(recipeData.ingredients)) {
                for (const ingredient of recipeData.ingredients) {
                  const ingredientRef = doc(db, 'products', ingredient.ingredientId);
                  const ingredientSnap = await getDoc(ingredientRef);
                  if (ingredientSnap.exists()) {
                    const returnQty = ingredient.quantity * itemToCancel.quantity;
                    await updateDoc(ingredientRef, { stock: (ingredientSnap.data().stock || 0) + returnQty });

                    await addDoc(collection(db, 'stockMovements'), {
                      productId: ingredient.ingredientId,
                      productName: ingredientSnap.data().name,
                      type: 'in',
                      quantity: returnQty,
                      reason: 'adjustment',
                      date: new Date().toISOString(),
                      orderId: currentOrder?.id,
                      parentProductId: itemToCancel.productId
                    });
                  }
                }
              }
            }
          }
        }

        toast.success('Item cancelado e estoque retornado');
      } catch (error: any) {
        console.error(error);
        toast.error('Erro ao cancelar item: ' + (error.message || String(error)));
      }
    }
  };

  const handleAddItem = async (product: any) => {
    if (!currentTable || !currentOrder) return;
    try {
      await addDoc(collection(db, 'orderItems'), {
        orderId: currentOrder.id,
        productId: product.id,
        productName: product.name,
        price: product.price,
        quantity: 1,
        status: 'pending',
        type: product.category,
        createdAt: new Date().toISOString()
      });

      // Update Order Total
      await updateDoc(doc(db, 'orders', currentOrder.id), {
        total: (currentOrder.total || 0) + product.price
      });

      // Stock Deduction
      if (!product.isComposite) {
        if (product.stock !== undefined) {
          const productRef = doc(db, 'products', product.id);
          const currentStock = product.stock || 0;
          await updateDoc(productRef, { stock: currentStock - 1 });
          
          await addDoc(collection(db, 'stockMovements'), {
            productId: product.id,
            productName: product.name,
            type: 'out',
            quantity: 1,
            reason: 'sale',
            date: new Date().toISOString(),
            orderId: currentOrder.id
          });
        }
      } else {
        const qRecipe = query(collection(db, 'recipes'), where('productId', '==', product.id));
        const recipeSnap = await getDocs(qRecipe);
        if (!recipeSnap.empty) {
          const recipeData = recipeSnap.docs[0].data();
          if (recipeData.ingredients && Array.isArray(recipeData.ingredients)) {
            for (const ingredient of recipeData.ingredients) {
              const ingredientRef = doc(db, 'products', ingredient.ingredientId);
              const ingredientSnap = await getDoc(ingredientRef);
              if (ingredientSnap.exists()) {
                const currentIngStock = ingredientSnap.data().stock || 0;
                const deduction = ingredient.quantity * 1;
                await updateDoc(ingredientRef, { stock: currentIngStock - deduction });

                await addDoc(collection(db, 'stockMovements'), {
                  productId: ingredient.ingredientId,
                  productName: ingredientSnap.data().name,
                  type: 'out',
                  quantity: deduction,
                  reason: 'sale',
                  date: new Date().toISOString(),
                  orderId: currentOrder.id,
                  parentProductId: product.id
                });
              }
            }
          }
        }
      }

      toast.success(`${product.name} adicionado!`);
    } catch (error) {
      toast.error('Erro ao adicionar item');
    }
  };

  return (
    <div className="flex h-[calc(100vh-4rem)] flex-col bg-stone-100 font-sans">
      {/* Top Navigation */}
      <div className="bg-white border-b border-stone-200 p-4 flex items-center gap-4">
        <button
          onClick={() => setActiveTab('caixa')}
          className={`px-6 py-2 rounded-xl font-bold transition-colors ${activeTab === 'caixa' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'}`}
        >
          Controle de Caixa
        </button>
        <button
          onClick={() => setActiveTab('mesas')}
          className={`px-6 py-2 rounded-xl font-bold transition-colors ${activeTab === 'mesas' ? 'bg-stone-900 text-white' : 'bg-stone-100 text-stone-600 hover:bg-stone-200'}`}
        >
          Mesas e Pedidos
        </button>
      </div>

      {activeTab === 'caixa' && (
        <div className="flex-1 p-4 md:p-8 overflow-y-auto">
          <div className="max-w-4xl mx-auto">
            {!currentSession ? (
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-stone-200 text-center">
                <Calculator size={64} className="mx-auto mb-6 text-stone-300" />
                <h2 className="text-2xl font-bold font-heading mb-2">Caixa Fechado</h2>
                <p className="text-stone-500 mb-8">Abra o caixa para iniciar as operações do turno.</p>
                
                <form onSubmit={handleOpenRegister} className="max-w-xs mx-auto">
                  <div className="mb-4 text-left">
                    <label className="block text-sm font-bold text-stone-700 mb-2">Troco Inicial (R$)</label>
                    <input 
                      type="number" 
                      step="0.01" 
                      required
                      value={initialAmount}
                      onChange={e => setInitialAmount(parseFloat(e.target.value))}
                      className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:ring-2 outline-none"
                    />
                  </div>
                  <button type="submit" className="w-full bg-orange-600 text-white font-bold py-3 rounded-xl hover:bg-orange-700 transition-colors shadow-md">
                    Abrir Caixa
                  </button>
                </form>
              </div>
            ) : (
              <div className="space-y-6">
                <div className="bg-white p-6 rounded-3xl shadow-sm border border-stone-200 flex flex-col md:flex-row justify-between items-center gap-6">
                  <div>
                    <h2 className="text-2xl font-bold font-heading text-stone-900">Caixa Aberto</h2>
                    <p className="text-stone-500 text-sm mt-1">Aberto por {currentSession.openedBy} em {new Date(currentSession.openedAt).toLocaleString('pt-BR')}</p>
                  </div>
                  <div className="text-center md:text-right bg-stone-50 px-6 py-4 rounded-2xl border border-stone-100">
                    <p className="text-sm font-bold text-stone-500 uppercase">Total em Gaveta (Dinheiro)</p>
                    <p className="text-4xl font-bold font-heading text-green-600">R$ {calculateTotalInDrawer().toFixed(2)}</p>
                  </div>
                  <div className="flex gap-3 w-full md:w-auto">
                    <button onClick={() => setIsMovementModalOpen(true)} className="flex-1 md:flex-none bg-stone-100 text-stone-700 font-bold py-3 px-6 rounded-xl hover:bg-stone-200 transition-colors">
                      Sangria / Suprimento
                    </button>
                    <button onClick={handleCloseRegister} className="flex-1 md:flex-none bg-red-600 text-white font-bold py-3 px-6 rounded-xl hover:bg-red-700 transition-colors shadow-md">
                      Fechar Caixa
                    </button>
                  </div>
                </div>

                <div className="bg-white p-6 rounded-3xl shadow-sm border border-stone-200">
                  <h3 className="text-lg font-bold font-heading mb-4">Movimentações do Turno</h3>
                  <div className="overflow-x-auto">
                    <table className="w-full text-left text-sm text-stone-600">
                      <thead className="bg-stone-50 text-xs uppercase font-bold border-b border-stone-200">
                        <tr>
                          <th className="px-4 py-3">Data/Hora</th>
                          <th className="px-4 py-3">Tipo</th>
                          <th className="px-4 py-3">Motivo/Descrição</th>
                          <th className="px-4 py-3">Operador</th>
                          <th className="px-4 py-3 text-right">Valor</th>
                        </tr>
                      </thead>
                      <tbody className="divide-y divide-stone-100">
                        <tr className="hover:bg-stone-50">
                          <td className="px-4 py-3">{new Date(currentSession.openedAt).toLocaleString('pt-BR')}</td>
                          <td className="px-4 py-3"><span className="bg-blue-100 text-blue-700 px-2 py-1 rounded-md text-xs font-bold">Abertura</span></td>
                          <td className="px-4 py-3">Troco Inicial</td>
                          <td className="px-4 py-3">{currentSession.openedBy}</td>
                          <td className="px-4 py-3 text-right font-bold text-blue-600">R$ {currentSession.initialAmount.toFixed(2)}</td>
                        </tr>
                        {movements.map(m => (
                          <tr key={m.id} className="hover:bg-stone-50">
                            <td className="px-4 py-3">{new Date(m.date).toLocaleString('pt-BR')}</td>
                            <td className="px-4 py-3">
                              <span className={`px-2 py-1 rounded-md text-xs font-bold ${m.type === 'in' ? 'bg-green-100 text-green-700' : 'bg-red-100 text-red-700'}`}>
                                {m.type === 'in' ? 'Suprimento' : 'Sangria'}
                              </span>
                            </td>
                            <td className="px-4 py-3">{m.reason}</td>
                            <td className="px-4 py-3">{m.performedBy}</td>
                            <td className={`px-4 py-3 text-right font-bold ${m.type === 'in' ? 'text-green-600' : 'text-red-600'}`}>
                              {m.type === 'in' ? '+' : '-'} R$ {m.amount.toFixed(2)}
                            </td>
                          </tr>
                        ))}
                        {transactions.filter(t => t.paymentMethod === 'cash' && t.status === 'paid').map(t => (
                          <tr key={t.id} className="hover:bg-stone-50">
                            <td className="px-4 py-3">{new Date(t.paidDate).toLocaleString('pt-BR')}</td>
                            <td className="px-4 py-3"><span className="bg-green-100 text-green-700 px-2 py-1 rounded-md text-xs font-bold">Venda (Dinheiro)</span></td>
                            <td className="px-4 py-3">{t.description}</td>
                            <td className="px-4 py-3">-</td>
                            <td className="px-4 py-3 text-right font-bold text-green-600">+ R$ {t.amount.toFixed(2)}</td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      {activeTab === 'mesas' && (
        <div className="flex flex-1 overflow-hidden">
          {/* Tables List */}
          <div className={`${selectedTable ? 'hidden md:block' : 'block'} w-full md:w-1/3 border-r border-stone-200 bg-white p-4 overflow-y-auto`}>
            <div className="space-y-3">
              {tables.filter(t => t.status !== 'free').map(table => (
                <button
                  key={table.id}
                  onClick={() => setSelectedTable(table)}
                  className={`flex w-full items-center justify-between rounded-2xl border p-4 transition-all duration-200 ${
                    selectedTable?.id === table.id 
                      ? 'border-orange-500 bg-orange-50 shadow-md' 
                      : 'border-stone-200 hover:border-orange-300 hover:bg-stone-50'
                  }`}
                >
                  <div className="flex items-center gap-4">
                    <div className={`flex h-12 w-12 items-center justify-center rounded-xl font-bold font-heading text-lg ${
                      table.status === 'billing' ? 'bg-red-100 text-red-600' : 'bg-blue-100 text-blue-600'
                    }`}>
                      {table.number === 0 ? 'B' : table.number}
                    </div>
                    <span className="font-bold text-stone-900">{table.number === 0 ? 'Mesa do Bar' : `Mesa ${table.number}`}</span>
                  </div>
                  {table.status === 'billing' && (
                    <span className="rounded-full bg-red-100 px-3 py-1 text-xs font-bold text-red-600 border border-red-200">Fechando</span>
                  )}
                </button>
              ))}
              {tables.filter(t => t.status !== 'free').length === 0 && (
                <div className="flex flex-col items-center justify-center py-16 text-stone-400">
                  <Calculator size={64} className="mb-4 opacity-20" />
                  <p className="text-center font-medium">Nenhuma mesa ocupada.</p>
                </div>
              )}
            </div>
          </div>

          {/* Order Details */}
          <div className={`${!selectedTable ? 'hidden md:flex' : 'flex'} flex-1 flex-col p-4 overflow-y-auto bg-stone-50/50`}>
            {currentTable && currentOrder ? (
              <div className="mx-auto w-full max-w-3xl rounded-3xl bg-white p-6 shadow-sm border border-stone-200">
                <div className="mb-6 flex items-center justify-between">
                  <button onClick={() => setSelectedTable(null)} className="text-stone-500 font-medium md:hidden flex items-center gap-2">
                    <ArrowLeft size={20} /> Voltar
                  </button>
                  <div className="flex items-center gap-4">
                    <h2 className="text-3xl font-bold font-heading text-stone-900 hidden md:block">
                      {currentTable.number === 0 ? 'Mesa do Bar' : `Mesa ${currentTable.number}`}
                    </h2>
                    <button 
                      onClick={() => setIsAddItemModalOpen(true)}
                      className="bg-stone-200 hover:bg-stone-300 text-stone-700 px-3 py-1.5 rounded-lg text-sm font-bold transition-colors"
                    >
                      + Adicionar Item
                    </button>
                  </div>
                  <div className="text-right bg-stone-50 p-3 rounded-xl border border-stone-100">
                    <p className="text-xs font-bold text-stone-500 uppercase">Total a Pagar</p>
                    <p className="text-3xl font-bold font-heading text-orange-600">R$ {unpaidTotal.toFixed(2)}</p>
                  </div>
                </div>

                <div className="mb-6">
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="text-lg font-bold font-heading text-stone-900">Itens do Pedido</h3>
                    <button 
                      onClick={() => setSelectedItems(selectedItems.length === orderItems.filter(i => i.status !== 'paid' && i.status !== 'cancelled').length ? [] : orderItems.filter(i => i.status !== 'paid' && i.status !== 'cancelled').map(i => i.id))}
                      className="text-sm font-bold text-orange-600 hover:underline"
                    >
                      {selectedItems.length > 0 ? 'Desmarcar todos' : 'Selecionar todos para pagar'}
                    </button>
                  </div>
                  <div className="max-h-64 overflow-y-auto rounded-2xl border border-stone-200 bg-stone-50 p-2">
                    {orderItems.map(item => (
                      <div key={item.id} className={`mb-2 flex items-center justify-between rounded-xl p-3 bg-white border ${selectedItems.includes(item.id) ? 'border-orange-500 shadow-sm' : 'border-stone-200'}`}>
                        <div className="flex items-center gap-3">
                          {item.status !== 'paid' && item.status !== 'cancelled' && (
                            <input 
                              type="checkbox" 
                              checked={selectedItems.includes(item.id)}
                              onChange={() => toggleItemSelection(item.id)}
                              className="w-5 h-5 rounded border-stone-300 text-orange-600 focus:ring-orange-500"
                            />
                          )}
                          <div>
                            <span className={`font-bold ${item.status === 'cancelled' ? 'line-through text-stone-400' : 'text-stone-900'}`}>
                              {item.quantity}x {item.productName}
                            </span>
                            <div className="flex gap-2 mt-1">
                              <span className="text-xs font-bold text-stone-500 bg-stone-100 px-2 py-0.5 rounded">
                                {item.status === 'paid' ? 'Pago' : item.status === 'cancelled' ? 'Cancelado' : 'Pendente'}
                              </span>
                            </div>
                          </div>
                        </div>
                        <div className="flex items-center gap-4">
                          <span className={`font-bold ${item.status === 'cancelled' ? 'text-stone-400' : 'text-stone-900'}`}>
                            R$ {(item.price * item.quantity).toFixed(2)}
                          </span>
                          {item.status !== 'paid' && item.status !== 'cancelled' && (
                            <button onClick={() => handleCancelItem(item.id)} className="text-red-500 hover:text-red-700 p-1">
                              <Trash2 size={18} />
                            </button>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                <div className="mb-6">
                  <h3 className="text-lg font-bold font-heading text-stone-900 mb-3">Forma de Pagamento</h3>
                  <div className="grid grid-cols-2 sm:grid-cols-4 gap-3">
                    {['credit', 'debit', 'pix', 'cash'].map(method => (
                      <button
                        key={method}
                        onClick={() => setPaymentMethod(method)}
                        className={`rounded-xl border-2 p-3 text-sm font-bold capitalize transition-all ${
                          paymentMethod === method 
                            ? 'border-orange-500 bg-orange-50 text-orange-700' 
                            : 'border-stone-200 text-stone-600 hover:bg-stone-50'
                        }`}
                      >
                        {method === 'credit' ? 'Crédito' : method === 'debit' ? 'Débito' : method === 'pix' ? 'Pix' : 'Dinheiro'}
                      </button>
                    ))}
                  </div>
                </div>

                <div className="flex gap-3">
                  <button
                    onClick={() => handlePrint(true)}
                    className="flex-1 flex items-center justify-center gap-2 rounded-xl border-2 border-stone-200 bg-white py-3 font-bold text-stone-700 hover:bg-stone-50"
                  >
                    <Printer size={20} /> Pré-conta
                  </button>
                  <button
                    onClick={handleCloseOrder}
                    disabled={isSubmitting || selectedItems.length === 0}
                    className="flex-[2] flex items-center justify-center gap-2 rounded-xl bg-orange-600 py-3 font-bold text-white hover:bg-orange-700 disabled:opacity-50"
                  >
                    <CheckCircle size={20} /> Pagar Selecionados (R$ {selectedTotal.toFixed(2)})
                  </button>
                </div>
              </div>
            ) : (
              <div className="flex h-full flex-col items-center justify-center text-stone-400">
                <Calculator size={80} className="mb-6 opacity-20" />
                <p className="text-2xl font-bold font-heading text-center text-stone-500">Selecione uma mesa</p>
              </div>
            )}
          </div>
        </div>
      )}

      {/* Movement Modal */}
      {isMovementModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-stone-200">
            <h2 className="mb-6 text-2xl font-bold font-heading text-stone-900">Sangria / Suprimento</h2>
            <form onSubmit={handleAddMovement} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Tipo de Movimentação</label>
                <div className="grid grid-cols-2 gap-3">
                  <button type="button" onClick={() => setMovementData({...movementData, type: 'out'})} className={`py-3 rounded-xl font-bold border-2 ${movementData.type === 'out' ? 'border-red-500 bg-red-50 text-red-700' : 'border-stone-200 text-stone-500'}`}>Sangria (Retirada)</button>
                  <button type="button" onClick={() => setMovementData({...movementData, type: 'in'})} className={`py-3 rounded-xl font-bold border-2 ${movementData.type === 'in' ? 'border-green-500 bg-green-50 text-green-700' : 'border-stone-200 text-stone-500'}`}>Suprimento (Entrada)</button>
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Valor (R$)</label>
                <input required type="number" step="0.01" value={movementData.amount || ''} onChange={e => setMovementData({...movementData, amount: parseFloat(e.target.value)})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 outline-none" />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Motivo / Descrição</label>
                <input required type="text" value={movementData.reason} onChange={e => setMovementData({...movementData, reason: e.target.value})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 outline-none" />
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsMovementModalOpen(false)} className="rounded-xl px-5 py-2.5 font-bold text-stone-600 hover:bg-stone-100">Cancelar</button>
                <button type="submit" className="rounded-xl bg-stone-900 px-5 py-2.5 font-bold text-white hover:bg-stone-800">Confirmar</button>
              </div>
            </form>
          </div>
        </div>
      )}
      {/* Add Item Modal */}
      {isAddItemModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl rounded-3xl bg-white p-6 shadow-2xl border border-stone-200 flex flex-col max-h-[80vh]">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-2xl font-bold font-heading text-stone-900">Adicionar Item</h2>
              <button onClick={() => setIsAddItemModalOpen(false)} className="text-stone-500 hover:text-stone-700">✕</button>
            </div>
            
            <div className="flex gap-2 mb-4">
              <button 
                onClick={() => setSelectedCategory('food')}
                className={`px-4 py-2 rounded-xl font-bold text-sm ${selectedCategory === 'food' ? 'bg-orange-600 text-white' : 'bg-stone-100 text-stone-600'}`}
              >
                Comidas
              </button>
              <button 
                onClick={() => setSelectedCategory('drink')}
                className={`px-4 py-2 rounded-xl font-bold text-sm ${selectedCategory === 'drink' ? 'bg-orange-600 text-white' : 'bg-stone-100 text-stone-600'}`}
              >
                Bebidas
              </button>
            </div>

            <div className="flex-1 overflow-y-auto grid grid-cols-2 sm:grid-cols-3 gap-3 pr-2">
              {products.filter(p => p.category === selectedCategory).map(product => (
                <button
                  key={product.id}
                  onClick={() => handleAddItem(product)}
                  className="flex flex-col items-start justify-between rounded-2xl border border-stone-200 bg-white p-3 text-left hover:border-orange-500 hover:shadow-md transition-all active:scale-95"
                >
                  <span className="font-bold text-stone-900 line-clamp-2 mb-2">{product.name}</span>
                  <span className="font-bold text-orange-600">R$ {product.price.toFixed(2)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
