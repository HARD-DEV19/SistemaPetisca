import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, LayoutGrid, AlertTriangle } from 'lucide-react';
import { toast } from 'sonner';

export default function Tables() {
  const [tables, setTables] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    number: '',
    status: 'free'
  });

  useEffect(() => {
    const q = query(collection(db, 'tables'), orderBy('number', 'asc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setTables(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const tableNumber = parseInt(formData.number);
      
      if (isNaN(tableNumber)) {
        toast.error('O número da mesa deve ser um valor numérico válido.');
        return;
      }

      const duplicate = tables.find(t => t.number === tableNumber && t.id !== editingId);
      if (duplicate) {
        toast.error('Já existe uma mesa com este número!');
        return;
      }

      if (editingId) {
        await updateDoc(doc(db, 'tables', editingId), { number: tableNumber });
        toast.success('Mesa atualizada!');
      } else {
        await addDoc(collection(db, 'tables'), {
          number: tableNumber,
          status: 'free',
          createdAt: new Date().toISOString()
        });
        toast.success('Mesa criada!');
      }

      setIsModalOpen(false);
      setEditingId(null);
      setFormData({ number: '', status: 'free' });
    } catch (error) {
      console.error(error);
      toast.error('Erro ao salvar mesa');
    }
  };

  const handleEdit = (table: any) => {
    setFormData({
      number: table.number.toString(),
      status: table.status
    });
    setEditingId(table.id);
    setIsModalOpen(true);
  };

  const handleDelete = async (table: any) => {
    if (table.status !== 'free') {
      toast.error('Não é possível excluir uma mesa que não está livre.');
      return;
    }
    
    if (confirm(`Tem certeza que deseja excluir a mesa ${table.number}?`)) {
      try {
        await deleteDoc(doc(db, 'tables', table.id));
        toast.success('Mesa excluída');
      } catch (error) {
        toast.error('Erro ao excluir mesa');
      }
    }
  };

  const generateBulkTables = async () => {
    if (confirm('Deseja gerar 10 mesas automaticamente? Isso não apagará as existentes.')) {
      try {
        const currentMax = tables.length > 0 ? Math.max(...tables.map(t => t.number)) : 0;
        for (let i = 1; i <= 10; i++) {
          await addDoc(collection(db, 'tables'), {
            number: currentMax + i,
            status: 'free',
            createdAt: new Date().toISOString()
          });
        }
        toast.success('10 mesas geradas com sucesso!');
      } catch (error) {
        toast.error('Erro ao gerar mesas');
      }
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading tracking-tight text-stone-900 flex items-center gap-2">
            <LayoutGrid className="text-orange-600" /> Gestão de Mesas
          </h1>
          <p className="text-stone-500 mt-1">Cadastre e gerencie as mesas do salão.</p>
        </div>
        <div className="flex gap-2">
          <button
            onClick={generateBulkTables}
            className="flex items-center justify-center gap-2 rounded-xl border border-stone-300 bg-white px-4 py-2.5 text-sm font-bold text-stone-700 hover:bg-stone-50 transition-all active:scale-95"
          >
            Gerar 10 Mesas
          </button>
          <button
            onClick={() => {
              setFormData({ number: '', status: 'free' });
              setEditingId(null);
              setIsModalOpen(true);
            }}
            className="flex items-center justify-center gap-2 rounded-xl bg-orange-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-orange-700 shadow-md shadow-orange-600/20 transition-all active:scale-95"
          >
            <Plus size={18} />
            Nova Mesa
          </button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {tables.map((table) => (
          <div key={table.id} className="relative group rounded-2xl border border-stone-200 bg-white p-4 shadow-sm hover:border-orange-500 hover:shadow-md transition-all flex flex-col items-center justify-center aspect-square">
            <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
              <button onClick={() => handleEdit(table)} className="p-1.5 bg-blue-50 text-blue-600 rounded-lg hover:bg-blue-100">
                <Edit size={14} />
              </button>
              <button onClick={() => handleDelete(table)} className="p-1.5 bg-red-50 text-red-600 rounded-lg hover:bg-red-100">
                <Trash2 size={14} />
              </button>
            </div>
            
            <span className="text-4xl font-bold font-heading text-stone-900 mb-2">{table.number}</span>
            
            <span className={`px-2.5 py-1 rounded-full text-xs font-bold uppercase tracking-wider ${
              table.status === 'free' ? 'bg-green-100 text-green-700' :
              table.status === 'occupied' ? 'bg-blue-100 text-blue-700' :
              table.status === 'billing' ? 'bg-orange-100 text-orange-700' :
              'bg-stone-100 text-stone-700'
            }`}>
              {table.status === 'free' ? 'Livre' :
               table.status === 'occupied' ? 'Ocupada' :
               table.status === 'billing' ? 'Fechando' : table.status}
            </span>
          </div>
        ))}
        {tables.length === 0 && (
          <div className="col-span-full py-12 text-center text-stone-500 bg-stone-50 rounded-2xl border border-dashed border-stone-300">
            <LayoutGrid size={48} className="mx-auto mb-4 text-stone-400 opacity-50" />
            <p className="text-lg font-medium">Nenhuma mesa cadastrada.</p>
            <p className="text-sm mt-1">Clique em "Nova Mesa" ou "Gerar 10 Mesas" para começar.</p>
          </div>
        )}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl border border-stone-200">
            <h2 className="mb-6 text-2xl font-bold font-heading text-stone-900">{editingId ? 'Editar Mesa' : 'Nova Mesa'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Número da Mesa</label>
                <input 
                  required 
                  type="number" 
                  min="0"
                  value={formData.number} 
                  onChange={e => setFormData({...formData, number: e.target.value})} 
                  className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all text-xl font-bold text-center" 
                />
                <p className="text-xs text-stone-500 mt-2 text-center">Use 0 para representar o Balcão/Bar.</p>
              </div>

              {editingId && formData.status !== 'free' && (
                <div className="bg-orange-50 text-orange-800 p-3 rounded-xl flex items-start gap-2 text-sm">
                  <AlertTriangle size={16} className="shrink-0 mt-0.5" />
                  <p>Esta mesa não está livre no momento. Alterar o número pode causar confusão nos pedidos em andamento.</p>
                </div>
              )}

              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="rounded-xl px-5 py-2.5 font-bold text-stone-600 hover:bg-stone-100 transition-colors">Cancelar</button>
                <button type="submit" className="rounded-xl bg-orange-600 px-5 py-2.5 font-bold text-white hover:bg-orange-700 shadow-md shadow-orange-600/20 transition-all active:scale-95">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
