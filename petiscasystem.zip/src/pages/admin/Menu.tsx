import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, where, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, UtensilsCrossed } from 'lucide-react';
import { toast } from 'sonner';

export default function Menu() {
  const [products, setProducts] = useState<any[]>([]);
  const [ingredients, setIngredients] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'food',
    price: 0,
    isComposite: false,
    imageUrl: ''
  });
  const [recipeIngredients, setRecipeIngredients] = useState<any[]>([]);

  useEffect(() => {
    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const allProducts = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setProducts(allProducts.filter(p => p.category === 'food' || p.category === 'drink'));
      setIngredients(allProducts.filter(p => p.category === 'ingredient' || p.category === 'drink'));
    });
    return () => unsubProducts();
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const duplicate = products.find(p => p.name.toLowerCase() === formData.name.toLowerCase() && p.id !== editingId);
      if (duplicate) {
        toast.error('Já existe um prato com este nome!');
        return;
      }

      let productId = editingId;
      if (editingId) {
        await updateDoc(doc(db, 'products', editingId), formData);
        toast.success('Prato atualizado!');
      } else {
        const docRef = await addDoc(collection(db, 'products'), {
          ...formData,
          createdAt: new Date().toISOString()
        });
        productId = docRef.id;
        toast.success('Prato criado!');
      }

      if (formData.isComposite && productId) {
        const recipesQuery = query(collection(db, 'recipes'), where('productId', '==', productId));
        const recipesSnap = await getDocs(recipesQuery);
        
        if (recipesSnap.empty) {
          await addDoc(collection(db, 'recipes'), {
            productId,
            ingredients: recipeIngredients,
            updatedAt: new Date().toISOString()
          });
        } else {
          await updateDoc(doc(db, 'recipes', recipesSnap.docs[0].id), {
            ingredients: recipeIngredients,
            updatedAt: new Date().toISOString()
          });
        }
      }

      setIsModalOpen(false);
      setEditingId(null);
      setRecipeIngredients([]);
      setFormData({ name: '', description: '', category: 'food', price: 0, isComposite: false, imageUrl: '' });
    } catch (error) {
      console.error(error);
      toast.error('Erro ao salvar prato');
    }
  };

  const handleEdit = async (product: any) => {
    setFormData({
      name: product.name || '',
      description: product.description || '',
      category: product.category || 'food',
      price: product.price || 0,
      isComposite: product.isComposite || false,
      imageUrl: product.imageUrl || ''
    });
    setEditingId(product.id);
    if (product.isComposite) {
      const q = query(collection(db, 'recipes'), where('productId', '==', product.id));
      const snap = await getDocs(q);
      if (!snap.empty) {
        setRecipeIngredients(snap.docs[0].data().ingredients || []);
      } else {
        setRecipeIngredients([]);
      }
    } else {
      setRecipeIngredients([]);
    }
    setIsModalOpen(true);
  };

  const addIngredientToRecipe = (ingredientId: string, quantity: number) => {
    const ingredient = ingredients.find(p => p.id === ingredientId);
    if (!ingredient) return;
    setRecipeIngredients(prev => {
      const existing = prev.find(i => i.ingredientId === ingredientId);
      if (existing) {
        return prev.map(i => i.ingredientId === ingredientId ? { ...i, quantity } : i);
      }
      return [...prev, { ingredientId, name: ingredient.name, quantity, unit: ingredient.unit }];
    });
  };

  const removeIngredientFromRecipe = (ingredientId: string) => {
    setRecipeIngredients(prev => prev.filter(i => i.ingredientId !== ingredientId));
  };

  const handleDelete = async (id: string) => {
    if (confirm('Tem certeza que deseja excluir este prato?')) {
      await deleteDoc(doc(db, 'products', id));
      toast.success('Prato excluído');
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading tracking-tight text-stone-900 flex items-center gap-2">
            <UtensilsCrossed className="text-orange-600" /> Cardápio
          </h1>
          <p className="text-stone-500 mt-1">Gerencie os pratos e bebidas servidos aos clientes.</p>
        </div>
        <button
          onClick={() => {
            setFormData({ name: '', description: '', category: 'food', price: 0, isComposite: false, imageUrl: '' });
            setEditingId(null);
            setRecipeIngredients([]);
            setIsModalOpen(true);
          }}
          className="flex items-center justify-center gap-2 rounded-xl bg-orange-600 px-4 py-2.5 text-sm font-bold text-white hover:bg-orange-700 shadow-md shadow-orange-600/20 transition-all active:scale-95"
        >
          <Plus size={18} />
          Novo Item
        </button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-stone-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm text-stone-600">
          <thead className="bg-stone-50 text-xs uppercase tracking-wider text-stone-500 font-bold border-b border-stone-200">
            <tr>
              <th className="px-6 py-4 w-16">Foto</th>
              <th className="px-6 py-4">Nome</th>
              <th className="px-6 py-4">Categoria</th>
              <th className="px-6 py-4">Preço</th>
              <th className="px-6 py-4">Ficha Técnica</th>
              <th className="px-6 py-4 text-right">Ações</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-stone-100">
            {products.map((product) => (
              <tr key={product.id} className="hover:bg-stone-50/50 transition-colors">
                <td className="px-6 py-4">
                  {product.imageUrl ? (
                    <img src={product.imageUrl} alt={product.name} className="w-10 h-10 rounded-lg object-cover border border-stone-200" />
                  ) : (
                    <div className="w-10 h-10 rounded-lg bg-stone-100 flex items-center justify-center border border-stone-200">
                      <UtensilsCrossed size={16} className="text-stone-400" />
                    </div>
                  )}
                </td>
                <td className="px-6 py-4 font-bold text-stone-900">{product.name}</td>
                <td className="px-6 py-4 capitalize">{product.category === 'food' ? 'Comida' : 'Bebida'}</td>
                <td className="px-6 py-4 font-medium">R$ {product.price.toFixed(2)}</td>
                <td className="px-6 py-4">
                  {product.isComposite ? (
                    <span className="inline-flex items-center rounded-full bg-blue-50 px-2 py-1 text-xs font-medium text-blue-700 ring-1 ring-inset ring-blue-700/10">
                      Sim
                    </span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-stone-50 px-2 py-1 text-xs font-medium text-stone-600 ring-1 ring-inset ring-stone-500/10">
                      Não
                    </span>
                  )}
                </td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => handleEdit(product)} className="mr-3 text-blue-600 hover:text-blue-800 transition-colors">
                    <Edit size={18} />
                  </button>
                  <button onClick={() => handleDelete(product.id)} className="text-red-600 hover:text-red-800 transition-colors">
                    <Trash2 size={18} />
                  </button>
                </td>
              </tr>
            ))}
            {products.length === 0 && (
              <tr>
                <td colSpan={5} className="px-6 py-8 text-center text-stone-500">
                  Nenhum item cadastrado no cardápio.
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-stone-200 my-8">
            <h2 className="mb-6 text-2xl font-bold font-heading text-stone-900">{editingId ? 'Editar Item' : 'Novo Item do Cardápio'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Nome do Prato/Bebida</label>
                <input required type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all" />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">Descrição (Opcional)</label>
                <textarea value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all" rows={2} />
              </div>
              <div>
                <label className="mb-1.5 block text-sm font-bold text-stone-700">URL da Foto (Opcional)</label>
                <input type="url" placeholder="https://exemplo.com/foto.jpg" value={formData.imageUrl} onChange={e => setFormData({...formData, imageUrl: e.target.value})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-stone-700">Categoria</label>
                  <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all">
                    <option value="food">Comida</option>
                    <option value="drink">Bebida</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-sm font-bold text-stone-700">Preço de Venda (R$)</label>
                  <input required type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className="w-full rounded-xl border border-stone-200 bg-stone-50 p-3 text-stone-900 focus:border-orange-500 focus:bg-white focus:ring-2 focus:ring-orange-500/20 outline-none transition-all" />
                </div>
              </div>
              
              <div className="flex items-center gap-2 pt-2">
                <input type="checkbox" id="isComposite" checked={formData.isComposite} onChange={e => setFormData({...formData, isComposite: e.target.checked})} className="rounded text-orange-600 focus:ring-orange-500 w-4 h-4" />
                <label htmlFor="isComposite" className="text-sm font-bold text-stone-700">Possui Ficha Técnica (Consome Estoque)</label>
              </div>

              {formData.isComposite && (
                <div className="rounded-2xl border border-stone-200 bg-stone-50 p-4 mt-2">
                  <h3 className="mb-3 text-sm font-bold text-stone-900">Ingredientes</h3>
                  <div className="mb-3 space-y-2">
                    {recipeIngredients.map(ing => (
                      <div key={ing.ingredientId} className="flex items-center justify-between text-sm bg-white p-2 rounded-lg border border-stone-100">
                        <span className="font-medium text-stone-900">{ing.name} <span className="text-stone-500">({ing.quantity}{ing.unit})</span></span>
                        <button type="button" onClick={() => removeIngredientFromRecipe(ing.ingredientId)} className="text-red-500 hover:text-red-700 font-medium transition-colors">Remover</button>
                      </div>
                    ))}
                    {recipeIngredients.length === 0 && (
                      <p className="text-xs text-stone-500 italic">Nenhum ingrediente adicionado.</p>
                    )}
                  </div>
                  <div className="flex gap-2">
                    <select 
                      className="flex-1 rounded-xl border border-stone-200 bg-white p-2.5 text-sm text-stone-900 focus:border-orange-500 focus:ring-2 focus:ring-orange-500/20 outline-none transition-all"
                      onChange={(e) => {
                        const val = e.target.value;
                        if (val) addIngredientToRecipe(val, 1); // Default to 1, user can edit later if we add an input
                      }}
                      value=""
                    >
                      <option value="">Adicionar Ingrediente...</option>
                      {ingredients.map(p => (
                        <option key={p.id} value={p.id}>{p.name} ({p.unit})</option>
                      ))}
                    </select>
                  </div>
                </div>
              )}

              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="rounded-xl px-5 py-2.5 font-bold text-stone-600 hover:bg-stone-100 transition-colors">Cancelar</button>
                <button type="submit" className="rounded-xl bg-orange-600 px-5 py-2.5 font-bold text-white hover:bg-orange-700 shadow-md shadow-orange-600/20 transition-all active:scale-95">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
