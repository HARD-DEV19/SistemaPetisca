export interface PrintRequest {
  pedidoId: string;
  itens: {
    nome: string;
    setor: string;
    quantidade: number;
    observacao?: string;
    preco: number;
  }[];
  imprimirCaixa: boolean;
  tipo: string;
  total: number;
  pagamento?: string;
  mesa: string;
}

export const printOrderWithFallback = async (request: PrintRequest, htmlContent: string) => {
  const controller = new AbortController();
  const timeoutId = setTimeout(() => controller.abort(), 3000); // 3s timeout

  try {
    const res = await fetch(`http://127.0.0.1:17321/print`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(request),
      signal: controller.signal
    });
    clearTimeout(timeoutId);
    if (res.ok) return;
  } catch (e) {
    clearTimeout(timeoutId);
    console.warn('Print agent offline or timeout, falling back to browser print', e);
  }
  printReceipt(htmlContent);
};

export const printReceipt = (content: string) => {
  const printerType = localStorage.getItem('printerType') || '80mm';
  
  let width = '80mm';
  let fontSize = '14px';
  let extraCss = '';
  
  if (printerType === '58mm') {
    width = '100%';
    fontSize = '12px';
    extraCss = 'body { padding: 0px; font-weight: 600; max-width: 58mm; margin: 0 auto; }';
  } else if (printerType === 'a4') {
    width = '100%';
    fontSize = '18px';
    extraCss = 'body { max-width: 210mm; margin: 0 auto; padding: 20px; font-weight: 500; }';
  } else {
    // 80mm default
    width = '100%';
    fontSize = '14px';
    extraCss = 'body { padding: 0px; font-weight: 600; max-width: 80mm; margin: 0 auto; }';
  }

  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  
  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(`
      <html>
        <head>
          <title>Imprimir Comanda</title>
          <style>
            @page { 
              margin: 0; 
              size: ${printerType === 'a4' ? 'auto' : printerType === '58mm' ? '58mm auto' : '80mm auto'};
            }
            body { 
              font-family: 'Courier New', Courier, monospace; 
              color: #000; 
              margin: 0; 
              padding: 0; 
              width: 100%;
              font-size: ${fontSize};
              line-height: 1.2;
              -webkit-print-color-adjust: exact;
            }
            ${extraCss}
            h1, h2, h3, p { margin: 0 0 4px 0; padding: 0; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .flex { display: flex; justify-content: space-between; align-items: flex-start; }
            .border-b { border-bottom: 2px dashed #000; margin-bottom: 6px; padding-bottom: 6px; }
            .border-t { border-top: 2px dashed #000; margin-top: 6px; padding-top: 6px; }
            .bold { font-weight: 900; }
            .text-lg { font-size: 1.3em; font-weight: 900; }
            .text-xl { font-size: 1.6em; font-weight: 900; }
            .mb-1 { margin-bottom: 4px; }
            .mb-2 { margin-bottom: 8px; }
            .w-full { width: 100%; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
            td { vertical-align: top; padding: 4px 0; font-weight: 700; }
            .qty { width: 35px; font-weight: 900; font-size: 1.1em; }
            .price { text-align: right; width: 85px; font-weight: 900; }
          </style>
        </head>
        <body>${content}</body>
      </html>
    `);
    doc.close();
    
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);
    }, 250);
  }
};
