import { useEffect, useState, useRef } from 'react';
import { collection, query, where, onSnapshot, updateDoc, doc, getDocs, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';

export default function PrintJobListener() {
  const { userData } = useAuth();
  const [isAgentOnline, setIsAgentOnline] = useState(false);
  const processedJobs = useRef<Set<string>>(new Set());
  const isInitialLoad = useRef(true);

  useEffect(() => {
    // Only run this listener on the Cashier/Admin PC and if auto-print is enabled
    const isAutoPrintEnabled = localStorage.getItem('enableAutoPrint') === 'true';
    if (!userData || (userData.role !== 'admin' && userData.role !== 'cashier' && userData.role !== 'manager') || !isAutoPrintEnabled) return;

    let isAgentOnlineLocal = false;

    // Health check for the agent
    const checkAgent = async () => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 2000);

      try {
        const res = await fetch('http://127.0.0.1:17321/health', { signal: controller.signal });
        clearTimeout(timeoutId);
        if (res.ok) {
          if (!isAgentOnlineLocal) {
            isAgentOnlineLocal = true;
            setIsAgentOnline(true);
            // When agent comes online, try to process all pending jobs
            await processPendingJobs();
          }
        } else {
          if (isAgentOnlineLocal) {
            isAgentOnlineLocal = false;
            setIsAgentOnline(false);
          }
        }
      } catch (e) {
        clearTimeout(timeoutId);
        if (isAgentOnlineLocal) {
          isAgentOnlineLocal = false;
          setIsAgentOnline(false);
        }
      }
    };

    const processPendingJobs = async () => {
      const q = query(collection(db, 'printJobs'), where('status', '==', 'pending'));
      const snapshot = await getDocs(q);
      for (const document of snapshot.docs) {
        if (!processedJobs.current.has(document.id)) {
          await printJob(document.id, document.data());
        }
      }
    };

    const sendRawPrint = async (printerName: string, text: string) => {
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 10000);
      const res = await fetch('http://127.0.0.1:17321/print', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName, text }),
        signal: controller.signal
      });
      clearTimeout(timeoutId);
      if (!res.ok) throw new Error(await res.text());
    };

    const formatSectorTicket = (sectorName: string, items: any[], job: any, width: number = 32) => {
      const ESC = '\x1B';
      const GS = '\x1D';
      const BOLD_ON = `${ESC}E\x01`;
      const BOLD_OFF = `${ESC}E\x00`;
      const DOUBLE_SIZE = `${GS}!\x11`;
      const NORMAL_SIZE = `${GS}!\x00`;

      const line = '-'.repeat(width);
      let text = `${BOLD_ON}${DOUBLE_SIZE}--- ${sectorName} ---${NORMAL_SIZE}\r\n`;
      text += `${BOLD_ON}Data: ${new Date().toLocaleString('pt-BR')}\r\n`;
      text += `${DOUBLE_SIZE}Mesa: ${job.mesa}${NORMAL_SIZE}\r\n`;
      text += `Pedido: #${job.pedidoId}\r\n`;
      if (job.garcom) text += `Garcom: ${job.garcom}\r\n`;
      text += `\r\nQtd  Item\r\n`;
      text += `${line}\r\n`;
      items.forEach(item => {
        text += `${DOUBLE_SIZE}${item.quantidade}x   ${item.nome}${NORMAL_SIZE}\r\n`;
        if (item.observacao) text += `     OBS: ${item.observacao}\r\n`;
      });
      text += `\r\n--- FIM ---${BOLD_OFF}\r\n\r\n\r\n\r\n\r\n\r\n`;
      return text;
    };

    const formatReceiptTicket = (job: any, width: number = 32) => {
      const ESC = '\x1B';
      const GS = '\x1D';
      const BOLD_ON = `${ESC}E\x01`;
      const BOLD_OFF = `${ESC}E\x00`;
      const DOUBLE_SIZE = `${GS}!\x11`;
      const NORMAL_SIZE = `${GS}!\x00`;

      const line = '-'.repeat(width);
      let text = `${BOLD_ON}${DOUBLE_SIZE}PETISCA PEIXE${NORMAL_SIZE}\r\n`;
      text += `${BOLD_ON}${job.tipo === 'preconta' ? 'Conferencia de Mesa' : 'Cupom Nao Fiscal'}\r\n`;
      text += `${new Date().toLocaleString('pt-BR')}\r\n`;
      text += `${DOUBLE_SIZE}Mesa: ${job.mesa}${NORMAL_SIZE}\r\n`;
      text += `Pedido: #${job.pedidoId}\r\n\r\n`;
      if (job.itens) {
        job.itens.forEach((item: any) => {
          const price = `R$ ${(item.preco * item.quantidade).toFixed(2)}`;
          const name = `${item.quantidade}x ${item.nome}`;
          if (name.length + price.length + 1 <= width) {
            text += name + ' '.repeat(width - name.length - price.length) + price + '\r\n';
          } else {
            text += name + '\r\n';
            text += ' '.repeat(width - price.length) + price + '\r\n';
          }
        });
      }
      text += `${line}\r\n`;
      const subtotalStr = `SUBTOTAL: R$ ${job.total.toFixed(2)}`;
      text += ' '.repeat(Math.max(0, width - subtotalStr.length)) + subtotalStr + '\r\n';
      const taxa = job.total * 0.1;
      const taxaStr = `TAXA (10%): R$ ${taxa.toFixed(2)}`;
      text += ' '.repeat(Math.max(0, width - taxaStr.length)) + taxaStr + '\r\n';
      const totalStr = `TOTAL: R$ ${(job.total + taxa).toFixed(2)}`;
      text += `${DOUBLE_SIZE}` + ' '.repeat(Math.max(0, width - totalStr.length)) + totalStr + `${NORMAL_SIZE}\r\n\r\n`;
      if (job.pagamento) text += `Pagamento: ${job.pagamento}\r\n\r\n`;
      text += `Obrigado pela preferencia!${BOLD_OFF}\r\n\r\n\r\n\r\n\r\n\r\n`;
      return text;
    };

    const printJob = async (jobId: string, job: any) => {
      if (processedJobs.current.has(jobId)) return;
      
      // Mark as processed immediately to avoid double prints from concurrent calls
      processedJobs.current.add(jobId);

      try {
        const docRef = doc(db, 'settings', 'printAgent');
        const docSnap = await getDoc(docRef);
        const config = docSnap.exists() ? docSnap.data().config : null;

        if (!config) throw new Error("Configuração de impressora não encontrada no banco");

        let hasPrintedSomething = false;

        const kitchenItems = (job.itens || []).filter((i: any) => ['kitchen', 'cozinha', 'food'].includes(i.setor));
        if (kitchenItems.length > 0 && config.cozinha?.printer) {
          const width = config.cozinha.largura === 80 ? 42 : 32;
          await sendRawPrint(config.cozinha.printer, formatSectorTicket('COZINHA', kitchenItems, job, width));
          hasPrintedSomething = true;
        }

        const barItems = (job.itens || []).filter((i: any) => ['bar', 'drink'].includes(i.setor));
        if (barItems.length > 0 && config.bar?.printer) {
          const width = config.bar.largura === 80 ? 42 : 32;
          await sendRawPrint(config.bar.printer, formatSectorTicket('BAR', barItems, job, width));
          hasPrintedSomething = true;
        }

        if (job.imprimirCaixa && config.caixa?.printer) {
          const width = config.caixa.largura === 80 ? 42 : 32;
          await sendRawPrint(config.caixa.printer, formatReceiptTicket(job, width));
          hasPrintedSomething = true;
        }

        // Even if nothing was printed (e.g., no printer configured for the sector), mark as completed
        // so it doesn't stay in the queue forever.
        await updateDoc(doc(db, 'printJobs', jobId), { 
          status: 'completed', 
          printedAt: new Date().toISOString(),
          agentProcessed: true 
        });
        
        if (hasPrintedSomething) {
          toast.success(`Pedido da Mesa ${job.mesa} impresso com sucesso!`);
        }
      } catch (e: any) {
        processedJobs.current.delete(jobId); // Allow retry on network error
        console.error(`Error printing job ${jobId}`, e);
        await updateDoc(doc(db, 'printJobs', jobId), { status: 'failed', error: e.message });
      }
    };

    const interval = setInterval(checkAgent, 5000);
    checkAgent();

    const q = query(collection(db, 'printJobs'), where('status', '==', 'pending'));
    const unsub = onSnapshot(q, (snapshot) => {
      // On initial load, we don't want to process everything via snapshot 
      // because processPendingJobs handles the initial batch when agent comes online
      if (isInitialLoad.current) {
        isInitialLoad.current = false;
        return;
      }

      snapshot.docChanges().forEach(async (change) => {
        if (change.type === 'added' && isAgentOnlineLocal) {
          await printJob(change.doc.id, change.doc.data());
        }
      });
    });

    return () => {
      clearInterval(interval);
      unsub();
    };
  }, [userData]);

  return null;
}
