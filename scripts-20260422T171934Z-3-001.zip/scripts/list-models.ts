import { GoogleGenAI } from '@google/genai';

/**
 * Script para inspecionar a estrutura de modelos no Vertex AI (2026)
 */

async function main() {
  const projectId = 'vibe-coding-ecossystem';
  const location = 'us-central1';

  try {
    const genAI = new GoogleGenAI({
      project: projectId,
      location: location,
      vertexai: true
    });

    console.log(`\n??  Inspecionando modelos no Vertex AI (${projectId}, ${location})...\n`);

    const res = await genAI.models.list();
    console.log('--- Início do Retorno ---');
    console.log(JSON.stringify(res, null, 2));
    console.log('--- Fim do Retorno ---');

  } catch (error: any) {
    console.error('\nErro ao listar modelos:', error.message);
    process.exit(1);
  }
}

main();
