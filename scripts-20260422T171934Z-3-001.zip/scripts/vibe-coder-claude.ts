import { AnthropicVertex } from '@anthropic-ai/vertex-sdk';

/**
 * Script de Vibe Coding com Claude (Vertex AI) - Versão 2026
 * Permite alternar entre Sonnet (rápido) e Opus (ultra-inteligente).
 * Uso: npx tsx scripts/vibe-coder-claude.ts --model="claude-4-6-opus" "Prompt"
 */

async function main() {
  const args = process.argv.slice(2);
  let prompt = '';
  let modelName = 'claude-3-5-sonnet@20240620'; // Padrão
  let projectId = 'vibe-coding-ecossystem';
  let region = 'us-central1';

  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--model=')) modelName = args[i].split('=')[1];
    else if (args[i].startsWith('--project=')) projectId = args[i].split('=')[1];
    else if (args[i].startsWith('--region=')) region = args[i].split('=')[1];
    else prompt += args[i] + ' ';
  }

  if (!prompt.trim()) {
    console.error('Uso: npx tsx scripts/vibe-coder-claude.ts "Seu comando"');
    process.exit(1);
  }

  try {
    const client = new AnthropicVertex({
      projectId: projectId,
      region: region,
    });

    console.log(`\n??  Vibe Coding com ${modelName} no Vertex AI...\n`);

    const stream = await client.messages.create({
      max_tokens: 8192, // Opus suporta saídas maiores
      messages: [{ role: 'user', content: prompt.trim() }],
      model: modelName,
      stream: true,
    });

    for await (const messageChunk of stream) {
      if (messageChunk.type === 'content_block_delta' && 'text' in messageChunk.delta) {
        process.stdout.write(messageChunk.delta.text);
      }
    }
    
    console.log(`\n\n? Finalizado pelo ${modelName}.`);

  } catch (error: any) {
    console.error('\nErro ao consultar o Claude no Vertex AI:', error.message);
    process.exit(1);
  }
}

main();
