import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, writeBatch, query, where } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "gen-lang-client-0575100100",
  appId: "1:255243577629:web:7478f3b7010ba22d9ad9f4",
  apiKey: "AIzaSyDi0kP-K3KdVWaoUF4l2omQLko9vbK8bvc",
  authDomain: "gen-lang-client-0575100100.firebaseapp.com",
  storageBucket: "gen-lang-client-0575100100.firebasestorage.app",
  messagingSenderId: "255243577629"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const DATA = {
  categories: [
    { name: 'Porções Tradicionais', type: 'food', order: 1 },
    { name: 'Porções de Peixes', type: 'food', order: 2 },
    { name: 'Pratos Individuais', type: 'food', order: 3 },
    { name: 'Porções Extras', type: 'food', order: 4 },
    { name: 'Chopp', type: 'drink', order: 5 },
    { name: 'Cervejas (Unidade)', type: 'drink', order: 6 },
    { name: 'Baldinho de Cerveja', type: 'drink', order: 7 },
    { name: 'Bebidas Não Alcoólicas', type: 'drink', order: 8 },
    { name: 'Sucos Naturais', type: 'drink', order: 9 },
    { name: 'Sucos de Polpa', type: 'drink', order: 10 },
  ],
  products: [
    // PORÇÕES TRADICIONAIS
    { name: 'Costelinha de porco (600g)', price: 44.99, cat: 'Porções Tradicionais', type: 'food', desc: '' },
    { name: 'Frango a passarinho (600g)', price: 35.99, cat: 'Porções Tradicionais', type: 'food', desc: '' },
    { name: 'Coxinha da asa (600g)', price: 37.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Empanada' },
    { name: 'Picanha (400g)', price: 69.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha mandioca frita' },
    { name: 'Carne de Sol (400g)', price: 59.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha mandioca frita' },
    { name: 'Filé mignon (400g)', price: 64.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha batata ou mandioca frita' },
    { name: 'Batata Frita (400g)', price: 19.99, cat: 'Porções Tradicionais', type: 'food', desc: '' },
    { name: 'Calabresa (400g)', price: 35.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha batata ou mandioca frita' },
    { name: 'Mandioca Frita (400g)', price: 15.99, cat: 'Porções Tradicionais', type: 'food', desc: '' },
    { name: 'Torresmo (400g)', price: 19.99, cat: 'Porções Tradicionais', type: 'food', desc: '' },

    // PORÇÕES DE PEIXES
    { name: 'Filé de Tilápia a Palito (400g)', price: 59.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
    { name: 'Posta de Tilápia (500g)', price: 55.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
    { name: 'Costelinha de Tilápia (500g)', price: 50.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
    { name: 'Costelinha de Tambaqui (500g)', price: 52.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
    { name: 'Camarão Alho e Óleo (400g)', price: 64.99, cat: 'Porções de Peixes', type: 'food', desc: '' },
    { name: 'Camarão Empanado (400g)', price: 79.99, cat: 'Porções de Peixes', type: 'food', desc: '' },
    { name: 'Manjubinha frita (500g)', price: 39.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha batata frita' },
    { name: 'Moqueca de Peixe', price: 119.99, cat: 'Porções de Peixes', type: 'food', desc: 'Serve 2 a 3 pessoas. Acompanha arroz e pirão' },

    // PRATOS INDIVIDUAIS
    { name: 'Filé de Peixe Grelhado', price: 24.00, cat: 'Pratos Individuais', type: 'food', desc: 'Acompanha arroz e salada' },
    { name: 'Filé de Peixe Empanado', price: 28.00, cat: 'Pratos Individuais', type: 'food', desc: 'Acompanha arroz e batata frita' },

    // PORÇÕES EXTRAS
    { name: 'Arroz', price: 4.99, cat: 'Porções Extras', type: 'food', desc: '' },
    { name: 'Vinagrete', price: 4.99, cat: 'Porções Extras', type: 'food', desc: '' },
    { name: 'Farofa', price: 4.99, cat: 'Porções Extras', type: 'food', desc: '' },

    // CHOPP
    { name: 'Chopp 300ml', price: 6.99, cat: 'Chopp', type: 'drink', desc: '' },

    // CERVEJAS
    { name: 'Long Neck Heineken', price: 9.00, cat: 'Cervejas (Unidade)', type: 'drink', desc: '' },
    { name: 'Long Neck Stella/Bud', price: 8.00, cat: 'Cervejas (Unidade)', type: 'drink', desc: '' },
    { name: 'Cerveja Lata 269ml', price: 3.99, cat: 'Cervejas (Unidade)', type: 'drink', desc: 'Brahma, Antarctica, Amstel, Skol' },

    // BALDINHO
    { name: 'Baldinho Long Neck (4un)', price: 40.00, cat: 'Baldinho de Cerveja', type: 'drink', desc: 'Heineken' },
    { name: 'Baldinho Stella/Bud (4un)', price: 36.00, cat: 'Baldinho de Cerveja', type: 'drink', desc: 'Stella/Budweiser' },
    { name: 'Baldinho Lata (6un)', price: 26.00, cat: 'Baldinho de Cerveja', type: 'drink', desc: 'Brahma, Antarctica, Amstel, Skol' },

    // NÃO ALCOÓLICAS
    { name: 'Água sem gás', price: 2.99, cat: 'Bebidas Não Alcoólicas', type: 'drink', desc: '' },
    { name: 'Água com gás', price: 4.99, cat: 'Bebidas Não Alcoólicas', type: 'drink', desc: '' },
    { name: 'Refrigerante Lata', price: 3.99, cat: 'Bebidas Não Alcoólicas', type: 'drink', desc: 'Coca, Guaraná, Fanta, Sprite' },
    { name: 'H2O Limão', price: 6.99, cat: 'Bebidas Não Alcoólicas', type: 'drink', desc: '' },

    // SUCOS NATURAIS
    { name: 'Suco Natural Copo 300ml', price: 7.99, cat: 'Sucos Naturais', type: 'drink', desc: 'Laranja ou Limão' },
    { name: 'Suco Natural Jarra 750ml', price: 18.99, cat: 'Sucos Naturais', type: 'drink', desc: 'Laranja ou Limão' },
    { name: 'Suco Natural Jarra 1,5L', price: 35.99, cat: 'Sucos Naturais', type: 'drink', desc: 'Laranja ou Limão' },

    // SUCOS POLPA
    { name: 'Suco Polpa Copo 300ml', price: 6.99, cat: 'Sucos de Polpa', type: 'drink', desc: 'Maracujá, Abacaxi, Goiaba ou Caju' },
    { name: 'Suco Polpa Jarra 750ml', price: 15.99, cat: 'Sucos de Polpa', type: 'drink', desc: 'Maracujá, Abacaxi, Goiaba ou Caju' },
    { name: 'Suco Polpa Jarra 1,5L', price: 28.99, cat: 'Sucos de Polpa', type: 'drink', desc: 'Maracujá, Abacaxi, Goiaba ou Caju' },
  ]
};

async function run() {
  console.log('--- LIMPANDO DADOS ANTIGOS ---');
  const batch = writeBatch(db);
  const pSnap = await getDocs(collection(db, 'products'));
  pSnap.docs.forEach(d => { if(d.data().category === 'food' || d.data().category === 'drink') batch.delete(d.ref); });
  const cSnap = await getDocs(collection(db, 'categories'));
  cSnap.docs.forEach(d => batch.delete(d.ref));
  await batch.commit();

  console.log('--- INJETANDO CATEGORIAS ---');
  const catIds: Record<string, string> = {};
  for (const cat of DATA.categories) {
    const ref = await addDoc(collection(db, 'categories'), { ...cat, createdAt: new Date().toISOString() });
    catIds[cat.name] = ref.id;
    console.log(`Categoria: ${cat.name}`);
  }

  console.log('--- INJETANDO PRODUTOS ---');
  for (const prod of DATA.products) {
    await addDoc(collection(db, 'products'), {
      name: prod.name,
      description: prod.desc,
      category: prod.type,
      subCategory: catIds[prod.cat],
      price: prod.price,
      unit: 'un', cost: 0, stock: 999, minStock: 0, isComposite: false, imageUrl: '', createdAt: new Date().toISOString()
    });
    console.log(`Prato: ${prod.name}`);
  }

  console.log('--- SUCESSO ABSOLUTO ---');
  process.exit(0);
}

run();
