import { GoogleGenAI } from '@google/genai';

/**
 * Script de Vibe Coding definitivo (Abril 2026)
 * Modelo padrão: gemini-2.5-flash (Vertex AI)
 * Uso: npx tsx scripts/vibe-coder.ts "Explique o componente App.tsx"
 */

async function main() {
  const args = process.argv.slice(2);
  let prompt = '';
  let modelName = 'gemini-2.5-flash'; 
  let projectId = 'vibe-coding-ecossystem';
  let location = 'us-central1';

  for (let i = 0; i < args.length; i++) {
    if (args[i].startsWith('--model=')) modelName = args[i].split('=')[1];
    else if (args[i].startsWith('--project=')) projectId = args[i].split('=')[1];
    else if (args[i].startsWith('--location=')) location = args[i].split('=')[1];
    else prompt += args[i] + ' ';
  }

  if (!prompt.trim()) {
    console.error('Uso: npx tsx scripts/vibe-coder.ts "Seu comando de codificação"');
    process.exit(1);
  }

  try {
    const genAI = new GoogleGenAI({
      project: projectId,
      location: location,
      vertexai: true
    });

    console.log(`\n??  Vibe Coding com ${modelName} no Vertex AI...\n`);

    const result = await genAI.models.generateContentStream({
      model: modelName,
      contents: [{ role: 'user', parts: [{ text: prompt.trim() }] }],
    });

    for await (const chunk of result) {
      const text = chunk.candidates?.[0]?.content?.parts?.[0]?.text;
      if (text) {
        process.stdout.write(text);
      }
    }
    
    console.log('\n\n? Finalizado.');

  } catch (error: any) {
    console.error('\nErro ao consultar o Vertex AI:', error.message);
    process.exit(1);
  }
}

main();
