import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, writeBatch, query } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "gen-lang-client-0575100100",
  appId: "1:255243577629:web:7478f3b7010ba22d9ad9f4",
  apiKey: "AIzaSyDi0kP-K3KdVWaoUF4l2omQLko9vbK8bvc",
  authDomain: "gen-lang-client-0575100100.firebaseapp.com",
  storageBucket: "gen-lang-client-0575100100.firebasestorage.app",
  messagingSenderId: "255243577629"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const DATA = {
  categories: [
    { name: 'Porções Tradicionais', type: 'food', order: 1 },
    { name: 'Porções de Peixes', type: 'food', order: 2 },
    { name: 'Pratos Individuais', type: 'food', order: 3 },
    { name: 'Porções Extras', type: 'food', order: 4 },
    { name: 'Chopp', type: 'drink', order: 5 },
    { name: 'Cervejas (Unidade)', type: 'drink', order: 6 },
    { name: 'Baldinho de Cerveja', type: 'drink', order: 7 },
    { name: 'Bebidas Não Alcoólicas', type: 'drink', order: 8 },
    { name: 'Sucos Naturais', type: 'drink', order: 9 },
    { name: 'Sucos de Polpa', type: 'drink', order: 10 },
  ],
  products: [
    // Porções Tradicionais
    { name: 'Costelinha de porco (600g)', price: 44.99, category: 'food', subCategoryName: 'Porções Tradicionais' },
    { name: 'Frango a passarinho (600g)', price: 35.99, category: 'food', subCategoryName: 'Porções Tradicionais' },
    { name: 'Coxinha da asa (600g)', price: 37.99, category: 'food', subCategoryName: 'Porções Tradicionais', description: 'Empanada' },
    { name: 'Picanha (400g)', price: 69.99, category: 'food', subCategoryName: 'Porções Tradicionais', description: 'Acompanha mandioca frita' },
    { name: 'Carne de Sol (400g)', price: 59.99, category: 'food', subCategoryName: 'Porções Tradicionais', description: 'Acompanha mandioca frita' },
    { name: 'Filé mignon (400g)', price: 64.99, category: 'food', subCategoryName: 'Porções Tradicionais', description: 'Acompanha batata ou mandioca frita' },
    { name: 'Batata Frita (400g)', price: 19.99, category: 'food', subCategoryName: 'Porções Tradicionais' },
    { name: 'Calabresa (400g)', price: 35.99, category: 'food', subCategoryName: 'Porções Tradicionais', description: 'Acompanha batata ou mandioca frita' },
    { name: 'Mandioca Frita (400g)', price: 15.99, category: 'food', subCategoryName: 'Porções Tradicionais' },
    { name: 'Torresmo (400g)', price: 19.99, category: 'food', subCategoryName: 'Porções Tradicionais' },

    // Porções de Peixes
    { name: 'Filé de Tilápia a Palito (400g)', price: 59.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Acompanha farofa e vinagrete' },
    { name: 'Posta de Tilápia (500g)', price: 55.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Acompanha farofa e vinagrete' },
    { name: 'Costelinha de Tilápia (500g)', price: 50.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Acompanha farofa e vinagrete' },
    { name: 'Costelinha de Tambaqui (500g)', price: 52.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Acompanha farofa e vinagrete' },
    { name: 'Camarão Alho e Óleo (400g)', price: 64.99, category: 'food', subCategoryName: 'Porções de Peixes' },
    { name: 'Camarão Empanado (400g)', price: 79.99, category: 'food', subCategoryName: 'Porções de Peixes' },
    { name: 'Manjubinha frita (500g)', price: 39.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Acompanha batata frita' },
    { name: 'Moqueca de Peixe', price: 119.99, category: 'food', subCategoryName: 'Porções de Peixes', description: 'Serve 2 a 3 pessoas. Acompanha arroz e pirão' },

    // Pratos Individuais
    { name: 'Filé de Peixe Grelhado', price: 24.00, category: 'food', subCategoryName: 'Pratos Individuais', description: 'Acompanha arroz e salada' },
    { name: 'Filé de Peixe Empanado', price: 28.00, category: 'food', subCategoryName: 'Pratos Individuais', description: 'Acompanha arroz e batata frita' },

    // Porções Extras
    { name: 'Arroz', price: 4.99, category: 'food', subCategoryName: 'Porções Extras' },
    { name: 'Vinagrete', price: 4.99, category: 'food', subCategoryName: 'Porções Extras' },
    { name: 'Farofa', price: 4.99, category: 'food', subCategoryName: 'Porções Extras' },

    // Chopp
    { name: 'Chopp 300ml', price: 6.99, category: 'drink', subCategoryName: 'Chopp' },

    // Cervejas
    { name: 'Long Neck Heineken', price: 9.00, category: 'drink', subCategoryName: 'Cervejas (Unidade)' },
    { name: 'Long Neck Stella/Bud', price: 8.00, category: 'drink', subCategoryName: 'Cervejas (Unidade)' },
    { name: 'Cerveja Lata 269ml', price: 3.99, category: 'drink', subCategoryName: 'Cervejas (Unidade)', description: 'Brahma, Antarctica, Amstel, Skol' },

    // Baldinho
    { name: 'Baldinho Long Neck (4un) - Heineken', price: 40.00, category: 'drink', subCategoryName: 'Baldinho de Cerveja' },
    { name: 'Baldinho Long Neck (4un) - Stella/Bud', price: 36.00, category: 'drink', subCategoryName: 'Baldinho de Cerveja' },
    { name: 'Baldinho Lata (6un)', price: 26.00, category: 'drink', subCategoryName: 'Baldinho de Cerveja', description: 'Brahma, Antarctica, Amstel, Skol' },

    // Não Alcoólicas
    { name: 'Água sem gás', price: 2.99, category: 'drink', subCategoryName: 'Bebidas Não Alcoólicas' },
    { name: 'Água com gás', price: 4.99, category: 'drink', subCategoryName: 'Bebidas Não Alcoólicas' },
    { name: 'Refrigerante Lata', price: 3.99, category: 'drink', subCategoryName: 'Bebidas Não Alcoólicas', description: 'Coca, Guaraná, Fanta, Sprite' },
    { name: 'H2O Limão', price: 6.99, category: 'drink', subCategoryName: 'Bebidas Não Alcoólicas' },

    // Sucos Naturais
    { name: 'Suco Natural Copo 300ml', price: 7.99, category: 'drink', subCategoryName: 'Sucos Naturais' },
    { name: 'Suco Natural Jarra 750ml', price: 18.99, category: 'drink', subCategoryName: 'Sucos Naturais' },
    { name: 'Suco Natural Jarra 1,5L', price: 35.99, category: 'drink', subCategoryName: 'Sucos Naturais' },

    // Sucos Polpa
    { name: 'Suco Polpa Copo 300ml', price: 6.99, category: 'drink', subCategoryName: 'Sucos de Polpa' },
    { name: 'Suco Polpa Jarra 750ml', price: 15.99, category: 'drink', subCategoryName: 'Sucos de Polpa' },
    { name: 'Suco Polpa Jarra 1,5L', price: 28.99, category: 'drink', subCategoryName: 'Sucos de Polpa' },
  ]
};

async function run() {
  console.log('--- LIMPANDO CARDÁPIO ANTIGO ---');
  const productsSnap = await getDocs(collection(db, 'products'));
  const batchP = writeBatch(db);
  productsSnap.docs.forEach(d => batchP.delete(d.ref));
  await batchP.commit();

  const catsSnap = await getDocs(collection(db, 'categories'));
  const batchC = writeBatch(db);
  catsSnap.docs.forEach(d => batchC.delete(d.ref));
  await batchC.commit();

  console.log('--- INJETANDO NOVAS CATEGORIAS ---');
  const catIds: Record<string, string> = {};
  for (const cat of DATA.categories) {
    const docRef = await addDoc(collection(db, 'categories'), {
      ...cat,
      createdAt: new Date().toISOString()
    });
    catIds[cat.name] = docRef.id;
    console.log(`Categoria criada: ${cat.name}`);
  }

  console.log('--- INJETANDO NOVOS PRODUTOS ---');
  for (const prod of DATA.products) {
    await addDoc(collection(db, 'products'), {
      name: prod.name,
      description: prod.description || '',
      category: prod.category,
      subCategory: catIds[prod.subCategoryName],
      price: prod.price,
      isComposite: false,
      unit: 'un',
      cost: 0,
      stock: 999,
      minStock: 0,
      imageUrl: '',
      ingredientList: [],
      createdAt: new Date().toISOString()
    });
    console.log(`Produto criado: ${prod.name}`);
  }

  console.log('--- CONCLUÍDO COM SUCESSO ---');
  process.exit(0);
}

run().catch(err => {
  console.error(err);
  process.exit(1);
});
