import { initializeApp } from 'firebase/app';
import { getFirestore, collection, getDocs, deleteDoc, doc, query, where } from 'firebase/firestore';

const firebaseConfig = {
  projectId: "gen-lang-client-0575100100",
  appId: "1:255243577629:web:7478f3b7010ba22d9ad9f4",
  apiKey: "AIzaSyDi0kP-K3KdVWaoUF4l2omQLko9vbK8bvc",
  authDomain: "gen-lang-client-0575100100.firebaseapp.com"
};

const app = initializeApp(firebaseConfig);
const db = getFirestore(app);

const COLLECTIONS_TO_DELETE = [
  'orders',
  'orderItems',
  'transactions',
  'printJobs',
  'cashRegisterSessions',
  'tables'
];

async function cleanup() {
  console.log('🚀 Iniciando limpeza profunda do PetiscaPeixe (Preservando Cardápio)...');

  for (const colName of COLLECTIONS_TO_DELETE) {
    try {
      const snapshot = await getDocs(collection(db, colName));
      console.log(`- Apagando ${snapshot.size} documentos de "${colName}"...`);
      const deletePromises = snapshot.docs.map(d => deleteDoc(doc(db, colName, d.id)));
      await Promise.all(deletePromises);
    } catch (e) {
      console.error(`Erro ao limpar ${colName}:`, e);
    }
  }

  // Limpar Garçons (Preservando Admins)
  try {
    const waitersQuery = query(collection(db, 'users'), where('role', '==', 'waiter'));
    const waiterSnapshot = await getDocs(waitersQuery);
    console.log(`- Removendo ${waiterSnapshot.size} garçons antigos...`);
    const deleteWaiters = waiterSnapshot.docs.map(d => deleteDoc(doc(db, 'users', d.id)));
    await Promise.all(deleteWaiters);
  } catch (e) {
    console.error(`Erro ao limpar garçons:`, e);
  }

  console.log('✅ Sistema limpo com sucesso! (Cardápio e Categorias intactos)');
  process.exit(0);
}

cleanup();
