const http = require('http');
const { execFile } = require('child_process');

/**
 * AGENTE DE IMPRESSÃO GDI - PetiscaPeixe
 * Adaptado do código de auditoria do usuário.
 * Usa System.Drawing para renderizar texto via driver do Windows.
 */

const PORT = 17321;

function escapeForPowerShell(text) {
  return String(text).replace(/'/g, "''");
}

function printTextGDI(printerName, text) {
  return new Promise((resolve, reject) => {
    const safePrinter = escapeForPowerShell(printerName);
    const safeText = escapeForPowerShell(text);

    // Script PowerShell para ignorar margens automáticas e usar a largura total do papel
    const psScript = `
$ErrorActionPreference = 'Stop'
try {
    Add-Type -AssemblyName System.Drawing
    $printerName = '${safePrinter}'
    $text = @'
${safeText}
'@

    $pd = New-Object System.Drawing.Printing.PrintDocument
    $pd.PrinterSettings.PrinterName = $printerName
    
    # IGNORA AS MARGENS DO DRIVER: Força o desenho a começar no ponto (0,0) físico
    $pd.OriginAtMargins = $false

    if (-not $pd.PrinterSettings.IsValid) {
        Write-Error "Impressora invalida: $printerName"
        exit 1
    }

    $handler = [System.Drawing.Printing.PrintPageEventHandler]{
        param($sender, $e)
        
        # Unidade de medida: Centésimos de polegada (Padrão Windows)
        # Fonte Consolas 10pt em 38 colunas ocupa aprox. 3 polegadas (76mm)
        $fontNormal = New-Object System.Drawing.Font("Consolas", 10)
        $fontLarge = New-Object System.Drawing.Font("Consolas", 16, [System.Drawing.FontStyle]::Bold)
        $brush = [System.Drawing.Brushes]::Black
        
        # Margem de segurança de 5px para não colar no canto físico esquerdo
        $y = 5
        $x = 5

        $lines = $text -split "\`r\`n|\`n"
        foreach ($line in $lines) {
            $currentFont = $fontNormal
            $cleanLine = $line
            
            if ($line.StartsWith("[BIG]")) {
                $currentFont = $fontLarge
                $cleanLine = $line.Substring(5)
            }

            if ($cleanLine.Trim().Length -gt 0 -or $line.Length -gt 0) {
                $e.Graphics.DrawString($cleanLine, $currentFont, $brush, $x, $y)
                $y += $currentFont.GetHeight($e.Graphics) + 1
            } else {
                $y += $fontNormal.GetHeight($e.Graphics)
            }
        }
    }

    $pd.add_PrintPage($handler)
    $pd.Print()
    Write-Output "OK"
} catch {
    Write-Error $_.Exception.Message
    exit 1
}
`;

    execFile(
      "powershell.exe",
      ["-NoProfile", "-ExecutionPolicy", "Bypass", "-Command", "& {" + psScript + "}"],
      { windowsHide: true, timeout: 15000 },
      (error, stdout, stderr) => {
        if (error) {
          const msg = stderr ? stderr.trim() : error.message;
          return reject(new Error(msg));
        }
        if (stderr && stderr.trim() && !stdout.includes("OK")) {
          if (!stderr.includes("DeprecationWarning") && !stderr.includes("punycode")) {
            return reject(new Error(stderr.trim()));
          }
        }
        resolve(stdout.trim() || "OK");
      }
    );
  });
}

const server = http.createServer((req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') { res.writeHead(200); res.end(); return; }
  
  if (req.method === 'GET' && req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ status: 'online', mode: 'GDI' }));
    return;
  }

  if (req.method === 'GET' && req.url === '/printers') {
    const psCommand = 'Get-Printer | Select-Object -ExpandProperty Name';
    execFile("powershell.exe", ["-NoProfile", "-Command", psCommand], (error, stdout) => {
      if (error) {
        res.writeHead(500);
        res.end(error.message);
        return;
      }
      const printers = stdout.split(/\r?\n/).filter(p => p.trim() !== '');
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(printers));
    });
    return;
  }

  if (req.method === 'POST' && req.url === '/print') {
    let body = '';
    req.on('data', chunk => { body += chunk.toString(); });
    req.on('end', async () => {
      try {
        const { printerName, text } = JSON.parse(body);
        if (!printerName) throw new Error("Nome da impressora nao fornecido.");
        await printTextGDI(printerName, text);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ status: 'success' }));
      } catch (e) {
        console.error("Erro no processamento:", e);
        res.writeHead(500, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: e instanceof Error ? e.message : "Erro interno no servidor" }));
      }
    });
    return;
  }
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`Agente GDI PetiscaPeixe rodando na porta ${PORT}`);
});
