/**
 * E-mails que recebem papel `admin` automaticamente no cliente.
 * A função `isBootstrapAdminEmail()` em `firestore.rules` deve listar os mesmos endereços
 * (Firestore Rules não importam módulos TypeScript).
 */
export const ADMIN_BOOTSTRAP_EMAILS = [
  'pedrohardsolu2025@gmail.com',
  'bsr.salvador2022@gmail.com',
  'harddisk1911@gmail.com',
  'petiscapeixe@gmail.com',
] as const;

export function isAdminBootstrapEmail(email: string | null | undefined): boolean {
  if (!email) return false;
  return (ADMIN_BOOTSTRAP_EMAILS as readonly string[]).includes(email);
}
