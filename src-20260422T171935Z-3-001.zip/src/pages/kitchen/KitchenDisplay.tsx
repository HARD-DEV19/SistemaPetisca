import { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, query, where, updateDoc, doc, orderBy, addDoc, limit, getDoc } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { CheckCircle, Clock, Printer, Utensils, XCircle } from 'lucide-react';
import { toast } from 'sonner';
import { printOrderWithFallback } from '../../lib/print';
import { isWithinWorkingHours } from '../../lib/utils';

export default function KitchenDisplay() {
  const [items, setItems] = useState<any[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = useRef(false);
  const [settings, setSettings] = useState<any>(null);

  useEffect(() => {
    const unsubSettings = onSnapshot(doc(db, 'settings', 'printAgent'), (snap) => {
      if (snap.exists()) setSettings(snap.data().config?.cozinha);
    });
    return () => unsubSettings();
  }, []);

  useEffect(() => {
    // Painel de Histórico: Mostra todos os itens de comida recentes (últimas 2 horas ou últimos 30 itens)
    // Para simplificar e garantir o histórico, vamos remover o filtro de status e limitar a quantidade.
    const q = query(
      collection(db, 'orderItems'),
      where('type', '==', 'food'),
      orderBy('createdAt', 'desc'),
      limit(30)
    );
    
    const unsub = onSnapshot(q, (snapshot) => {
      setItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    
    return () => unsub();
  }, []);

  const isOpen = settings ? isWithinWorkingHours(settings.openTime, settings.closeTime) : true;

  // Removida a função updateStatus para evitar cliques acidentais

  const handlePrint = async (item: any) => {
    if (isSubmittingRef.current) return;
    isSubmittingRef.current = true;
    setIsSubmitting(true);
    try {
      const printReq = {
        pedidoId: item.orderId?.slice(0, 8) || 'N/A',
        waiterName: item.waiterName || 'SISTEMA',
        itens: [{
          nome: item.productName,
          setor: 'cozinha',
          quantidade: item.quantity,
          preco: item.price || 0,
          observacao: item.notes
        }],
        imprimirCaixa: false,
        tipo: 'comanda',
        total: 0,
        mesa: item.tableNumber === 0 ? 'BAR' : (item.tableNumber?.toString() || '?')
      };

      // Criação do Job de impressão (Não afetado pela mudança visual)
      await addDoc(collection(db, 'printJobs'), {
        ...printReq,
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      
      toast.success('Re-imprimindo comanda...');
    } catch (error) {
      toast.error('Erro ao enviar para impressora');
    } finally {
      isSubmittingRef.current = false;
      setIsSubmitting(false);
    }
  };

  return (
    <div className="flex min-h-screen flex-col bg-blue-50 p-4 md:p-8 max-w-5xl mx-auto w-full font-sans">
      {!isOpen && (
        <div className="mb-6 flex items-center justify-center gap-3 bg-red-600 text-white p-4 rounded-2xl shadow-lg animate-pulse">
          <XCircle size={24} />
          <span className="font-black uppercase tracking-widest italic">Setor Fechado no Momento ({settings?.openTime} às {settings?.closeTime})</span>
        </div>
      )}

      <div className="mb-8 flex items-center justify-between bg-white p-6 rounded-3xl border border-blue-100 shadow-sm">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 flex items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg">
            <Utensils size={28} />
          </div>
          <div>
            <h1 className="text-2xl font-bold font-heading text-slate-900 tracking-tight">Cozinha</h1>
            <p className="text-sm font-medium text-slate-500 uppercase tracking-widest">Pedidos Recebidos</p>
          </div>
        </div>
        <div className="flex items-center gap-2 bg-blue-50 px-4 py-2 rounded-full border border-blue-100">
          <span className={`h-2 w-2 rounded-full ${isOpen ? 'bg-blue-600 animate-pulse' : 'bg-red-500'}`}></span>
          <span className="text-sm font-black text-blue-700">{items.length} ITENS</span>
        </div>
      </div>
      
      <div className="grid gap-4 grid-cols-1 sm:grid-cols-2 lg:grid-cols-2">
        {items.map(item => (
          <div key={item.id} className="flex flex-col rounded-[2rem] bg-white p-6 shadow-sm border border-slate-100 hover:shadow-md transition-all">
            <div className="mb-4 flex items-start justify-between">
              <div>
                <span className="inline-block rounded-full bg-slate-100 px-3 py-1 text-[10px] font-black uppercase tracking-widest text-slate-500 mb-3 border border-slate-200">
                  {item.tableNumber === 0 ? 'BAR' : `MESA ${item.tableNumber || '?'}`}
                </span>
                <p className="text-2xl font-black font-heading text-slate-900 leading-tight">
                  {item.quantity}x {item.productName}
                </p>
              </div>
              <div className="flex flex-col items-end gap-2">
                <span className="text-[10px] font-bold text-slate-400 bg-slate-50 px-2 py-1 rounded-lg border border-slate-100">
                  {new Date(item.createdAt).toLocaleTimeString('pt-BR', {hour: '2-digit', minute:'2-digit'})}
                </span>
                <button onClick={() => handlePrint(item)} className="rounded-xl p-2.5 text-slate-400 hover:bg-blue-50 hover:text-blue-600 transition-all border border-transparent hover:border-blue-100">
                  <Printer size={20} />
                </button>
              </div>
            </div>

            {item.notes && (
              <div className="mb-6 p-4 rounded-2xl bg-blue-50/50 border border-blue-100/50">
                <p className="text-xs font-black text-blue-400 uppercase tracking-widest mb-1">Observação:</p>
                <p className="text-sm font-bold text-blue-900">{item.notes.toUpperCase()}</p>
              </div>
            )}

            <div className={`mt-auto flex items-center justify-center gap-2 rounded-2xl py-4 font-black text-[10px] uppercase tracking-widest border-2 ${
              item.status === 'paid' ? 'bg-green-50 border-green-100 text-green-600' : 'bg-slate-50 border-slate-100 text-slate-400'
            }`}>
               {item.status === 'paid' ? 'ITEM PAGO NO CAIXA' : 'AGUARDANDO PAGAMENTO'}
            </div>
          </div>
        ))}

        {items.length === 0 && (
          <div className="col-span-full flex flex-col items-center justify-center py-20 bg-white rounded-[3rem] border border-dashed border-slate-200 text-slate-400">
            <CheckCircle size={64} className="mb-4 opacity-10" />
            <p className="font-bold text-lg">Tudo limpo por aqui!</p>
            <p className="text-sm">Aguardando novos pedidos...</p>
          </div>
        )}
      </div>
    </div>
  );
}
