import { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, query, where, addDoc, updateDoc, doc, getDocs, runTransaction, getDoc, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { useAuth, WAITER_SESSION_KEY } from '../../contexts/AuthContext';
import { Plus, Minus, ShoppingBag, ArrowLeft, CheckCircle, Clock, Utensils, Wine, LogOut, Printer, Search, X, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useNavigate } from 'react-router-dom';
import { isWithinWorkingHours } from '../../lib/utils';

export default function WaiterApp() {
  const { userData, logout, loading } = useAuth();
  const navigate = useNavigate();
  const [tables, setTables] = useState<any[]>([]);
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [selectedTable, setSelectedTable] = useState<any | null>(null);
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [cart, setCart] = useState<{product: any, quantity: number, notes: string}[]>([]);
  const [view, setView] = useState<'tables' | 'menu' | 'cart' | 'order'>('tables');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const isSubmittingRef = useRef(false);
  const [menuSearch, setMenuSearch] = useState('');
  const [settings, setSettings] = useState<any>(null);

  useEffect(() => {
    if (loading) return;
    if (!userData || userData.role !== 'waiter') {
      navigate('/waiter/login');
    }
  }, [loading, navigate, userData]);

  useEffect(() => {
    const unsubSettings = onSnapshot(doc(db, 'settings', 'printAgent'), (snap) => {
      if (snap.exists()) {
        setSettings(snap.data().config);
      }
    });
    const unsubTables = onSnapshot(collection(db, 'tables'), (snap) => {
      const data = snap.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setTables(data.sort((a, b) => {
        const priority = ['balcão', 'bar'];
        const isA = priority.includes((a.name || '').toLowerCase());
        const isB = priority.includes((b.name || '').toLowerCase());
        if (isA && !isB) return -1;
        if (!isA && isB) return 1;
        return (a.number || 0) - (b.number || 0);
      }));
    });
    const unsubProducts = onSnapshot(collection(db, 'products'), (snap) => {
      setProducts(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    const unsubCats = onSnapshot(query(collection(db, 'categories'), orderBy('order', 'asc')), (snap) => {
      setCategories(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => { unsubSettings(); unsubTables(); unsubProducts(); unsubCats(); };
  }, []);

  const currentTable = tables.find(t => t.id === selectedTable?.id) || null;
  const currentOrderId = currentTable?.currentOrderId;

  useEffect(() => {
    if (currentOrderId) {
      const q = query(collection(db, 'orderItems'), where('orderId', '==', currentOrderId));
      const unsubItems = onSnapshot(q, (snap) => {
        setOrderItems(snap.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      });
      return () => unsubItems();
    } else {
      setOrderItems([]);
    }
  }, [currentOrderId]);

  const addToCart = (product: any) => {
    if (!product) return;
    setCart(prev => {
      const existing = prev.find(item => item.product?.id === product.id);
      if (existing) return prev.map(item => item.product?.id === product.id ? { ...item, quantity: item.quantity + 1 } : item);
      return [...prev, { product, quantity: 1, notes: '' }];
    });
    toast.success(`${product.name} no carrinho`);
  };

  const updateCartQuantity = (productId: string, delta: number) => {
    setCart(prev => prev.map(item => {
      if (item.product?.id === productId) {
        const newQ = item.quantity + delta;
        return newQ > 0 ? { ...item, quantity: newQ } : item;
      }
      return item;
    }).filter(item => item.quantity > 0));
  };

  const sendOrder = async () => {
    if (cart.length === 0 || !currentTable || !userData || isSubmittingRef.current) return;

    // Validação de horário por setor
    if (settings) {
      for (const item of cart) {
        const sectorKey = item.product.category === 'food' ? 'cozinha' : 'bar';
        const config = settings[sectorKey];
        if (config && config.openTime && config.closeTime) {
          if (!isWithinWorkingHours(config.openTime, config.closeTime)) {
            toast.error(`Setor ${sectorKey.toUpperCase()} FECHADO (${config.openTime} às ${config.closeTime})`, {
              description: `O item "${item.product.name}" não pode ser enviado agora.`
            });
            return;
          }
        }
      }
    }

    isSubmittingRef.current = true; setIsSubmitting(true);
    try {
      let finalOrderId = currentOrderId;
      await runTransaction(db, async (tx) => {
        const tableRef = doc(db, 'tables', currentTable.id);
        const tableSnap = await tx.get(tableRef);
        let orderId = tableSnap.data()?.currentOrderId;
        
        if (!orderId) {
          const newOrderRef = doc(collection(db, 'orders'));
          orderId = newOrderRef.id;
          tx.set(newOrderRef, { tableId: currentTable.id, tableNumber: currentTable.number, tableName: currentTable.name || '', waiterId: userData.uid, waiterName: userData.name, status: 'open', total: 0, createdAt: new Date().toISOString() });
          tx.update(tableRef, { status: 'occupied', currentOrderId: orderId });
        }
        finalOrderId = orderId;

        for (const item of cart) {
          const itemRef = doc(collection(db, 'orderItems'));
          tx.set(itemRef, { orderId, tableId: currentTable.id, tableNumber: currentTable.number, productId: item.product.id, productName: item.product.name, quantity: item.quantity, price: item.product.price, status: 'pending', type: item.product.category, notes: item.notes, createdAt: new Date().toISOString() });
        }
      });

      await addDoc(collection(db, 'printJobs'), {
        pedidoId: finalOrderId?.slice(0, 8),
        waiterName: userData.name,
        itens: cart.map(i => ({ nome: i.product.name, setor: i.product.category, quantidade: i.quantity, preco: i.product.price, observacao: i.notes })),
        status: 'pending', tipo: 'comanda', mesa: currentTable.name || currentTable.number.toString(), createdAt: new Date().toISOString()
      });

      setCart([]); setView('tables'); setSelectedTable(null);
      toast.success('Pedido Enviado!');
    } catch (e: any) { toast.error(e.message); } finally { setIsSubmitting(false); isSubmittingRef.current = false; }
  };

  if (view === 'tables') {
    return (
      <div className="p-4 pb-24 md:p-8 max-w-5xl mx-auto min-h-screen bg-blue-50">
        <div className="mb-8 flex items-center justify-between bg-white p-6 rounded-[2rem] shadow-sm border border-blue-100">
          <div>
            <h1 className="text-3xl font-black font-heading text-slate-900 italic">Mesas</h1>
            <p className="text-sm font-bold text-blue-600 uppercase tracking-widest">Olá, {userData?.name}</p>
          </div>
          <button onClick={() => logout()} className="h-12 w-12 flex items-center justify-center rounded-2xl bg-slate-100 text-slate-400 hover:bg-red-50 hover:text-red-600 transition-all"><LogOut size={24} /></button>
        </div>
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5">
          {tables.map(table => (
            <button key={table.id} onClick={() => { setSelectedTable(table); setView('order'); }} className={`flex aspect-square flex-col items-center justify-center rounded-[2.5rem] border-2 transition-all active:scale-95 ${table.status === 'free' ? 'border-white bg-white text-slate-400 shadow-sm' : 'border-blue-500 bg-blue-600 text-white shadow-xl shadow-blue-600/20'}`}>
              <span className="text-3xl font-black font-heading italic text-center px-2">{table.name || table.number}</span>
              <span className="mt-2 text-[10px] font-black uppercase tracking-[0.2em]">{table.status === 'free' ? 'Livre' : 'Ocupada'}</span>
            </button>
          ))}
        </div>
      </div>
    );
  }

  if (view === 'order') {
    const unpaidTotal = orderItems.filter(i => i.status !== 'paid' && i.status !== 'cancelled').reduce((acc, i) => acc + (i.price * i.quantity), 0);
    return (
      <div className="flex h-screen flex-col bg-blue-50 font-sans">
        <div className="flex items-center justify-between bg-white p-4 shadow-sm z-10 border-b border-blue-100">
          <button onClick={() => { setView('tables'); setSelectedTable(null); }} className="flex items-center gap-2 text-slate-600 font-bold bg-slate-100 px-4 py-2 rounded-xl active:scale-95 transition-all"><ArrowLeft size={20} /> Mesas</button>
          <h2 className="text-xl font-black font-heading text-slate-900 uppercase italic">{currentTable?.name || `Mesa ${currentTable?.number}`}</h2>
          <button onClick={() => setView('menu')} className="bg-blue-600 text-white px-4 py-2 rounded-xl font-bold shadow-lg">Lançar</button>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {orderItems.length === 0 ? (
            <div className="flex h-full flex-col items-center justify-center text-slate-300 opacity-50"><Utensils size={64} /><p className="font-bold mt-4 italic">Mesa vazia</p></div>
          ) : (
            orderItems.map(item => (
              <div key={item.id} className="flex items-center justify-between rounded-3xl bg-white p-5 shadow-sm border border-blue-50">
                <div className="flex-1 min-w-0 pr-4">
                  <p className="font-black text-slate-900 text-lg leading-tight uppercase italic">{item.quantity}x {item.productName}</p>
                  {item.notes && <p className="text-[10px] text-blue-600 font-black mt-1 uppercase bg-blue-50 px-2 py-0.5 rounded-md inline-block">Obs: {item.notes}</p>}
                </div>
                <div className={`px-3 py-1 rounded-full text-[10px] font-black uppercase border ${item.status === 'ready' ? 'bg-green-100 text-green-700 border-green-200' : 'bg-blue-50 text-blue-600 border-blue-100'}`}>{item.status}</div>
              </div>
            ))
          )}
        </div>
        <div className="bg-white p-6 rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.05)] border-t border-blue-100">
          <div className="mb-6 flex items-center justify-between px-2">
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Total Parcial</span>
            <span className="text-3xl font-black font-heading text-blue-600 italic">R$ {unpaidTotal.toFixed(2)}</span>
          </div>
          <button onClick={() => setView('menu')} className="w-full bg-blue-600 py-5 rounded-[2rem] text-white font-black text-lg shadow-xl shadow-blue-600/30 active:scale-95 transition-all uppercase tracking-widest italic">Novo Pedido</button>
        </div>
      </div>
    );
  }

  if (view === 'menu') {
    const filteredProducts = products.filter(p => p.name.toLowerCase().includes(menuSearch.toLowerCase()));
    return (
      <div className="flex h-screen flex-col bg-blue-50 font-sans">
        <div className="bg-white border-b border-blue-100 z-10 shadow-sm">
          <div className="flex items-center justify-between p-4">
            <button onClick={() => { setView('order'); setMenuSearch(''); }} className="flex items-center gap-2 text-slate-600 font-bold bg-slate-100 px-4 py-2 rounded-xl"><ArrowLeft size={20} /> Voltar</button>
            <button onClick={() => setView('cart')} className="relative bg-slate-900 text-white p-3 rounded-2xl shadow-xl active:scale-95">
              <ShoppingBag size={24} />
              {cart.length > 0 && <span className="absolute -right-2 -top-2 flex h-7 w-7 items-center justify-center rounded-full bg-blue-600 text-xs font-black text-white border-4 border-white">{cart.reduce((a,b) => a + b.quantity, 0)}</span>}
            </button>
          </div>
          <div className="px-4 pb-4">
            <div className="relative">
              <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
              <input type="text" placeholder="Buscar no cardápio..." value={menuSearch} onChange={(e) => setMenuSearch(e.target.value)} className="w-full bg-slate-50 border border-slate-100 rounded-2xl py-4 pl-12 pr-10 font-bold outline-none focus:bg-white focus:border-blue-500 transition-all shadow-inner" />
              {menuSearch && <button onClick={() => setMenuSearch('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400 hover:text-slate-600"><X size={20}/></button>}
            </div>
          </div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-8 pb-20">
          {categories.map(cat => {
            const catProds = filteredProducts.filter(p => p.subCategory === cat.id);
            if (catProds.length === 0) return null;
            return (
              <div key={cat.id}>
                <h3 className="mb-4 text-xs font-black text-slate-400 uppercase tracking-[0.3em] ml-2 border-l-4 border-blue-600 pl-3">{cat.name}</h3>
                <div className="grid gap-3">
                  {catProds.map(product => (
                    <button key={product.id} onClick={() => addToCart(product)} className="flex items-center justify-between rounded-[2rem] bg-white p-4 shadow-sm border border-blue-50 active:bg-blue-50 transition-all text-left group">
                      <div className="flex-1 min-w-0">
                        <h4 className="font-black text-slate-900 text-base leading-tight uppercase italic">{product.name}</h4>
                        <p className="text-blue-600 font-black text-sm mt-1">R$ {product.price.toFixed(2)}</p>
                      </div>
                      <div className="h-10 w-10 flex items-center justify-center rounded-xl bg-blue-50 text-blue-600 group-active:scale-110 transition-transform"><Plus size={20} /></div>
                    </button>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    );
  }

  if (view === 'cart') {
    const total = cart.reduce((acc, item) => acc + (item.product?.price * item.quantity), 0);
    return (
      <div className="flex h-screen flex-col bg-blue-50 font-sans">
        <div className="flex items-center justify-between bg-white p-4 shadow-sm border-b border-blue-100">
          <button onClick={() => setView('menu')} className="flex items-center gap-2 text-slate-600 font-bold bg-slate-100 px-4 py-2 rounded-xl active:scale-95 transition-all"><ArrowLeft size={20} /> Voltar</button>
          <h2 className="text-xl font-black font-heading text-slate-900 uppercase italic text-center">Carrinho</h2>
          <div className="w-[88px]"></div>
        </div>
        <div className="flex-1 overflow-y-auto p-4 space-y-3">
          {cart.map((item, idx) => (
            <div key={idx} className="rounded-[2rem] bg-white p-5 shadow-sm border border-blue-50 space-y-4">
              <div className="flex justify-between items-start">
                <div className="flex-1 pr-4">
                  <p className="font-black text-slate-900 text-lg uppercase italic leading-tight">{item.product?.name}</p>
                  <button onClick={() => item.product && updateCartQuantity(item.product.id, -item.quantity)} className="mt-2 flex items-center gap-1 text-[10px] font-bold text-red-400 uppercase tracking-widest"><Trash2 size={12}/> Remover</button>
                </div>
                <p className="font-black text-blue-600">R$ {(item.product?.price * item.quantity).toFixed(2)}</p>
              </div>
              <div className="flex items-center justify-between gap-4">
                <div className="flex items-center gap-4 bg-slate-50 p-1.5 rounded-2xl border border-slate-100">
                  <button onClick={() => item.product && updateCartQuantity(item.product.id, -1)} className="h-10 w-10 flex items-center justify-center rounded-xl bg-white shadow-sm text-slate-400"><Minus size={18} /></button>
                  <span className="w-6 text-center font-black text-slate-900 text-lg">{item.quantity}</span>
                  <button onClick={() => item.product && updateCartQuantity(item.product.id, 1)} className="h-10 w-10 flex items-center justify-center rounded-xl bg-white shadow-sm text-blue-600"><Plus size={18} /></button>
                </div>
                <input type="text" placeholder="Obs..." value={item.notes} onChange={(e) => setCart(prev => prev.map((i, iidx) => iidx === idx ? { ...i, notes: e.target.value } : i))} className="flex-1 bg-slate-50 border border-slate-100 rounded-2xl p-3 text-sm font-bold outline-none focus:bg-white focus:border-blue-500 transition-all" />
              </div>
            </div>
          ))}
        </div>
        <div className="bg-white p-6 rounded-t-[3rem] shadow-[0_-10px_40px_rgba(0,0,0,0.05)] border-t border-blue-100">
          <div className="mb-6 flex items-center justify-between px-2">
            <span className="text-xs font-black text-slate-400 uppercase tracking-widest">Total a Enviar</span>
            <span className="text-3xl font-black font-heading text-blue-600 italic">R$ {total.toFixed(2)}</span>
          </div>
          <button onClick={sendOrder} disabled={isSubmitting || cart.length === 0} className="w-full bg-blue-600 py-5 rounded-[2rem] text-white font-black text-xl shadow-xl active:scale-95 transition-all uppercase italic disabled:opacity-50">Enviar Pedido</button>
        </div>
      </div>
    );
  }

  return null;
}
