import React, { useState } from 'react';
import { collection, getDocs } from 'firebase/firestore';
import { auth, db } from '../../lib/firebase';
import { signInAnonymously, signOut } from 'firebase/auth';
import { useNavigate } from 'react-router-dom';
import { Smartphone, ArrowRight } from 'lucide-react';
import { toast } from 'sonner';
import { WAITER_SESSION_KEY } from '../../contexts/AuthContext';

export default function WaiterLogin() {
  const [pin, setPin] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    if (pin.length < 4) return;

    setLoading(true);
    try {
      // 1. Limpa lixo de sessões anteriores agressivamente
      localStorage.removeItem(WAITER_SESSION_KEY);
      await signOut(auth).catch(() => undefined);

      // 2. Garante autenticação anônima limpa
      await signInAnonymously(auth);

      // 3. Busca todos os garçons
      const snapshot = await getDocs(collection(db, 'users'));
      const waiters = snapshot.docs
        .map(doc => ({ id: doc.id, ...doc.data() } as any))
        .filter(u => u.role === 'waiter');

      const found = waiters.find(w => String(w.pin) === String(pin));

      if (found) {
        const sessionData = {
          uid: found.id,
          name: found.name || 'Garçom',
          role: 'waiter' as const,
          createdAt: new Date().toISOString()
        };

        // Grava nova sessão
        localStorage.setItem(WAITER_SESSION_KEY, JSON.stringify(sessionData));
        toast.success(`Bem-vindo, ${sessionData.name}`);
        
        // Redirecionamento instantâneo
        window.location.href = '/waiter';
      } else {
        toast.error('PIN incorreto ou não cadastrado.');
        setPin('');
      }
    } catch (error: any) {
      console.error('Erro de conexão:', error);
      toast.error(`Erro ao conectar: ${error.message}`);
    } finally {
      setLoading(false);
    }
  };

  const addDigit = (digit: string) => { if (pin.length < 6) setPin(prev => prev + digit); };
  const removeDigit = () => { setPin(prev => prev.slice(0, -1)); };

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-blue-50 p-6 font-sans">
      <div className="w-full max-w-sm rounded-[2rem] bg-white p-8 shadow-xl border border-blue-100">
        <div className="mb-8 flex flex-col items-center text-center">
          <div className="mb-6 flex h-20 w-20 items-center justify-center overflow-hidden rounded-2xl bg-white shadow-lg shadow-blue-600/20 border border-blue-50">
            <img src="/logo.jpg" alt="Logo" className="h-full w-full object-cover" />
          </div>
          <h1 className="text-3xl font-bold font-heading tracking-tight text-slate-900 uppercase">PetiscaPeixe</h1>
          <p className="text-slate-500 font-medium mt-2">Digite seu PIN para entrar</p>
        </div>

        <div className="mb-10 flex justify-center gap-3">
          {[...Array(6)].map((_, i) => (
            <div key={i} className={`h-4 w-4 rounded-full border-2 transition-all duration-300 ${pin.length > i ? 'border-blue-600 bg-blue-600 scale-110' : 'border-slate-200 bg-transparent'}`} />
          ))}
        </div>

        <div className="grid grid-cols-3 gap-4">
          {['1', '2', '3', '4', '5', '6', '7', '8', '9'].map(digit => (
            <button key={digit} onClick={() => addDigit(digit)} className="flex h-16 items-center justify-center rounded-2xl bg-slate-50 text-2xl font-bold font-heading text-slate-700 hover:bg-slate-100 border border-slate-100 transition-all active:scale-95">{digit}</button>
          ))}
          <button onClick={removeDigit} className="flex h-16 items-center justify-center rounded-2xl bg-slate-50 text-lg font-bold text-slate-500 border border-slate-100 transition-all active:scale-95">Limpar</button>
          <button onClick={() => addDigit('0')} className="flex h-16 items-center justify-center rounded-2xl bg-slate-50 text-2xl font-bold font-heading text-slate-700 border border-slate-100 transition-all active:scale-95">0</button>
          <button onClick={handleLogin} disabled={pin.length < 4 || loading} className="flex h-16 items-center justify-center rounded-2xl bg-blue-600 text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all active:scale-95 disabled:opacity-50"><ArrowRight size={28} /></button>
        </div>
      </div>
    </div>
  );
}
