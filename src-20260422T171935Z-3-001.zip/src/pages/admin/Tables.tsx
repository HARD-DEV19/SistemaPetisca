import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, writeBatch, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, LayoutGrid, Coffee, Trash } from 'lucide-react';
import { toast } from 'sonner';

export default function Tables() {
  const [tables, setTables] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    number: '',
    name: '',
    status: 'free'
  });

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'tables'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      const sorted = data.sort((a, b) => {
        const priorityNames = ['balcão', 'bar'];
        const nameA = (a.name || '').toLowerCase();
        const nameB = (b.name || '').toLowerCase();
        const isPriorityA = priorityNames.includes(nameA);
        const isPriorityB = priorityNames.includes(nameB);
        if (isPriorityA && !isPriorityB) return -1;
        if (!isPriorityA && isPriorityB) return 1;
        return (a.number || 0) - (b.number || 0);
      });
      setTables(sorted);
    });
    return () => unsub();
  }, []);

  const handleClearAll = async () => {
    const password = prompt('ATENÇÃO: Isso excluirá TODAS as mesas. Digite a senha de segurança:');
    if (password === 'harddisk18458416') {
      try {
        const snapshot = await getDocs(collection(db, 'tables'));
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        toast.success('Módulo de mesas limpo.');
      } catch (e) { toast.error('Erro ao limpar.'); }
    } else if (password !== null) { toast.error('Senha incorreta.'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const tableNumber = parseInt(formData.number);
      const payload = {
        number: tableNumber || 0,
        name: formData.name,
        status: formData.status,
        updatedAt: new Date().toISOString()
      };
      if (editingId) {
        await updateDoc(doc(db, 'tables', editingId), payload);
        toast.success('Mesa atualizada!');
      } else {
        await addDoc(collection(db, 'tables'), { ...payload, createdAt: new Date().toISOString() });
        toast.success('Mesa criada!');
      }
      setIsModalOpen(false); setEditingId(null);
      setFormData({ number: '', name: '', status: 'free' });
    } catch (error: any) { toast.error(`Erro: ${error.message}`); }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading tracking-tight text-slate-900 flex items-center gap-2">
            <LayoutGrid className="text-blue-600" /> Gestão de Mesas
          </h1>
        </div>
        <div className="flex gap-2">
          <button onClick={handleClearAll} className="flex items-center gap-2 rounded-xl border border-red-200 bg-white px-5 py-2.5 text-sm font-bold text-red-600 hover:bg-red-50 transition-all"><Trash size={18}/> Limpar Tudo</button>
          <button onClick={() => { setFormData({ number: '', name: '', status: 'free' }); setEditingId(null); setIsModalOpen(true); }} className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white hover:bg-blue-700 shadow-md transition-all"><Plus size={20} /> Nova Mesa</button>
        </div>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 gap-4">
        {tables.map((table) => {
          const isSpecial = ['balcão', 'bar'].includes((table.name || '').toLowerCase());
          return (
            <div key={table.id} className={`relative group rounded-2xl border ${isSpecial ? 'border-blue-200 bg-blue-50/30' : 'border-slate-200 bg-white'} p-4 shadow-sm hover:border-blue-500 transition-all flex flex-col items-center justify-center aspect-square`}>
              <div className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity flex gap-1">
                <button onClick={() => { setFormData({ number: table.number.toString(), name: table.name || '', status: table.status }); setEditingId(table.id); setIsModalOpen(true); }} className="p-1.5 bg-white text-blue-600 rounded-lg border border-slate-100"><Edit size={14} /></button>
                <button onClick={async () => { if(confirm('Excluir?')) await deleteDoc(doc(db, 'tables', table.id)); }} className="p-1.5 bg-white text-blue-900 rounded-lg border border-slate-100"><Trash2 size={14} /></button>
              </div>
              {isSpecial ? <Coffee size={32} className="text-blue-600 mb-1 opacity-40" /> : <span className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Mesa</span>}
              <span className="text-3xl font-bold font-heading text-slate-900 mb-2">{table.name || table.number}</span>
              <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase ${table.status === 'free' ? 'bg-green-100 text-green-700' : 'bg-blue-100 text-blue-700'}`}>{table.status === 'free' ? 'Livre' : 'Ocupada'}</span>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-sm rounded-3xl bg-white p-6 shadow-2xl">
            <h2 className="mb-6 text-2xl font-bold font-heading text-slate-900">{editingId ? 'Editar' : 'Nova Mesa'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input type="text" placeholder="Nome (Balcão, Bar...)" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full rounded-xl border border-slate-200 p-3 outline-none" />
              <input required type="number" placeholder="Número" value={formData.number} onChange={e => setFormData({...formData, number: e.target.value})} className="w-full rounded-xl border border-slate-200 p-3 text-center text-xl font-bold outline-none" />
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 font-bold text-slate-600">Cancelar</button>
                <button type="submit" className="rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white shadow-lg">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
