import React, { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { QrCode, Smartphone, Globe, Download, Printer, Database, Settings as SettingsIcon, CheckCircle, XCircle, Clock, Trash2 } from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../../contexts/AuthContext';
import { collection, addDoc, getDocs, updateDoc, doc, setDoc, getDoc, query, where, onSnapshot, deleteDoc, writeBatch, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';

export default function Settings() {
  const { userData } = useAuth();
  const appUrl = window.location.origin;
  const waiterLoginUrl = `${appUrl}/waiter/login`;
  const customerMenuUrl = `${appUrl}/menu`;
  const [printerType, setPrinterType] = useState(() => localStorage.getItem('printerType') || '80mm');
  
  const [agentStatus, setAgentStatus] = useState<'checking' | 'online' | 'offline'>('checking');
  const [printers, setPrinters] = useState<string[]>([]);
  const [pendingJobs, setPendingJobs] = useState<any[]>([]);
  const agentUrl = 'http://localhost:17321';
  
  const [localConfig, setLocalConfig] = useState(() => ({
    cozinha: { printer: '', tipo: 'termica', largura: 80, openTime: '00:00', closeTime: '23:59' },
    bar: { printer: '', tipo: 'termica', largura: 80, openTime: '00:00', closeTime: '23:59' },
    caixa: { printer: '', tipo: 'termica', largura: 80 }
  }));
  const [enableAutoPrint, setEnableAutoPrint] = useState(() => localStorage.getItem('enableAutoPrint') === 'true');

  useEffect(() => {
    const loadConfig = async () => {
      try {
        const docSnap = await getDoc(doc(db, 'settings', 'printAgent'));
        if (docSnap.exists()) {
          const data = docSnap.data();
          if (data.config) setLocalConfig(prev => ({ ...prev, ...data.config }));
        }
      } catch (e) { console.error(e); }
    };
    loadConfig();
    checkAgentStatus();
    const interval = setInterval(checkAgentStatus, 5000);
    const q = query(collection(db, 'printJobs'), where('status', 'in', ['pending', 'failed']), orderBy('createdAt', 'desc'));
    const unsubJobs = onSnapshot(q, (snapshot) => {
      setPendingJobs(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => { clearInterval(interval); unsubJobs(); };
  }, []);

  useEffect(() => {
    localStorage.setItem('enableAutoPrint', enableAutoPrint.toString());
  }, [enableAutoPrint]);

  const checkAgentStatus = async () => {
    try {
      const res = await fetch(`${agentUrl}/health`);
      if (res.ok) {
        if (agentStatus !== 'online') { setAgentStatus('online'); fetchPrinters(); }
      } else { setAgentStatus('offline'); }
    } catch { setAgentStatus('offline'); }
  };

  const fetchPrinters = async () => {
    try {
      const res = await fetch(`${agentUrl}/printers`);
      if (res.ok) setPrinters(await res.json());
    } catch (e) { console.error(e); }
  };

  const saveLocalConfig = async (sector?: string) => {
    try {
      await setDoc(doc(db, 'settings', 'printAgent'), {
        config: localConfig,
        updatedAt: new Date().toISOString()
      });
      toast.success(sector ? `Configurações de ${sector} salvas!` : 'Configurações salvas!');
    } catch (e) { toast.error('Erro ao salvar no banco.'); }
  };

  const handleTestPrint = async (sector: string) => {
    const config = (localConfig as any)[sector];
    if (!config.printer) { toast.error('Selecione uma impressora.'); return; }
    try {
      const res = await fetch(`${agentUrl}/print`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ printerName: config.printer, text: `--- TESTE PETISCAPEIXE ---\r\nSetor: ${sector.toUpperCase()}\r\nStatus: OK\r\n\r\n\r\n\r\n\r\n\r\n` })
      });
      if (res.ok) toast.success(`Teste enviado.`);
      else throw new Error();
    } catch { toast.error('Erro no teste.'); }
  };

  const handleClearModule = async (moduleName: string, collectionName: string) => {
    const password = prompt(`ATENÇÃO: Isso excluirá TODOS os dados de ${moduleName}. Digite a senha:`);
    if (password === 'harddisk18458416') {
      try {
        const snapshot = await getDocs(collection(db, collectionName));
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        toast.success(`Módulo ${moduleName} limpo.`);
      } catch { toast.error('Erro ao limpar.'); }
    } else if (password !== null) { toast.error('Senha incorreta.'); }
  };

  const downloadQR = (id: string, filename: string) => {
    const svg = document.getElementById(id);
    if (!svg) return;
    const svgData = new XMLSerializer().serializeToString(svg);
    const canvas = document.createElement("canvas");
    const ctx = canvas.getContext("2d");
    const img = new Image();
    img.onload = () => {
      canvas.width = img.width; canvas.height = img.height;
      if (ctx) { ctx.fillStyle = "white"; ctx.fillRect(0, 0, canvas.width, canvas.height); ctx.drawImage(img, 0, 0); const pngFile = canvas.toDataURL("image/png"); const downloadLink = document.createElement("a"); downloadLink.download = `${filename}.png`; downloadLink.href = pngFile; downloadLink.click(); }
    };
    img.src = "data:image/svg+xml;base64," + btoa(unescape(encodeURIComponent(svgData)));
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 font-sans pb-20">
      <h1 className="text-2xl md:text-3xl font-bold font-heading text-slate-900">Configurações</h1>

      <div className="grid gap-6 md:gap-8 grid-cols-1 lg:grid-cols-2">
        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="mb-6 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600"><Smartphone size={24} /></div>
            <h2 className="text-xl font-bold font-heading text-slate-900">Acesso Garçom</h2>
          </div>
          <div className="flex flex-col items-center justify-center rounded-2xl bg-slate-50 p-6 border border-slate-100">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
              <QRCodeSVG id="waiter-qr" value={waiterLoginUrl} size={150} level="H" includeMargin />
            </div>
            <button onClick={() => downloadQR('waiter-qr', 'qr-garcom')} className="mt-5 flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 transition-all"><Download size={18} /> Baixar QR</button>
          </div>
        </div>

        <div className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm">
          <div className="mb-6 flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600"><Globe size={24} /></div>
            <h2 className="text-xl font-bold font-heading text-slate-900">Cardápio Digital</h2>
          </div>
          <div className="flex flex-col items-center justify-center rounded-2xl bg-slate-50 p-6 border border-slate-100">
            <div className="bg-white p-3 rounded-xl border border-slate-200 shadow-sm">
              <QRCodeSVG id="menu-qr" value={customerMenuUrl} size={150} level="H" includeMargin />
            </div>
            <button onClick={() => downloadQR('menu-qr', 'qr-cardapio')} className="mt-5 flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 transition-all"><Download size={18} /> Baixar QR</button>
          </div>
        </div>
      </div>

      {/* Agente de Impressão */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm">
        <div className="mb-6 flex items-center justify-between">
          <div className="flex items-center gap-4">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600"><Printer size={24} /></div>
            <h2 className="text-xl font-bold font-heading text-slate-900">Agente de Impressão</h2>
          </div>
          <label className="flex items-center gap-2 cursor-pointer bg-slate-100 px-4 py-2 rounded-xl border">
            <input type="checkbox" checked={enableAutoPrint} onChange={(e) => setEnableAutoPrint(e.target.checked)} className="h-5 w-5 text-blue-600" />
            <span className="text-sm font-bold text-slate-700">Auto-Print</span>
          </label>
        </div>

        {agentStatus === 'offline' ? (
          <div className="rounded-2xl bg-blue-50 p-6 border border-blue-200">
            <p className="text-sm font-medium text-blue-800 mb-4">Agente Offline. Execute o <strong>PrintAgent.exe</strong>.</p>
            <a href="/PrintAgent.exe" download className="inline-flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white"><Download size={18} /> Baixar Agente (.exe)</a>
          </div>
        ) : (
          <div className="grid gap-6 md:grid-cols-3">
            {['cozinha', 'bar', 'caixa'].map((s) => (
              <div key={s} className="rounded-2xl border border-slate-200 bg-slate-50 p-4">
                <div className="mb-3 flex items-center justify-between">
                  <h3 className="font-bold text-slate-900 capitalize">{s}</h3>
                  <button onClick={() => handleTestPrint(s)} className="text-[10px] font-bold text-blue-600 bg-blue-100 px-2 py-1 rounded">TESTE</button>
                </div>
                <select
                  value={(localConfig as any)[s].printer}
                  onChange={(e) => setLocalConfig(prev => ({ ...prev, [s]: { ...(prev as any)[s], printer: e.target.value } }))}
                  className="w-full rounded-xl border p-2.5 text-sm outline-none"
                >
                  <option value="">Selecionar...</option>
                  {printers.map(p => <option key={p} value={p}>{p}</option>)}
                </select>
                <button onClick={() => saveLocalConfig(s)} className="mt-3 w-full rounded-lg bg-blue-600 py-2 text-xs font-bold text-white">Salvar {s}</button>
              </div>
            ))}
          </div>
        )}

        {/* Print Queue */}
        <div className="mt-10 border-t pt-8">
          <h2 className="text-lg font-bold font-heading mb-4 flex items-center gap-2"><Clock size={20} /> Fila de Impressão</h2>
          {pendingJobs.length === 0 ? (
            <p className="text-sm text-slate-400 italic">Nenhum pedido pendente.</p>
          ) : (
            <div className="space-y-2">
              {pendingJobs.map(job => (
                <div key={job.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border text-xs">
                  <span className="font-bold">Mesa {job.mesa} - #{job.pedidoId?.slice(-4)}</span>
                  <div className="text-right">
                    <div className={job.status === 'failed' ? 'text-red-500 font-bold' : 'text-blue-600 animate-pulse'}>
                      {job.status === 'failed' ? 'Erro no Agente' : 'Processando...'}
                    </div>
                    {job.status === 'failed' && job.error && (
                      <div className="text-[10px] text-red-400 mt-0.5 max-w-[200px] truncate" title={job.error}>
                        {job.error}
                      </div>
                    )}
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      {/* Horários */}
      <div className="rounded-3xl border border-slate-200 bg-white p-6 md:p-8 shadow-sm">
        <h2 className="text-xl font-bold font-heading mb-6 flex items-center gap-2"><Clock /> Horários de Funcionamento</h2>
        <div className="grid gap-6 md:grid-cols-2">
          {['cozinha', 'bar'].map(s => (
            <div key={s} className="rounded-2xl border bg-slate-50 p-5">
              <h3 className="font-bold capitalize mb-4">{s}</h3>
              <div className="grid grid-cols-2 gap-4">
                <input type="time" value={(localConfig as any)[s].openTime} onChange={e => setLocalConfig(prev => ({ ...prev, [s]: { ...(prev as any)[s], openTime: e.target.value } }))} className="rounded-xl border p-3 font-bold" />
                <input type="time" value={(localConfig as any)[s].closeTime} onChange={e => setLocalConfig(prev => ({ ...prev, [s]: { ...(prev as any)[s], closeTime: e.target.value } }))} className="rounded-xl border p-3 font-bold" />
                <button onClick={() => saveLocalConfig(s)} className="col-span-full mt-2 rounded-xl bg-blue-600 py-3 font-bold text-white">Salvar Horários</button>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* Limpeza */}
      <div className="rounded-3xl border border-red-200 bg-red-50 p-6 md:p-8">
        <h2 className="text-xl font-bold text-red-900 mb-6 flex items-center gap-2"><Trash2 /> Limpeza de Dados</h2>
        <div className="grid gap-4 sm:grid-cols-3">
          <button onClick={() => handleClearModule('Pedidos', 'orders')} className="rounded-xl bg-white border border-red-200 p-4 text-xs font-bold text-red-600">Limpar Pedidos</button>
          <button onClick={() => handleClearModule('Fila', 'printJobs')} className="rounded-xl bg-white border border-red-200 p-4 text-xs font-bold text-red-600">Limpar Impressões</button>
          <button onClick={() => handleClearModule('Financeiro', 'transactions')} className="rounded-xl bg-white border border-red-200 p-4 text-xs font-bold text-red-600">Limpar Financeiro</button>
        </div>
      </div>
    </div>
  );
}
