import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, where, addDoc, updateDoc, doc, deleteDoc, writeBatch, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, UserCheck, Key, Trash } from 'lucide-react';
import { toast } from 'sonner';

export default function Waiters() {
  const [waiters, setWaiters] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    name: '',
    pin: ''
  });

  useEffect(() => {
    const q = query(collection(db, 'users'), where('role', '==', 'waiter'));
    const unsub = onSnapshot(q, (snapshot) => {
      setWaiters(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    });
    return () => unsub();
  }, []);

  const handleClearAll = async () => {
    const password = prompt('ATENÇÃO: Isso excluirá TODOS os garçons. Digite a senha de segurança:');
    if (password === 'harddisk18458416') {
      try {
        const q = query(collection(db, 'users'), where('role', '==', 'waiter'));
        const snapshot = await getDocs(q);
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        toast.success('Todos os garçons foram removidos.');
      } catch (e) { toast.error('Erro ao limpar módulo.'); }
    } else if (password !== null) { toast.error('Senha incorreta.'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      if (editingId) {
        await updateDoc(doc(db, 'users', editingId), formData);
        toast.success('Garçom atualizado!');
      } else {
        await addDoc(collection(db, 'users'), {
          ...formData,
          role: 'waiter',
          uid: `waiter_${Date.now()}`,
          createdAt: new Date().toISOString()
        });
        toast.success('Garçom criado!');
      }
      setIsModalOpen(false); setEditingId(null);
      setFormData({ name: '', pin: '' });
    } catch (error) { toast.error('Erro ao salvar garçom'); }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl md:text-3xl font-bold font-heading tracking-tight text-slate-900">Gerenciar Garçons</h1>
        <div className="flex gap-2">
          <button onClick={handleClearAll} className="flex items-center gap-2 rounded-xl border border-red-200 bg-white px-5 py-2.5 text-sm font-bold text-red-600 hover:bg-red-50 transition-all"><Trash size={18}/> Limpar Tudo</button>
          <button onClick={() => setIsModalOpen(true)} className="flex items-center justify-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white hover:bg-blue-700 shadow-md transition-all active:scale-95"><Plus size={20} /> Novo Garçom</button>
        </div>
      </div>

      <div className="grid gap-4 md:gap-6 grid-cols-1 sm:grid-cols-2 lg:grid-cols-3">
        {waiters.map((waiter) => (
          <div key={waiter.id} className="rounded-3xl border border-slate-200 bg-white p-6 shadow-sm hover:shadow-md transition-shadow">
            <div className="mb-4 flex items-center justify-between">
              <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-blue-50 text-blue-600 border border-blue-100">
                <UserCheck size={24} />
              </div>
              <div className="flex gap-2">
                <button onClick={() => { setFormData({ name: waiter.name, pin: waiter.pin }); setEditingId(waiter.id); setIsModalOpen(true); }} className="rounded-xl p-2 text-blue-600 hover:bg-blue-50 transition-colors"><Edit size={18} /></button>
                <button onClick={async () => { if(confirm('Excluir?')) await deleteDoc(doc(db, 'users', waiter.id)); }} className="rounded-xl p-2 text-blue-900 hover:bg-red-50 transition-colors"><Trash2 size={18} /></button>
              </div>
            </div>
            <h3 className="text-xl font-bold font-heading text-slate-900">{waiter.name}</h3>
            <div className="mt-5 flex items-center gap-2 rounded-xl bg-slate-50 p-3 text-sm font-bold text-slate-700 border border-slate-100">
              <Key size={16} className="text-slate-400" />
              PIN: <span className="font-mono text-blue-600 tracking-wider">{waiter.pin || 'N/A'}</span>
            </div>
          </div>
        ))}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl border border-slate-200">
            <h2 className="mb-6 text-2xl font-bold font-heading text-slate-900">{editingId ? 'Editar Garçom' : 'Novo Garçom'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input required type="text" placeholder="Nome Completo" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full rounded-xl border border-slate-200 p-3 outline-none" />
              <input type="text" maxLength={6} required placeholder="PIN (4-6 dígitos)" value={formData.pin} onChange={e => setFormData({...formData, pin: e.target.value.replace(/\D/g, '')})} className="w-full rounded-xl border border-slate-200 p-3 text-center text-2xl font-bold outline-none" />
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 font-bold text-slate-600">Cancelar</button>
                <button type="submit" className="rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white shadow-md">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
