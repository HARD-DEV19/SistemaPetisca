import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, where, getDocs, writeBatch, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { uploadProductImage, deleteProductImageIfStored, validateImageFile } from '../../lib/storageUpload';
import { Plus, Edit, Trash2, UtensilsCrossed, Upload, Trash, Tag, ChevronDown, Download, Search, X } from 'lucide-react';
import { toast } from 'sonner';

export default function Menu() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [isCatModalOpen, setIsCatModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);
  const [search, setSearch] = useState('');
  
  const [formData, setFormData] = useState({
    name: '',
    description: '',
    category: 'food',
    subCategory: '',
    price: 0,
    isComposite: false,
    imageUrl: ''
  });

  const [catFormData, setCatFormData] = useState({
    name: '',
    type: 'food',
    order: 0
  });

  const [imageFile, setImageFile] = useState<File | null>(null);
  const [previewObjectUrl, setPreviewObjectUrl] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    if (!imageFile) { setPreviewObjectUrl(null); return; }
    const u = URL.createObjectURL(imageFile);
    setPreviewObjectUrl(u);
    return () => URL.revokeObjectURL(u);
  }, [imageFile]);

  useEffect(() => {
    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      const all = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setProducts(all.filter(p => p.category === 'food' || p.category === 'drink'));
    });
    const unsubCats = onSnapshot(query(collection(db, 'categories'), orderBy('order', 'asc')), (snapshot) => {
      setCategories(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
    });
    return () => { unsubProducts(); unsubCats(); };
  }, []);

  const handleImportOfficialMenu = async () => {
    const password = prompt('Isso apagará o cardápio e criará as categorias. Digite a senha:');
    if (password !== 'harddisk18458416') {
      if (password !== null) toast.error('Senha incorreta.');
      return;
    }
    setIsSaving(true);
    try {
      const batch = writeBatch(db);
      const pSnap = await getDocs(collection(db, 'products'));
      pSnap.docs.forEach(d => { if(d.data().category === 'food' || d.data().category === 'drink') batch.delete(d.ref); });
      const cSnap = await getDocs(collection(db, 'categories'));
      cSnap.docs.forEach(d => batch.delete(d.ref));
      await batch.commit();

      const menuData = {
        categories: [
          { name: 'Porções Tradicionais', type: 'food', order: 1 },
          { name: 'Porções de Peixes', type: 'food', order: 2 },
          { name: 'Pratos Individuais', type: 'food', order: 3 },
          { name: 'Porções Extras', type: 'food', order: 4 },
          { name: 'Chopp', type: 'drink', order: 5 },
          { name: 'Cervejas (Unidade)', type: 'drink', order: 6 },
          { name: 'Baldinho de Cerveja', type: 'drink', order: 7 },
          { name: 'Bebidas Não Alcoólicas', type: 'drink', order: 8 },
          { name: 'Sucos Naturais', type: 'drink', order: 9 },
          { name: 'Sucos de Polpa', type: 'drink', order: 10 },
        ],
        products: [
          { name: 'Costelinha de porco (600g)', price: 44.99, cat: 'Porções Tradicionais', type: 'food' },
          { name: 'Frango a passarinho (600g)', price: 35.99, cat: 'Porções Tradicionais', type: 'food' },
          { name: 'Coxinha da asa (600g)', price: 37.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Empanada' },
          { name: 'Picanha (400g)', price: 69.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha mandioca frita' },
          { name: 'Carne de Sol (400g)', price: 59.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha mandioca frita' },
          { name: 'Filé mignon (400g)', price: 64.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha batata ou mandioca frita' },
          { name: 'Batata Frita (400g)', price: 19.99, cat: 'Porções Tradicionais', type: 'food' },
          { name: 'Calabresa (400g)', price: 35.99, cat: 'Porções Tradicionais', type: 'food', desc: 'Acompanha batata ou mandioca frita' },
          { name: 'Mandioca Frita (400g)', price: 15.99, cat: 'Porções Tradicionais', type: 'food' },
          { name: 'Torresmo (400g)', price: 19.99, cat: 'Porções Tradicionais', type: 'food' },
          { name: 'Filé de Tilápia a Palito (400g)', price: 59.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
          { name: 'Posta de Tilápia (500g)', price: 55.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
          { name: 'Costelinha de Tilápia (500g)', price: 50.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
          { name: 'Costelinha de Tambaqui (500g)', price: 52.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha farofa e vinagrete' },
          { name: 'Camarão Alho e Óleo (400g)', price: 64.99, cat: 'Porções de Peixes', type: 'food' },
          { name: 'Camarão Empanado (400g)', price: 79.99, cat: 'Porções de Peixes', type: 'food' },
          { name: 'Manjubinha frita (500g)', price: 39.99, cat: 'Porções de Peixes', type: 'food', desc: 'Acompanha batata frita' },
          { name: 'Moqueca de Peixe', price: 119.99, cat: 'Porções de Peixes', type: 'food', desc: 'Serve 2 a 3 pessoas. Acompanha arroz e pirão' },
          { name: 'Filé de Peixe Grelhado', price: 24.00, cat: 'Pratos Individuais', type: 'food', desc: 'Acompanha arroz e salada' },
          { name: 'Filé de Peixe Empanado', price: 28.00, cat: 'Pratos Individuais', type: 'food', desc: 'Acompanha arroz e batata frita' },
          { name: 'Arroz', price: 4.99, cat: 'Porções Extras', type: 'food' },
          { name: 'Vinagrete', price: 4.99, cat: 'Porções Extras', type: 'food' },
          { name: 'Farofa', price: 4.99, cat: 'Porções Extras', type: 'food' },
          { name: 'Chopp 300ml', price: 6.99, cat: 'Chopp', type: 'drink' },
          { name: 'Long Neck Heineken', price: 9.00, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Long Neck Heineken 0', price: 9.00, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Long Neck Stella Artois', price: 8.00, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Long Neck Budweiser', price: 8.00, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Cerveja Lata Brahma', price: 3.99, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Cerveja Lata Antarctica', price: 3.99, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Cerveja Lata Amstel', price: 3.99, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Cerveja Lata Skol', price: 3.99, cat: 'Cervejas (Unidade)', type: 'drink' },
          { name: 'Baldinho Heineken (4un)', price: 40.00, cat: 'Baldinho de Cerveja', type: 'drink' },
          { name: 'Baldinho Stella/Bud (4un)', price: 36.00, cat: 'Baldinho de Cerveja', type: 'drink' },
          { name: 'Baldinho Lata (6un)', price: 26.00, cat: 'Baldinho de Cerveja', type: 'drink' },
          { name: 'Água sem gás', price: 2.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Água com gás', price: 4.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Coca-Cola Lata', price: 3.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Guaraná Lata', price: 3.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Fanta Lata', price: 3.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Sprite Lata', price: 3.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'H2O Limão', price: 6.99, cat: 'Bebidas Não Alcoólicas', type: 'drink' },
          { name: 'Suco de Laranja (Copo 300ml)', price: 7.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Laranja (Jarra 750ml)', price: 18.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Laranja (Jarra 1,5L)', price: 35.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Limão (Copo 300ml)', price: 7.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Limão (Jarra 750ml)', price: 18.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Limão (Jarra 1,5L)', price: 35.99, cat: 'Sucos Naturais', type: 'drink' },
          { name: 'Suco de Maracujá (Copo 300ml)', price: 6.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Maracujá (Jarra 750ml)', price: 15.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Maracujá (Jarra 1,5L)', price: 28.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Abacaxi (Copo 300ml)', price: 6.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Abacaxi (Jarra 750ml)', price: 15.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Abacaxi (Jarra 1,5L)', price: 28.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Goiaba (Copo 300ml)', price: 6.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Goiaba (Jarra 750ml)', price: 15.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Goiaba (Jarra 1,5L)', price: 28.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Caju (Copo 300ml)', price: 6.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Caju (Jarra 750ml)', price: 15.99, cat: 'Sucos de Polpa', type: 'drink' },
          { name: 'Suco de Caju (Jarra 1,5L)', price: 28.99, cat: 'Sucos de Polpa', type: 'drink' },
        ]
      };
      const catIds: Record<string, string> = {};
      for (const cat of menuData.categories) {
        const ref = await addDoc(collection(db, 'categories'), { ...cat, createdAt: new Date().toISOString() });
        catIds[cat.name] = ref.id;
      }
      for (const prod of menuData.products) {
        await addDoc(collection(db, 'products'), {
          name: prod.name, description: prod.desc || '', category: prod.type, subCategory: catIds[prod.cat], price: prod.price,
          unit: 'un', cost: 0, stock: 999, minStock: 0, isComposite: false, imageUrl: '', createdAt: new Date().toISOString()
        });
      }
      toast.success('Cardápio Oficial Importado!');
    } catch (e) { toast.error('Erro na importação.'); } finally { setIsSaving(false); }
  };

  const handleSaveCategory = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      await addDoc(collection(db, 'categories'), { ...catFormData, createdAt: new Date().toISOString() });
      toast.success('Categoria criada!');
      setIsCatModalOpen(false);
      setCatFormData({ name: '', type: 'food', order: categories.length });
    } catch (e) { toast.error('Erro ao salvar categoria.'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSaving(true);
    try {
      const core: any = {
        name: formData.name, description: formData.description,
        category: formData.category, subCategory: formData.subCategory,
        price: Number(formData.price), isComposite: formData.isComposite,
        ingredientList: []
      };
      if (!imageFile) core.imageUrl = formData.imageUrl;
      let productId = editingId;
      if (editingId) {
        await updateDoc(doc(db, 'products', editingId), core);
      } else {
        const docRef = await addDoc(collection(db, 'products'), {
          ...core, unit: 'un', cost: 0, stock: 999, minStock: 0, createdAt: new Date().toISOString()
        });
        productId = docRef.id;
      }
      if (imageFile && productId) {
        const url = await uploadProductImage(productId, imageFile);
        await updateDoc(doc(db, 'products', productId), { imageUrl: url });
      }
      setIsModalOpen(false); setEditingId(null); setImageFile(null);
      setFormData({ name: '', description: '', category: 'food', subCategory: '', price: 0, isComposite: false, imageUrl: '' });
      toast.success('Salvo!');
    } catch (e) { toast.error('Erro ao salvar.'); } finally { setIsSaving(false); }
  };

  const filteredProducts = products.filter(p => p.name.toLowerCase().includes(search.toLowerCase()));

  const handleDeleteProduct = async (id: string, imageUrl?: string) => {
    if (!window.confirm('Tem certeza que deseja excluir este item?')) return;
    try {
      if (imageUrl) await deleteProductImageIfStored(imageUrl);
      await deleteDoc(doc(db, 'products', id));
      toast.success('Item excluído!');
    } catch (e) {
      toast.error('Erro ao excluir item.');
    }
  };

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 font-sans">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading text-slate-900 flex items-center gap-2">
            <UtensilsCrossed className="text-blue-600" /> Cardápio
          </h1>
          <p className="text-slate-500 mt-1 font-medium">Gerencie seus pratos e bebidas.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={handleImportOfficialMenu} className="flex items-center gap-2 rounded-xl bg-blue-900 px-4 py-2 text-xs font-bold text-white hover:bg-slate-800 transition-all shadow-md active:scale-95"><Download size={16}/> Importar Oficial</button>
          <button onClick={() => setIsCatModalOpen(true)} className="flex items-center gap-2 rounded-xl border border-blue-200 bg-white px-4 py-2 text-xs font-bold text-blue-600 hover:bg-blue-50 transition-all"><Tag size={16}/> Categorias</button>
          <button onClick={() => { setEditingId(null); setIsModalOpen(true); }} className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 text-sm font-bold text-white hover:bg-blue-700 shadow-md transition-all active:scale-95"><Plus size={18} /> Novo Item</button>
        </div>
      </div>

      {/* Barra de Pesquisa */}
      <div className="relative">
        <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
        <input 
          type="text" 
          placeholder="Pesquisar no cardápio..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full rounded-2xl border border-slate-200 bg-white py-4 pl-12 pr-4 text-sm font-bold outline-none focus:border-blue-500 transition-all shadow-sm"
        />
        {search && <button onClick={() => setSearch('')} className="absolute right-4 top-1/2 -translate-y-1/2 text-slate-400"><X size={20}/></button>}
      </div>

      <div className="grid gap-8">
        {categories.map(cat => {
          const catProducts = filteredProducts.filter(p => p.subCategory === cat.id);
          if (catProducts.length === 0) return null;
          return (
            <div key={cat.id} className="space-y-4">
              <h2 className="text-sm font-black font-heading uppercase tracking-[0.2em] text-slate-400 flex items-center gap-3">
                {cat.name} <div className="h-[1px] flex-1 bg-slate-100"></div>
              </h2>
              <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
                {catProducts.map(p => (
                  <div key={p.id} className="rounded-3xl border border-slate-200 bg-white p-4 shadow-sm flex gap-4 items-center group hover:border-blue-200 transition-all">
                    {p.imageUrl ? <img src={p.imageUrl} className="w-16 h-16 rounded-2xl object-cover border" /> : <div className="w-16 h-16 rounded-2xl bg-slate-100 flex items-center justify-center border text-slate-300 group-hover:bg-blue-50 transition-all"><UtensilsCrossed size={24} /></div>}
                    <div className="flex-1 min-w-0">
                      <h3 className="font-bold text-slate-900 truncate">{p.name}</h3>
                      <p className="text-blue-600 font-black text-sm">R$ {p.price.toFixed(2)}</p>
                    </div>
                    <div className="flex gap-1">
                      <button onClick={() => { setFormData({...p}); setEditingId(p.id); setIsModalOpen(true); }} className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-all"><Edit size={18} /></button>
                      <button onClick={() => handleDeleteProduct(p.id, p.imageUrl)} className="p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={18} /></button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4 overflow-y-auto">
          <div className="w-full max-w-md rounded-[2.5rem] bg-white p-8 shadow-2xl my-8">
            <h2 className="mb-6 text-2xl font-black font-heading text-slate-900">{editingId ? 'Editar' : 'Novo Item'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input required placeholder="Nome do Prato" type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full rounded-2xl border p-4 font-bold outline-none focus:border-blue-500" />
              <textarea placeholder="Descrição" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full rounded-2xl border p-4 text-sm outline-none" rows={2} />
              <div className="grid grid-cols-2 gap-4">
                <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full rounded-2xl border p-4 font-bold outline-none">
                  <option value="food">Comida</option><option value="drink">Bebida</option>
                </select>
                <select required value={formData.subCategory} onChange={e => setFormData({...formData, subCategory: e.target.value})} className="w-full rounded-2xl border p-4 font-bold outline-none border-blue-200 bg-blue-50/30">
                  <option value="">Categoria...</option>
                  {categories.filter(c => c.type === formData.category).map(c => <option key={c.id} value={c.id}>{c.name}</option>)}
                </select>
              </div>
              <input required type="number" step="0.01" value={formData.price} onChange={e => setFormData({...formData, price: parseFloat(e.target.value)})} className="w-full rounded-2xl border p-4 font-black text-xl text-blue-600 outline-none" />
              <div onClick={() => fileInputRef.current?.click()} className="h-32 w-full cursor-pointer rounded-2xl border-2 border-dashed flex flex-col items-center justify-center hover:bg-slate-50 transition-all overflow-hidden border-slate-200">
                {previewObjectUrl || formData.imageUrl ? <img src={previewObjectUrl || formData.imageUrl} className="h-full w-full object-cover" /> : <Upload className="text-slate-300" />}
              </div>
              <input type="file" ref={fileInputRef} className="hidden" accept="image/*" onChange={e => { const f = e.target.files?.[0]; if(f) setImageFile(f); }} />
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-6 py-3 font-bold text-slate-400">Cancelar</button>
                <button type="submit" disabled={isSaving} className="rounded-2xl bg-blue-600 px-8 py-3 font-black text-white shadow-lg active:scale-95 transition-all">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}

      {isCatModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-[2.5rem] bg-white p-8 shadow-2xl">
            <h2 className="text-2xl font-black font-heading text-slate-900 mb-6 uppercase italic">Categorias</h2>
            <form onSubmit={handleSaveCategory} className="flex gap-2 mb-6">
              <input required placeholder="Nova Categoria..." type="text" value={catFormData.name} onChange={e => setCatFormData({...catFormData, name: e.target.value})} className="flex-1 rounded-xl border p-3 text-sm outline-none" />
              <button type="submit" className="bg-blue-600 text-white p-3 rounded-xl shadow-md"><Plus size={20}/></button>
            </form>
            <div className="max-h-[300px] overflow-y-auto space-y-2 pr-2">
              {categories.map(cat => (
                <div key={cat.id} className="flex items-center justify-between p-3 bg-slate-50 rounded-xl border border-slate-100">
                  <span className="font-bold text-slate-700 text-sm uppercase">{cat.name}</span>
                  <button onClick={async () => await deleteDoc(doc(db, 'categories', cat.id))} className="text-slate-300 hover:text-red-500"><Trash2 size={16} /></button>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
