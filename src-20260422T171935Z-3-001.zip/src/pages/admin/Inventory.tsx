import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, where, getDocs, writeBatch } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, Package, AlertTriangle, RefreshCw, Trash } from 'lucide-react';
import { toast } from 'sonner';

export default function Inventory() {
  const [products, setProducts] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [activeTab, setActiveTab] = useState<'insumos' | 'cardapio' | 'low_stock'>('insumos');
  const [formData, setFormData] = useState({
    name: '',
    category: 'ingredient',
    unit: 'un',
    cost: 0,
    price: 0,
    stock: 0,
    minStock: 0
  });

  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
    });
    return () => unsub();
  }, []);

  const handleClearAll = async () => {
    const password = prompt('ATENÇÃO: Isso excluirá TODO o estoque e insumos. Digite a senha de segurança:');
    if (password === 'harddisk18458416') {
      try {
        const q = query(collection(db, 'products'), where('category', 'in', ['ingredient', 'supply']));
        const snapshot = await getDocs(q);
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        toast.success('Estoque limpo.');
      } catch (e) { toast.error('Erro ao limpar.'); }
    } else if (password !== null) { toast.error('Senha incorreta.'); }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = { ...formData, updatedAt: new Date().toISOString() };
      if (editingId) { await updateDoc(doc(db, 'products', editingId), payload); }
      else { await addDoc(collection(db, 'products'), { ...payload, createdAt: new Date().toISOString() }); }
      setIsModalOpen(false); setEditingId(null);
      toast.success('Produto salvo.');
    } catch (e) { toast.error('Erro ao salvar.'); }
  };

  const insumos = products.filter(p => p.category === 'ingredient' || p.category === 'supply');
  const cardapio = products.filter(p => p.category === 'food' || p.category === 'drink');
  const lowStock = products.filter(p => p.stock <= p.minStock);

  const currentList = activeTab === 'insumos' ? insumos : activeTab === 'cardapio' ? cardapio : lowStock;

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto">
      <div className="mb-8 flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <h1 className="text-2xl md:text-3xl font-bold font-heading text-slate-900 flex items-center gap-2"><Package className="text-blue-600" /> Estoque</h1>
        <div className="flex gap-2">
          <button onClick={handleClearAll} className="flex items-center gap-2 rounded-xl border border-red-200 bg-white px-5 py-2.5 text-sm font-bold text-red-600 hover:bg-red-50 transition-all"><Trash size={18}/> Limpar Tudo</button>
          <button onClick={() => { setFormData({ name: '', category: 'ingredient', unit: 'un', cost: 0, price: 0, stock: 0, minStock: 0 }); setEditingId(null); setIsModalOpen(true); }} className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white shadow-md hover:bg-blue-700 transition-all"><Plus size={20} /> Novo Item</button>
        </div>
      </div>

      <div className="flex mb-6 rounded-xl bg-slate-100 p-1 border w-fit">
        <button onClick={() => setActiveTab('insumos')} className={`px-4 py-2 rounded-lg text-sm font-bold ${activeTab === 'insumos' ? 'bg-white shadow-sm' : 'text-slate-500'}`}>Insumos</button>
        <button onClick={() => setActiveTab('cardapio')} className={`px-4 py-2 rounded-lg text-sm font-bold ${activeTab === 'cardapio' ? 'bg-white shadow-sm' : 'text-slate-500'}`}>Cardápio</button>
        <button onClick={() => setActiveTab('low_stock')} className={`px-4 py-2 rounded-lg text-sm font-bold ${activeTab === 'low_stock' ? 'bg-white shadow-sm' : 'text-slate-500'}`}>Estoque Baixo</button>
      </div>

      <div className="overflow-hidden rounded-2xl border border-slate-200 bg-white shadow-sm">
        <table className="w-full text-left text-sm">
          <thead className="bg-slate-50 border-b">
            <tr><th className="px-6 py-4">Nome</th><th className="px-6 py-4">Estoque</th><th className="px-6 py-4">Mínimo</th><th className="px-6 py-4 text-right">Ações</th></tr>
          </thead>
          <tbody className="divide-y">
            {currentList.map(p => (
              <tr key={p.id} className="hover:bg-slate-50/50">
                <td className="px-6 py-4 font-bold">{p.name}</td>
                <td className="px-6 py-4">{p.stock} {p.unit}</td>
                <td className="px-6 py-4 text-red-500 font-medium">{p.minStock} {p.unit}</td>
                <td className="px-6 py-4 text-right">
                  <button onClick={() => { setFormData({...p}); setEditingId(p.id); setIsModalOpen(true); }} className="mr-3 text-blue-600"><Edit size={18} /></button>
                  <button onClick={async () => { if(confirm('Excluir?')) await deleteDoc(doc(db, 'products', p.id)); }} className="text-blue-900"><Trash2 size={18} /></button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-3xl bg-white p-6 shadow-2xl">
            <h2 className="mb-6 text-2xl font-bold font-heading text-slate-900">{editingId ? 'Editar' : 'Novo Item'}</h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <input required placeholder="Nome" type="text" value={formData.name} onChange={e => setFormData({...formData, name: e.target.value})} className="w-full rounded-xl border p-3 outline-none" />
              <div className="grid grid-cols-2 gap-4">
                <select value={formData.category} onChange={e => setFormData({...formData, category: e.target.value})} className="w-full rounded-xl border p-3 outline-none">
                  <option value="ingredient">Ingrediente</option><option value="supply">Suprimento</option><option value="food">Comida</option><option value="drink">Bebida</option>
                </select>
                <input placeholder="Unidade (kg, un, lt)" type="text" value={formData.unit} onChange={e => setFormData({...formData, unit: e.target.value})} className="w-full rounded-xl border p-3 outline-none" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <input type="number" placeholder="Estoque Atual" value={formData.stock} onChange={e => setFormData({...formData, stock: parseFloat(e.target.value)})} className="w-full rounded-xl border p-3 outline-none" />
                <input type="number" placeholder="Estoque Mínimo" value={formData.minStock} onChange={e => setFormData({...formData, minStock: parseFloat(e.target.value)})} className="w-full rounded-xl border p-3 outline-none" />
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="px-5 py-2.5 font-bold text-slate-600">Cancelar</button>
                <button type="submit" className="rounded-xl bg-blue-600 px-5 py-2.5 font-bold text-white shadow-lg">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
