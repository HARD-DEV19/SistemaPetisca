import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, addDoc, updateDoc, doc, deleteDoc, query, orderBy, writeBatch, getDocs } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Plus, Edit, Trash2, Printer, Trash, Wallet } from 'lucide-react';
import { toast } from 'sonner';
import { useReactToPrint } from 'react-to-print';

export default function Finance() {
  const [transactions, setTransactions] = useState<any[]>([]);
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const printRef = useRef<HTMLDivElement>(null);
  const [formData, setFormData] = useState({
    type: 'receivable',
    amount: 0,
    description: '',
    status: 'paid',
    dueDate: new Date().toISOString().split('T')[0],
    category: 'sales'
  });

  useEffect(() => {
    const q = query(collection(db, 'transactions'), orderBy('createdAt', 'desc'));
    const unsub = onSnapshot(q, (snapshot) => {
      setTransactions(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
    }, (error) => {
      console.error("Finance listener error:", error);
      toast.error("Erro ao carregar dados financeiros.");
    });
    return () => unsub();
  }, []);

  const handlePrint = useReactToPrint({
    contentRef: printRef,
    documentTitle: 'Relatorio_Financeiro_PetiscaPeixe',
  });

  const handleClearAll = async () => {
    const password = prompt('ATENÇÃO: Isso excluirá TODAS as transações financeiras. Digite a senha de segurança:');
    if (password === 'harddisk18458416') {
      try {
        const snapshot = await getDocs(collection(db, 'transactions'));
        const batch = writeBatch(db);
        snapshot.docs.forEach(d => batch.delete(d.ref));
        await batch.commit();
        toast.success('Módulo financeiro limpo com sucesso.');
      } catch (e) {
        toast.error('Erro ao limpar módulo.');
      }
    } else if (password !== null) {
      toast.error('Senha incorreta.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    try {
      const payload = { 
        ...formData, 
        amount: Number(formData.amount),
        updatedAt: new Date().toISOString() 
      };
      
      if (editingId) {
        await updateDoc(doc(db, 'transactions', editingId), payload);
        toast.success('Transação atualizada!');
      } else {
        await addDoc(collection(db, 'transactions'), { 
          ...payload, 
          createdAt: new Date().toISOString() 
        });
        toast.success('Transação registrada!');
      }
      
      setIsModalOpen(false);
      setEditingId(null);
      setFormData({
        type: 'receivable',
        amount: 0,
        description: '',
        status: 'paid',
        dueDate: new Date().toISOString().split('T')[0],
        category: 'sales'
      });
    } catch (error: any) {
      toast.error(`Erro ao salvar: ${error.message}`);
    }
  };

  const totalIn = transactions
    .filter(t => t.type === 'receivable' && t.status === 'paid')
    .reduce((acc, t) => acc + (t.amount || 0), 0);
    
  const totalOut = transactions
    .filter(t => t.type === 'payable' && t.status === 'paid')
    .reduce((acc, t) => acc + (t.amount || 0), 0);

  return (
    <div className="p-4 md:p-8 max-w-7xl mx-auto space-y-8 font-sans text-slate-900">
      <div className="flex flex-col gap-4 sm:flex-row sm:items-center sm:justify-between">
        <div>
          <h1 className="text-2xl md:text-3xl font-bold font-heading tracking-tight flex items-center gap-2">
            <Wallet className="text-blue-600" /> Financeiro
          </h1>
          <p className="text-slate-500 mt-1 font-medium">Controle de fluxo de caixa e vendas.</p>
        </div>
        <div className="flex flex-wrap gap-2">
          <button onClick={handleClearAll} className="flex items-center gap-2 rounded-xl border border-red-200 bg-white px-4 py-2 text-xs font-bold text-red-600 hover:bg-red-50 transition-all">
            <Trash size={16} /> Limpar Tudo
          </button>
          <button onClick={() => handlePrint()} className="flex items-center gap-2 rounded-xl border border-slate-200 bg-white px-4 py-2 text-xs font-bold text-slate-600 hover:bg-slate-50 transition-all">
            <Printer size={16} /> Relatório
          </button>
          <button
            onClick={() => {
              setEditingId(null);
              setIsModalOpen(true);
            }}
            className="flex items-center gap-2 rounded-xl bg-blue-600 px-5 py-2 text-sm font-bold text-white hover:bg-blue-700 shadow-md shadow-blue-600/20 transition-all active:scale-95"
          >
            <Plus size={18} /> Nova Transação
          </button>
        </div>
      </div>

      {/* Cards de Resumo */}
      <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
        <div className="rounded-3xl bg-white p-6 border border-slate-100 shadow-sm">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Entradas</p>
          <p className="text-2xl font-black text-green-600 font-heading">R$ {totalIn.toFixed(2)}</p>
        </div>
        <div className="rounded-3xl bg-white p-6 border border-slate-100 shadow-sm">
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mb-1">Total Saídas</p>
          <p className="text-2xl font-black text-red-600 font-heading">R$ {totalOut.toFixed(2)}</p>
        </div>
        <div className="rounded-3xl bg-blue-600 p-6 shadow-lg shadow-blue-600/20">
          <p className="text-xs font-bold text-blue-100 uppercase tracking-widest mb-1">Saldo Atual</p>
          <p className="text-2xl font-black text-white font-heading">R$ {(totalIn - totalOut).toFixed(2)}</p>
        </div>
      </div>

      {/* Tabela de Transações */}
      <div className="overflow-hidden rounded-[2.5rem] border border-slate-200 bg-white shadow-sm">
        <div className="overflow-x-auto">
          <table className="w-full text-left text-sm">
            <thead className="bg-slate-50 border-b border-slate-100 text-[10px] font-bold uppercase tracking-widest text-slate-500">
              <tr>
                <th className="px-6 py-4">Data</th>
                <th className="px-6 py-4">Descrição</th>
                <th className="px-6 py-4">Valor</th>
                <th className="px-6 py-4">Status</th>
                <th className="px-6 py-4 text-right">Ações</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-50">
              {transactions.map(t => (
                <tr key={t.id} className="hover:bg-blue-50/30 transition-colors">
                  <td className="px-6 py-4 font-medium text-slate-500">
                    {new Date(t.dueDate || t.paidDate || t.createdAt).toLocaleDateString('pt-BR')}
                  </td>
                  <td className="px-6 py-4 font-bold text-slate-900">{t.description || t.tableName || 'Venda'}</td>
                  <td className={`px-6 py-4 font-black ${t.type === 'receivable' ? 'text-green-600' : 'text-red-600'}`}>
                    {t.type === 'receivable' ? '+' : '-'} R$ {Number(t.amount || 0).toFixed(2)}
                  </td>
                  <td className="px-6 py-4">
                    <span className={`px-2.5 py-1 rounded-full text-[10px] font-bold uppercase tracking-tighter ${
                      t.status === 'paid' ? 'bg-green-100 text-green-700 border border-green-200' : 'bg-yellow-100 text-yellow-700 border border-yellow-200'
                    }`}>
                      {t.status === 'paid' ? 'Pago' : 'Pendente'}
                    </span>
                  </td>
                  <td className="px-6 py-4 text-right">
                    <button onClick={() => { 
                      setFormData({
                        type: t.type, amount: t.amount, description: t.description, 
                        status: t.status, dueDate: t.dueDate, category: t.category 
                      }); 
                      setEditingId(t.id); 
                      setIsModalOpen(true); 
                    }} className="p-2 text-blue-600 hover:bg-blue-50 rounded-xl transition-all"><Edit size={18} /></button>
                    <button onClick={async () => { 
                      if(confirm('Excluir esta transação?')) await deleteDoc(doc(db, 'transactions', t.id)); 
                    }} className="p-2 text-slate-400 hover:text-red-600 hover:bg-red-50 rounded-xl transition-all"><Trash2 size={18} /></button>
                  </td>
                </tr>
              ))}
              {transactions.length === 0 && (
                <tr>
                  <td colSpan={5} className="px-6 py-20 text-center text-slate-400 font-medium">Nenhuma transação registrada.</td>
                </tr>
              )}
            </tbody>
          </table>
        </div>
      </div>

      {/* Relatório Oculto para Impressão */}
      <div className="hidden">
        <div ref={printRef} className="p-12 font-sans text-slate-900">
          <div className="text-center border-b-2 border-slate-900 pb-6 mb-8">
            <h1 className="text-3xl font-black uppercase tracking-tighter">Relatório Financeiro</h1>
            <p className="text-sm font-bold text-slate-500 mt-2">PetiscaPeixe - Gastronomia Marítima</p>
            <p className="text-xs mt-1">Gerado em: {new Date().toLocaleString('pt-BR')}</p>
          </div>
          
          <div className="grid grid-cols-2 gap-8 mb-10">
            <div className="border p-4 rounded-xl">
              <p className="text-xs font-bold uppercase text-slate-400">Total Recebido</p>
              <p className="text-xl font-black text-green-600">R$ {totalIn.toFixed(2)}</p>
            </div>
            <div className="border p-4 rounded-xl">
              <p className="text-xs font-bold uppercase text-slate-400">Total Pago</p>
              <p className="text-xl font-black text-red-600">R$ {totalOut.toFixed(2)}</p>
            </div>
          </div>

          <table className="w-full text-left text-xs">
            <thead>
              <tr className="border-b-2 border-slate-900"><th className="py-2">Data</th><th>Descrição</th><th>Valor</th><th>Status</th></tr>
            </thead>
            <tbody className="divide-y divide-slate-200">
              {transactions.map(t => (
                <tr key={t.id} className="py-2">
                  <td className="py-3">{new Date(t.dueDate || t.paidDate || t.createdAt).toLocaleDateString('pt-BR')}</td>
                  <td className="font-bold">{t.description || t.tableName || 'Venda'}</td>
                  <td className="font-black">R$ {Number(t.amount || 0).toFixed(2)}</td>
                  <td className="uppercase font-bold">{t.status === 'paid' ? 'Pago' : 'Pendente'}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Modal de Transação */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-md rounded-[2.5rem] bg-white p-8 shadow-2xl border border-slate-200 animate-in fade-in zoom-in duration-200">
            <h2 className="mb-6 text-2xl font-black font-heading text-slate-900 tracking-tight">
              {editingId ? 'Editar Transação' : 'Nova Transação'}
            </h2>
            <form onSubmit={handleSubmit} className="space-y-4">
              <div>
                <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-widest">Descrição</label>
                <input required placeholder="Ex: Venda de pratos, Aluguel, etc." type="text" value={formData.description} onChange={e => setFormData({...formData, description: e.target.value})} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-900 font-bold focus:border-blue-500 focus:bg-white outline-none transition-all" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-widest">Tipo</label>
                  <select value={formData.type} onChange={e => setFormData({...formData, type: e.target.value})} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-900 font-bold outline-none focus:border-blue-500 transition-all">
                    <option value="receivable">Entrada (+)</option>
                    <option value="payable">Saída (-)</option>
                  </select>
                </div>
                <div>
                  <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-widest">Valor (R$)</label>
                  <input required type="number" step="0.01" value={formData.amount} onChange={e => setFormData({...formData, amount: Number(e.target.value)})} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-900 font-black focus:border-blue-500 transition-all" />
                </div>
              </div>
              <div>
                <label className="mb-1.5 block text-xs font-bold text-slate-500 uppercase tracking-widest">Data</label>
                <input required type="date" value={formData.dueDate} onChange={e => setFormData({...formData, dueDate: e.target.value})} className="w-full rounded-2xl border border-slate-200 bg-slate-50 p-4 text-slate-900 font-bold outline-none" />
              </div>
              <div className="mt-8 flex justify-end gap-3">
                <button type="button" onClick={() => setIsModalOpen(false)} className="rounded-2xl px-6 py-3 font-bold text-slate-400 hover:bg-slate-100 transition-all">Cancelar</button>
                <button type="submit" className="rounded-2xl bg-blue-600 px-8 py-3 font-black text-white shadow-lg shadow-blue-600/20 hover:bg-blue-700 active:scale-95 transition-all">Salvar</button>
              </div>
            </form>
          </div>
        </div>
      )}
    </div>
  );
}
