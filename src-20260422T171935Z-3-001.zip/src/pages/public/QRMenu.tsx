import React, { useState, useEffect } from 'react';
import { collection, onSnapshot, query, orderBy } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { Utensils, Wine, Waves, Fish, Anchor } from 'lucide-react';
import { toast } from 'sonner';

export default function QRMenu() {
  const [products, setProducts] = useState<any[]>([]);
  const [categories, setCategories] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [dataReady, setDataReady] = useState({ products: false, categories: false });

  useEffect(() => {
    const unsubProducts = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setDataReady(prev => ({ ...prev, products: true }));
    }, (error) => {
      console.error("Falha ao carregar produtos:", error);
      toast.error("Erro ao carregar o cardápio.");
      setDataReady(prev => ({ ...prev, products: true })); // Unblock on error
    });

    const unsubCats = onSnapshot(query(collection(db, 'categories'), orderBy('order', 'asc')), (snapshot) => {
      setCategories(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() })));
      setDataReady(prev => ({ ...prev, categories: true }));
    }, (error) => {
      console.error("Falha ao carregar categorias:", error);
      setDataReady(prev => ({ ...prev, categories: true })); // Unblock on error
    });

    return () => { unsubProducts(); unsubCats(); };
  }, []);

  useEffect(() => {
    if (dataReady.products && dataReady.categories) {
      setLoading(false);
    }
  }, [dataReady]);

  if (loading) {
    return (
      <div className="flex h-screen flex-col items-center justify-center bg-blue-50">
        <Waves className="animate-bounce text-blue-600 mb-4" size={48} />
        <div className="h-1 w-32 bg-blue-100 rounded-full overflow-hidden">
          <div className="h-full bg-blue-600 animate-progress origin-left w-1/2"></div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-8 font-sans text-slate-900 overflow-x-hidden">
      {/* Header Compacto e Mobile-First */}
      <div className="bg-slate-900 px-4 py-8 text-white shadow-xl relative overflow-hidden text-center">
        <div className="absolute -right-4 -bottom-4 opacity-10 rotate-12">
          <Anchor size={80} />
        </div>
        <div className="relative z-10 flex flex-col items-center">
          <div className="h-16 w-16 mb-3 overflow-hidden rounded-full bg-white border-2 border-blue-600/30">
            <img src="/logo.jpg" alt="Logo" className="h-full w-full object-cover" />
          </div>
          <h1 className="text-2xl font-black font-heading tracking-tighter italic">PetiscaPeixe</h1>
        </div>
      </div>

      <div className="mx-auto max-w-2xl px-3 -mt-4 relative z-20">
        {categories.map(cat => {
          const catProducts = products.filter(p => p.subCategory === cat.id);
          if (catProducts.length === 0) return null;

          return (
            <div key={cat.id} className="mb-6">
              {/* Divisor de Categoria */}
              <div className="mb-4 flex items-center gap-2 bg-blue-600 py-1.5 px-4 rounded-full shadow-md w-fit mx-auto border-2 border-white">
                <div className="text-white">
                  {cat.type === 'food' ? <Utensils size={16} /> : <Wine size={16} />}
                </div>
                <h2 className="text-xs font-black font-heading uppercase tracking-widest text-white italic">
                  {cat.name}
                </h2>
              </div>
              
              <div className="grid gap-2">
                {catProducts.map(product => (
                  <div key={product.id} className="flex items-center gap-3 rounded-2xl bg-white p-2.5 shadow-sm border border-slate-100 active:bg-slate-50 transition-colors w-full min-w-0">
                    {/* Imagem com tamanho fixo seguro */}
                    <div className="h-16 w-16 sm:h-20 sm:w-20 flex-shrink-0 relative">
                      {product.imageUrl ? (
                        <img
                          src={product.imageUrl}
                          alt=""
                          className="h-full w-full rounded-xl object-cover"
                        />
                      ) : (
                        <div className="h-full w-full rounded-xl bg-blue-50 flex items-center justify-center text-blue-200">
                          <Fish size={20} />
                        </div>
                      )}
                    </div>

                    <div className="flex-1 min-w-0 flex flex-col justify-center">
                      <div className="flex justify-between items-start gap-2 w-full">
                        <h3 className="text-sm font-bold text-slate-900 truncate pr-1 leading-tight">
                          {product.name}
                        </h3>
                        <span className="text-sm font-black text-blue-600 whitespace-nowrap">
                          R$ {product.price.toFixed(2)}
                        </span>
                      </div>
                      
                      {product.description && (
                        <p className="text-slate-500 text-[10px] leading-tight line-clamp-1 mt-0.5 mb-1 font-medium">
                          {product.description}
                        </p>
                      )}

                      {product.ingredientList && product.ingredientList.length > 0 && (
                        <div className="flex flex-wrap gap-1 mt-auto">
                          {product.ingredientList.slice(0, 2).map((ing: string, i: number) => (
                            <span key={i} className="text-[8px] font-bold text-blue-700 bg-blue-50 px-1.5 py-0.5 rounded border border-blue-100 uppercase tracking-tighter">
                              {ing}
                            </span>
                          ))}
                          {product.ingredientList.length > 2 && (
                            <span className="text-[8px] font-bold text-slate-400">+{product.ingredientList.length - 2}</span>
                          )}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Footer Minimalista */}
      <div className="mt-8 px-6 text-center border-t border-slate-100 pt-6">
        <Waves className="mx-auto text-blue-100 mb-2" size={20} />
        <p className="text-[9px] font-black uppercase tracking-[0.2em] text-slate-300">© 2026 PetiscaPeixe</p>
      </div>
    </div>
  );
}
