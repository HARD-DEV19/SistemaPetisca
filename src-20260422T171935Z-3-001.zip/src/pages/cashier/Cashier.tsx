import React, { useState, useEffect, useRef } from 'react';
import { collection, onSnapshot, doc, updateDoc, addDoc, query, where, orderBy, getDocs, getDoc, deleteDoc, writeBatch } from 'firebase/firestore';
import { db } from '../../lib/firebase';
import { 
  Calculator, Search, CreditCard, Banknote, QrCode, Trash2, ChevronRight, RefreshCw, Plus, X, CheckCircle2, User, Printer
} from 'lucide-react';
import { toast } from 'sonner';
import { useAuth } from '../../contexts/AuthContext';

import { useNavigate } from 'react-router-dom';

export default function Cashier() {
  const navigate = useNavigate();
  const { userData } = useAuth();
  const [tables, setTables] = useState<any[]>([]);
  const [selectedTable, setSelectedTable] = useState<any>(null);
  const [orderItems, setOrderItems] = useState<any[]>([]);
  const [currentSession, setCurrentSession] = useState<any>(null);
  
  // Selection & Payment States
  const [selectedItemIds, setSelectedItemIds] = useState<Set<string>>(new Set());
  const [paymentMethod, setPaymentMethod] = useState<string | null>(null);
  const [isProcessing, setIsProcessing] = useState(false);
  const [includeServiceFee, setIncludeServiceFee] = useState(true);
  
  // UI States
  const [showDirectAdd, setShowDirectAdd] = useState(false);
  const [products, setProducts] = useState<any[]>([]);
  const [search, setSearch] = useState('');
  const [tableSearch, setTableSearch] = useState('');

  // 1. Listen for tables
  useEffect(() => {
    const unsub = onSnapshot(collection(db, 'tables'), (snapshot) => {
      const data = snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any));
      setTables(data.sort((a, b) => {
        const priority = ['balcão', 'bar'];
        const isA = priority.includes((a.name || '').toLowerCase());
        const isB = priority.includes((b.name || '').toLowerCase());
        if (isA && !isB) return -1;
        if (!isA && isB) return 1;
        return (a.number || 0) - (b.number || 0);
      }));
    });
    return () => unsub();
  }, []);

  // 2. Listen for session and products
  useEffect(() => {
    const q = query(collection(db, 'cashRegisterSessions'), where('status', '==', 'open'));
    const unsubSession = onSnapshot(q, (snapshot) => {
      setCurrentSession(!snapshot.empty ? { id: snapshot.docs[0].id, ...snapshot.docs[0].data() } : null);
    });
    const unsubProds = onSnapshot(collection(db, 'products'), (snapshot) => {
      setProducts(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
    });
    return () => { unsubSession(); unsubProds(); };
  }, []);

  // 3. Sincronia REAL TIME da Mesa Selecionada
  useEffect(() => {
    if (!selectedTable) {
      setOrderItems([]);
      setSelectedItemIds(new Set());
      return;
    }

    const unsubTable = onSnapshot(doc(db, 'tables', selectedTable.id), (tableDoc) => {
      if (tableDoc.exists()) {
        const tableData = tableDoc.data();
        if (tableData.currentOrderId) {
          const qItems = query(collection(db, 'orderItems'), where('orderId', '==', tableData.currentOrderId));
          const unsubItems = onSnapshot(qItems, (snapshot) => {
            setOrderItems(snapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as any)));
          });
          return () => unsubItems();
        } else {
          setOrderItems([]);
        }
      }
    });
    return () => unsubTable();
  }, [selectedTable?.id]);

  const toggleItemSelection = (id: string) => {
    const newSelection = new Set(selectedItemIds);
    if (newSelection.has(id)) newSelection.delete(id);
    else newSelection.add(id);
    setSelectedItemIds(newSelection);
  };

  const selectAll = () => {
    const unpaid = orderItems.filter(i => i.status !== 'paid' && i.status !== 'cancelled');
    setSelectedItemIds(new Set(unpaid.map(i => i.id)));
  };

  const handleAddItem = async (product: any) => {
    if (!selectedTable || !userData || isProcessing) return;
    setIsProcessing(true);
    try {
      const tableSnap = await getDoc(doc(db, 'tables', selectedTable.id));
      let orderId = tableSnap.data()?.currentOrderId;

      if (!orderId) {
        const newOrderRef = await addDoc(collection(db, 'orders'), {
          tableId: selectedTable.id, tableNumber: selectedTable.number, tableName: selectedTable.name || '',
          waiterId: userData.uid, waiterName: userData.name, status: 'open', total: 0, createdAt: new Date().toISOString()
        });
        orderId = newOrderRef.id;
        await updateDoc(doc(db, 'tables', selectedTable.id), { status: 'occupied', currentOrderId: orderId });
      }

      await addDoc(collection(db, 'orderItems'), {
        orderId, productId: product.id, productName: product.name, price: product.price,
        quantity: 1, status: 'pending', type: product.category, tableNumber: selectedTable.number, createdAt: new Date().toISOString()
      });

      const orderRef = doc(db, 'orders', orderId);
      const orderSnap = await getDoc(orderRef);
      if (orderSnap.exists()) {
        await updateDoc(orderRef, { total: (orderSnap.data().total || 0) + product.price });
      }
      toast.success('Item adicionado');
    } catch (e) { toast.error('Erro ao lançar'); } finally { setIsProcessing(false); }
  };

  const handleRemoveItem = async (item: any) => {
    if (!confirm(`Remover "${item.productName}" do pedido?`)) return;
    setIsProcessing(true);
    try {
      // 1. Deleta o item
      await deleteDoc(doc(db, 'orderItems', item.id));
      
      // 2. Atualiza o total do pedido
      const orderRef = doc(db, 'orders', item.orderId);
      const orderSnap = await getDoc(orderRef);
      if (orderSnap.exists()) {
        const newTotal = Math.max(0, (orderSnap.data().total || 0) - (item.price * item.quantity));
        await updateDoc(orderRef, { total: newTotal });
      }

      // 3. Limpa da seleção se estiver lá
      const newSelection = new Set(selectedItemIds);
      newSelection.delete(item.id);
      setSelectedItemIds(newSelection);

      toast.success('Item removido!');
    } catch (e) { toast.error('Erro ao remover item'); } finally { setIsProcessing(false); }
  };

  const handlePrintCheck = async () => {
    if (!selectedTable || orderItems.length === 0) return;
    try {
      const unpaid = orderItems.filter(i => i.status !== 'cancelled' && i.status !== 'paid');
      const subtotal = unpaid.reduce((acc, i) => acc + (i.price * i.quantity), 0);
      
      const orderId = selectedTable.currentOrderId;
      
      await addDoc(collection(db, 'printJobs'), {
        pedidoId: orderId?.slice(0, 8) || 'MESA',
        mesa: selectedTable.name || selectedTable.number.toString(),
        itens: unpaid.map(i => ({ nome: i.productName, quantidade: i.quantity, preco: i.price })),
        subtotal: subtotal,
        tipo: 'preconta',
        status: 'pending',
        createdAt: new Date().toISOString()
      });
      toast.success('Conferência enviada para impressora');
    } catch (e) { toast.error('Erro ao imprimir'); }
  };

  const handleFinalizePayment = async () => {
    if (!paymentMethod || selectedItemIds.size === 0 || !currentSession) return;
    setIsProcessing(true);
    try {
      const itemsToPay = orderItems.filter(i => selectedItemIds.has(i.id));
      const subtotal = itemsToPay.reduce((acc, i) => acc + (i.price * i.quantity), 0);
      const valorTaxa = includeServiceFee ? subtotal * 0.1 : 0;
      const totalFinal = subtotal + valorTaxa;

      await addDoc(collection(db, 'transactions'), {
        amount: totalFinal, 
        type: 'receivable', 
        status: 'paid', 
        category: 'sales', 
        paymentMethod,
        description: `Venda ${selectedTable.name || `Mesa ${selectedTable.number}`}`,
        orderId: itemsToPay[0].orderId, 
        tableName: selectedTable.name || `Mesa ${selectedTable.number}`,
        createdAt: new Date().toISOString(), 
        paidDate: new Date().toISOString(),
        dueDate: new Date().toISOString().split('T')[0],
        hasServiceFee: includeServiceFee
      });

      const batch = writeBatch(db);
      selectedItemIds.forEach(id => { batch.update(doc(db, 'orderItems', id), { status: 'paid' }); });
      await batch.commit();

      await updateDoc(doc(db, 'cashRegisterSessions', currentSession.id), {
        currentAmount: currentSession.currentAmount + totalFinal
      });

      await addDoc(collection(db, 'printJobs'), {
        pedidoId: itemsToPay[0].orderId.slice(0, 8),
        mesa: selectedTable.name || selectedTable.number.toString(),
        itens: itemsToPay.map(i => ({ nome: i.productName, quantidade: i.quantity, preco: i.price })),
        subtotal: subtotal,
        taxa: valorTaxa,
        pagamento: paymentMethod,
        tipo: 'venda_parcial',
        status: 'pending',
        createdAt: new Date().toISOString()
      });

      const stillUnpaid = orderItems.filter(i => !selectedItemIds.has(i.id) && i.status !== 'paid' && i.status !== 'cancelled');
      if (stillUnpaid.length === 0) {
        await updateDoc(doc(db, 'tables', selectedTable.id), { status: 'free', currentOrderId: null });
        await updateDoc(doc(db, 'orders', itemsToPay[0].orderId), { status: 'closed', closedAt: new Date().toISOString() });
        setSelectedTable(null);
      }

      setSelectedItemIds(new Set()); setPaymentMethod(null);
      toast.success('Venda finalizada!');
    } catch (e) { toast.error('Erro ao processar'); } finally { setIsProcessing(false); }
  };

  const [showOpenModal, setShowOpenModal] = useState(false);
  const [showCloseModal, setShowCloseModal] = useState(false);
  const [initialAmount, setInitialAmount] = useState('0');

  const handleOpenCashier = async () => {
    if (!userData || isProcessing) return;
    setIsProcessing(true);
    try {
      await addDoc(collection(db, 'cashRegisterSessions'), {
        status: 'open',
        openedAt: new Date().toISOString(),
        openedBy: userData.name,
        initialAmount: Number(initialAmount),
        currentAmount: Number(initialAmount),
        totalSales: 0,
        createdAt: new Date().toISOString()
      });
      toast.success('Caixa aberto com sucesso!');
    } catch (e) {
      toast.error('Erro ao abrir caixa');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleCloseCashier = async () => {
    if (!currentSession || isProcessing) return;
    if (!confirm('Deseja realmente FECHAR o caixa agora?')) return;
    setIsProcessing(true);
    try {
      const closedAt = new Date().toISOString();
      const totalVendas = currentSession.currentAmount - currentSession.initialAmount;

      // 1. Gera Impressão do Relatório de Fechamento (X de Caixa)
      const reportLines = [
        `[BIG]FECHAMENTO DE CAIXA`,
        `DATA: ${new Date().toLocaleString()}`,
        `OPERADOR: ${currentSession.openedBy.toUpperCase()}`,
        `--------------------------------`,
        `FUNDO INICIAL:    R$ ${currentSession.initialAmount.toFixed(2)}`,
        `VENDAS NO TURNO:  R$ ${totalVendas.toFixed(2)}`,
        `--------------------------------`,
        `[BIG]TOTAL GERAL: R$ ${currentSession.currentAmount.toFixed(2)}`,
        `\n\n\n\n\n\n\n\n`
      ];

      await addDoc(collection(db, 'printJobs'), {
        tipo: 'fechamento',
        status: 'pending',
        text: reportLines.join('\n'), // O PrintJobListener agora suporta texto direto ou layout
        createdAt: closedAt
      });

      // 2. Atualiza status no Firestore
      await updateDoc(doc(db, 'cashRegisterSessions', currentSession.id), {
        status: 'closed',
        closedAt: closedAt,
        finalAmount: currentSession.currentAmount
      });

      setShowCloseModal(false);
      toast.success('Caixa fechado e relatório enviado para impressão!');
    } catch (e) {
      toast.error('Erro ao fechar caixa');
    } finally {
      setIsProcessing(false);
    }
  };

  const subtotalSelecionado = orderItems.filter(i => selectedItemIds.has(i.id)).reduce((acc, i) => acc + (i.price * i.quantity), 0);

  return (
    <div className="flex h-screen bg-blue-50 flex-col font-sans overflow-hidden">
      <header className="bg-white border-b border-blue-100 px-6 py-4 flex items-center justify-between shrink-0 h-20 shadow-sm z-10">
        <div className="flex items-center gap-4">
          <div className="h-12 w-12 flex items-center justify-center rounded-2xl bg-blue-600 text-white shadow-lg shadow-blue-600/20"><Calculator size={28} /></div>
          <div>
            <h1 className="text-xl font-bold text-slate-900 font-heading uppercase italic">Frente de Caixa</h1>
            <div className="flex items-center gap-2">
              <span className={`h-2 w-2 rounded-full ${currentSession ? 'bg-green-500 animate-pulse' : 'bg-red-500'}`}></span>
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">
                {currentSession ? `Operador: ${currentSession.openedBy}` : 'Caixa Fechado'}
              </span>
              {currentSession && (
                <button 
                  onClick={handleCloseCashier}
                  className="ml-4 bg-red-50 text-red-600 px-3 py-1 rounded-lg text-[10px] font-black hover:bg-red-600 hover:text-white transition-all uppercase"
                >
                  Encerrar Turno
                </button>
              )}
            </div>
          </div>
        </div>
      </header>

      <div className="flex flex-1 overflow-hidden">
        <aside className="w-80 bg-white border-r border-blue-100 flex flex-col shrink-0">
          <div className="p-4 border-b border-blue-50">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
              <input type="text" placeholder="Buscar mesa..." value={tableSearch} onChange={e => setTableSearch(e.target.value)} className="w-full rounded-xl bg-slate-50 py-2.5 pl-10 pr-4 text-sm font-bold outline-none border border-slate-100" />
            </div>
          </div>
          <div className="flex-1 overflow-y-auto p-4 space-y-2">
            {tables.filter(t => (t.name || '').toLowerCase().includes(tableSearch.toLowerCase()) || t.number.toString().includes(tableSearch)).map(table => (
              <button key={table.id} onClick={() => setSelectedTable(table)} className={`flex w-full items-center justify-between rounded-2xl border p-4 transition-all ${selectedTable?.id === table.id ? 'border-blue-600 bg-blue-50 shadow-md' : 'border-slate-50 bg-slate-50/30'}`}>
                <div className="flex items-center gap-4">
                  <div className={`h-10 w-10 flex items-center justify-center rounded-xl font-black ${table.status === 'free' ? 'bg-white text-slate-300 border' : 'bg-blue-600 text-white shadow-sm'}`}>{table.name ? table.name.charAt(0).toUpperCase() : table.number}</div>
                  <div className="text-left"><span className="block font-bold text-slate-900 truncate uppercase text-sm">{table.name || `Mesa ${table.number}`}</span><span className={`text-[9px] font-black uppercase ${table.status === 'free' ? 'text-slate-400' : 'text-blue-600'}`}>{table.status === 'free' ? 'Livre' : 'Ocupada'}</span></div>
                </div>
              </button>
            ))}
          </div>
        </aside>

        <main className="flex-1 flex flex-col overflow-hidden">
          {!selectedTable ? (
            <div className="flex-1 flex flex-col items-center justify-center text-slate-300 opacity-30"><Calculator size={120}/><p className="text-xl font-black uppercase mt-4">Selecione uma mesa</p></div>
          ) : (
            <div className="flex-1 flex flex-col overflow-hidden">
              <div className="bg-white p-6 border-b border-blue-100 flex items-center justify-between shrink-0">
                <div>
                  <h2 className="text-2xl font-black font-heading text-slate-900 uppercase italic">{selectedTable.name || `Mesa ${selectedTable.number}`}</h2>
                  <div className="flex gap-3 mt-1">
                    <button onClick={selectAll} className="text-[10px] font-black text-blue-600 uppercase tracking-widest">Selecionar Tudo</button>
                    <button onClick={() => setSelectedItemIds(new Set())} className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Limpar</button>
                  </div>
                </div>
                <div className="flex gap-2">
                  <button onClick={handlePrintCheck} className="bg-slate-900 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-md active:scale-95 transition-all uppercase flex items-center gap-2"><Printer size={16}/> Conferência</button>
                  <button onClick={() => setShowDirectAdd(true)} className="bg-blue-600 text-white px-5 py-2.5 rounded-xl text-xs font-black shadow-md hover:bg-blue-700 active:scale-95 transition-all uppercase">Lançar Item</button>
                  <button onClick={async () => { if(confirm('Liberar mesa?')) { await updateDoc(doc(db,'tables',selectedTable.id), {status:'free', currentOrderId: null}); setSelectedTable(null); } }} className="bg-slate-100 text-slate-400 px-5 py-2.5 rounded-xl text-xs font-black active:scale-95 transition-all uppercase">Forçar Liberar</button>
                </div>
              </div>

              <div className="flex-1 overflow-y-auto p-6 space-y-3 bg-white/50">
                {orderItems.length === 0 ? (
                  <div className="py-20 text-center text-slate-300 italic font-bold">Nenhum item lançado.</div>
                ) : (
                  orderItems.map(item => {
                    const isPaid = item.status === 'paid';
                    const isSelected = selectedItemIds.has(item.id);
                    return (
                      <div key={item.id} className="group relative">
                        <div 
                          onClick={() => !isPaid && toggleItemSelection(item.id)}
                          className={`flex items-center justify-between p-5 rounded-3xl border transition-all cursor-pointer ${
                            isPaid ? 'bg-slate-50 border-slate-100 opacity-40' : 
                            isSelected ? 'bg-blue-600 border-blue-600 text-white shadow-xl scale-[1.02]' : 'bg-white border-slate-100 hover:border-blue-200'
                          }`}
                        >
                          <div className="flex items-center gap-4">
                            <div className={`h-6 w-6 rounded-full border-2 flex items-center justify-center ${isSelected ? 'bg-white border-white text-blue-600' : 'border-slate-200'}`}>
                              {isSelected && <CheckCircle2 size={16} />}
                            </div>
                            <div>
                              <p className="font-black uppercase italic text-base">{item.quantity}x {item.productName}</p>
                              <p className={`text-[10px] font-black ${isSelected ? 'text-blue-100' : 'text-slate-400'}`}>
                                {isPaid ? 'ITEM PAGO' : 'AGUARDANDO'}
                              </p>
                            </div>
                          </div>
                          <div className="flex items-center gap-4">
                            <span className="font-black text-lg">R$ {(item.price * item.quantity).toFixed(2)}</span>
                            {!isPaid && (
                              <button 
                                onClick={(e) => { e.stopPropagation(); handleRemoveItem(item); }}
                                className={`p-2 rounded-xl transition-all ${isSelected ? 'text-blue-200 hover:bg-white/10' : 'text-slate-300 hover:text-red-500 hover:bg-red-50'}`}
                              >
                                <Trash2 size={18} />
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    );
                  })
                )}
              </div>

              <div className="bg-white border-t-2 border-blue-600 p-8 shrink-0 shadow-[0_-20px_60px_rgba(0,0,0,0.1)]">
                <div className="max-w-4xl mx-auto flex flex-col md:flex-row gap-8 items-center">
                  <div className="flex-1 space-y-2">
                    <div className="flex items-center justify-between">
                      <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Subtotal Itens</span>
                      <span className="font-bold text-slate-600">R$ {subtotalSelecionado.toFixed(2)}</span>
                    </div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <input type="checkbox" id="tax-toggle" checked={includeServiceFee} onChange={e => setIncludeServiceFee(e.target.checked)} className="h-4 w-4 rounded border-slate-300 text-blue-600" />
                        <label htmlFor="tax-toggle" className="text-[10px] font-black text-blue-600 uppercase cursor-pointer">Taxa de Serviço (10%)</label>
                      </div>
                      <span className="font-bold text-blue-600">R$ {(includeServiceFee ? subtotalSelecionado * 0.1 : 0).toFixed(2)}</span>
                    </div>
                    <div className="h-[1px] bg-slate-100 my-2"></div>
                    <div className="flex items-center justify-between">
                      <span className="text-sm font-black text-slate-900 uppercase italic">Total à Pagar</span>
                      <p className="text-4xl font-black text-slate-900 font-heading italic">R$ {(subtotalSelecionado + (includeServiceFee ? subtotalSelecionado * 0.1 : 0)).toFixed(2)}</p>
                    </div>
                  </div>

                  <div className="w-full md:w-auto space-y-4">
                    <div className="grid grid-cols-4 gap-2">
                      {['pix', 'cash', 'credit', 'debit'].map(m => (
                        <button key={m} onClick={() => setPaymentMethod(m)} className={`p-4 rounded-2xl border-2 transition-all flex flex-col items-center gap-1 ${paymentMethod === m ? 'border-blue-600 bg-blue-50 text-blue-600' : 'border-slate-100 bg-slate-50 text-slate-400'}`}>
                          {m === 'pix' && <QrCode size={24}/>}
                          {m === 'cash' && <Banknote size={24}/>}
                          {m === 'credit' && <CreditCard size={24}/>}
                          {m === 'debit' && <CreditCard size={24}/>}
                          <span className="text-[8px] font-black uppercase">{m === 'cash' ? 'DINHEIRO' : m}</span>
                        </button>
                      ))}
                    </div>
                    <button disabled={!paymentMethod || selectedItemIds.size === 0 || isProcessing} onClick={handleFinalizePayment} className="w-full bg-blue-600 py-5 rounded-2xl text-white font-black text-lg shadow-xl shadow-blue-600/30 active:scale-95 transition-all disabled:opacity-30 uppercase italic tracking-widest">{isProcessing ? 'PROCESSANDO...' : 'CONFIRMAR PAGAMENTO'}</button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </main>
      </div>

      {showDirectAdd && (
        <div className="fixed inset-0 z-[60] flex items-center justify-center bg-slate-950/60 backdrop-blur-sm p-4">
          <div className="w-full max-w-2xl bg-white rounded-[2.5rem] shadow-2xl overflow-hidden flex flex-col h-[80vh]">
            <div className="p-6 border-b border-blue-50 flex items-center justify-between shrink-0">
              <h2 className="text-xl font-black font-heading text-slate-900 italic uppercase">Lançar Produto</h2>
              <button onClick={() => setShowDirectAdd(false)} className="p-2 hover:bg-slate-100 rounded-full"><X /></button>
            </div>
            <div className="p-4 border-b border-blue-50 shrink-0">
              <div className="relative">
                <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
                <input type="text" value={search} onChange={(e) => setSearch(e.target.value)} placeholder="Pesquisar..." className="w-full rounded-xl bg-slate-50 py-3 pl-10 pr-4 text-sm font-bold outline-none border border-slate-100" />
              </div>
            </div>
            <div className="flex-1 overflow-y-auto p-6 grid grid-cols-2 sm:grid-cols-3 gap-4">
              {products.filter(p => p.name.toLowerCase().includes(search.toLowerCase())).map(product => (
                <button key={product.id} disabled={isProcessing} onClick={() => handleAddItem(product)} className="flex flex-col items-start p-4 rounded-2xl border border-slate-50 bg-slate-50/50 hover:bg-blue-50 transition-all text-left active:scale-95 disabled:opacity-50">
                  <span className="text-[9px] font-black uppercase text-blue-400 tracking-widest mb-1">{product.category}</span>
                  <span className="font-bold text-slate-900 mb-2 line-clamp-2 leading-tight uppercase text-xs">{product.name}</span>
                  <span className="mt-auto font-black text-blue-600 text-sm">R$ {product.price.toFixed(2)}</span>
                </button>
              ))}
            </div>
          </div>
        </div>
      )}

      {!currentSession && (
        <div className="fixed inset-0 z-[100] flex items-center justify-center bg-slate-900/40 backdrop-blur-md p-4">
          <div className="w-full max-w-md bg-white rounded-[3rem] shadow-2xl p-10 text-center border-4 border-white relative">
            <button 
              onClick={() => navigate('/dashboard')}
              className="absolute top-6 right-6 p-2 text-slate-300 hover:text-red-500 hover:bg-red-50 rounded-full transition-all"
            >
              <X size={24} />
            </button>

            <div className="h-20 w-20 bg-blue-600 text-white rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-blue-600/30">
              <Calculator size={40} />
            </div>
            
            <h2 className="text-3xl font-black text-slate-900 uppercase italic font-heading mb-2">Caixa Fechado</h2>
            <p className="text-slate-500 font-bold mb-8 uppercase text-[10px] tracking-widest leading-relaxed">
              O turno atual está encerrado. Informe o fundo de caixa para iniciar as operações.
            </p>
            
            <div className="bg-slate-50 p-6 rounded-3xl mb-8 border border-slate-100 text-left group-focus-within:border-blue-400 transition-all">
              <label className="text-[10px] font-black text-slate-400 uppercase mb-2 block tracking-widest">Fundo de Caixa (R$)</label>
              <input 
                type="number" 
                autoFocus
                value={initialAmount}
                onChange={e => setInitialAmount(e.target.value)}
                className="w-full bg-transparent text-3xl font-black text-blue-600 outline-none"
                placeholder="0,00"
              />
            </div>

            <div className="grid grid-cols-1 gap-3">
              <button 
                onClick={handleOpenCashier}
                disabled={isProcessing}
                className="w-full bg-blue-600 py-6 rounded-2xl text-white font-black text-xl shadow-xl shadow-blue-600/40 active:scale-95 transition-all uppercase italic tracking-widest"
              >
                {isProcessing ? 'PROCESSANDO...' : 'ABRIR CAIXA AGORA'}
              </button>
              
              <button 
                onClick={() => navigate('/dashboard')}
                className="w-full py-4 text-slate-400 font-black text-[10px] uppercase tracking-[0.2em] hover:text-slate-600 transition-all"
              >
                Cancelar e Voltar ao Início
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
