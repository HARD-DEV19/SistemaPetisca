import { useEffect, useState, useRef } from 'react';
import { collection, query, where, onSnapshot, updateDoc, doc, getDocs, getDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { toast } from 'sonner';
import { BUSINESS_DISPLAY_NAME } from '../lib/brand';
import { generate80mmLayout } from '../lib/escpos';

export default function PrintJobListener() {
  const { userData } = useAuth();
  const [isAgentOnline, setIsAgentOnline] = useState(false);
  const processedJobs = useRef<Set<string>>(new Set());
  const isInitialLoad = useRef(true);

  useEffect(() => {
    // Somente executa no PC do Caixa/Admin e se impressão automática estiver ativa
    const isAutoPrintEnabled = localStorage.getItem('enableAutoPrint') === 'true';
    if (!userData || (userData.role !== 'admin' && userData.role !== 'cashier' && userData.role !== 'manager') || !isAutoPrintEnabled) return;

    let isAgentOnlineLocal = false;

    const checkAgent = async () => {
      try {
        const res = await fetch('http://localhost:17321/health', { 
          mode: 'cors',
          cache: 'no-cache'
        });
        if (res.ok) {
          if (!isAgentOnlineLocal) {
            isAgentOnlineLocal = true;
            setIsAgentOnline(true);
            console.log("Agente detectado! Processando fila...");
            processPendingJobs();
          }
        } else {
          isAgentOnlineLocal = false;
          setIsAgentOnline(false);
        }
      } catch (e) {
        isAgentOnlineLocal = false;
        setIsAgentOnline(false);
      }
    };

    const processPendingJobs = async () => {
      if (!isAgentOnlineLocal) return;
      const q = query(collection(db, 'printJobs'), where('status', '==', 'pending'));
      const snapshot = await getDocs(q);
      for (const document of snapshot.docs) {
        if (!processedJobs.current.has(document.id)) {
          // Verifica novamente o status no banco antes de processar para evitar duplicidade entre abas
          const freshDoc = await getDoc(document.ref);
          if (freshDoc.exists() && freshDoc.data().status === 'pending') {
            await printJob(document.id, document.data());
          }
        }
      }
    };

    const sendRawPrint = async (printerName: string, text: string) => {
      try {
        const controller = new AbortController();
        const timeoutId = setTimeout(() => controller.abort(), 10000); // 10s timeout

        const res = await fetch('http://localhost:17321/print', {
          method: 'POST',
          mode: 'cors',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ printerName, text }),
          signal: controller.signal
        });
        
        clearTimeout(timeoutId);

        if (!res.ok) {
          const errorData = await res.json().catch(() => ({ error: 'Erro desconhecido no agente' }));
          throw new Error(errorData.error || 'Erro na comunicação com o agente');
        }
      } catch (e: any) {
        if (e.name === 'AbortError') throw new Error('Tempo esgotado ao enviar para impressora');
        throw e;
      }
    };

    const printJob = async (jobId: string, job: any) => {
      // 1. Trava em memória imediata
      if (processedJobs.current.has(jobId)) return;
      processedJobs.current.add(jobId);

      try {
        // 2. Trava no banco de dados (Sincronização entre abas)
        const jobRef = doc(db, 'printJobs', jobId);
        await updateDoc(jobRef, { status: 'printing' });

        const docRef = doc(db, 'settings', 'printAgent');
        const docSnap = await getDoc(docRef);
        const config = docSnap.exists() ? docSnap.data().config : null;

        if (!config) throw new Error("Configuração de impressora não encontrada no sistema.");
        let hasPrintedSomething = false;

        // 0. Caso especial: Relatório de Fechamento ou Texto Direto
        if (job.tipo === 'fechamento' && job.text && config.caixa?.printer) {
          await sendRawPrint(config.caixa.printer, job.text);
          hasPrintedSomething = true;
        }

        // 1. Impressão de Cozinha (Itens de comida)

        const kitchenItems = (job.itens || []).filter((i: any) => ['kitchen', 'cozinha', 'food'].includes(i.setor));
        if (kitchenItems.length > 0 && config.cozinha?.printer) {
          const width = config.cozinha.largura === '58mm' ? 30 : 38;
          const kitchenContent = generate80mmLayout({...job, itens: kitchenItems}, BUSINESS_DISPLAY_NAME, "COMANDA - COZINHA", width);
          await sendRawPrint(config.cozinha.printer, kitchenContent);
          hasPrintedSomething = true;
        }

        // 2. Impressão de Bar (Itens de bebida)
        const barItems = (job.itens || []).filter((i: any) => ['bar', 'drink'].includes(i.setor));
        if (barItems.length > 0 && config.bar?.printer) {
          const width = config.bar.largura === '58mm' ? 30 : 38;
          const barContent = generate80mmLayout({...job, itens: barItems}, BUSINESS_DISPLAY_NAME, "COMANDA - BAR", width);
          await sendRawPrint(config.bar.printer, barContent);
          hasPrintedSomething = true;
        }

        // 3. Impressão do Caixa (Completa / Pre-conta / Venda)
        if ((job.imprimirCaixa || job.tipo === 'preconta' || job.tipo === 'venda_parcial') && config.caixa?.printer) {
          try {
            const width = config.caixa.largura === '58mm' ? 30 : 38;
            const rawContent = generate80mmLayout(job, BUSINESS_DISPLAY_NAME, undefined, width);
            await sendRawPrint(config.caixa.printer, rawContent);
            hasPrintedSomething = true;
          } catch (err: any) {
            console.error("Erro na impressora do caixa:", err);
            if (!hasPrintedSomething) throw err;
          }
        }

        if (!hasPrintedSomething) throw new Error('Nenhuma impressora configurada para este pedido.');

        // 3. Finalização
        await updateDoc(jobRef, { 
          status: 'completed', 
          printedAt: new Date().toISOString(),
          agentProcessed: true 
        });
        
        toast.success(`Impressão da Mesa ${job.mesa} enviada.`);
      } catch (e: any) {
        console.error(`Print fail:`, e);
        await updateDoc(doc(db, 'printJobs', jobId), { status: 'failed', error: e.message });
        
        // Remove da trava de memória após 5s para permitir re-tentativa manual se necessário
        setTimeout(() => {
          processedJobs.current.delete(jobId);
        }, 5000);
      }
    };

    const interval = setInterval(checkAgent, 5000);
    checkAgent();

    const q = query(collection(db, 'printJobs'), where('status', '==', 'pending'));
    const unsub = onSnapshot(q, (snapshot) => {
      if (isInitialLoad.current) {
        isInitialLoad.current = false;
        return;
      }
      snapshot.docChanges().forEach(async (change) => {
        if (change.type === 'added' && isAgentOnlineLocal) {
          await printJob(change.doc.id, change.doc.data());
        }
      });
    });

    return () => {
      clearInterval(interval);
      unsub();
    };
  }, [userData]);

  return null;
}
