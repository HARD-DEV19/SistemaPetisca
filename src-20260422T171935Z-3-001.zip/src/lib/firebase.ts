import { initializeApp } from 'firebase/app';
import { getAuth } from 'firebase/auth';
import { initializeFirestore, memoryLocalCache } from 'firebase/firestore';
import { getStorage } from 'firebase/storage';

const firebaseConfig = {
  projectId: "gen-lang-client-0575100100",
  appId: "1:255243577629:web:7478f3b7010ba22d9ad9f4",
  apiKey: "AIzaSyDi0kP-K3KdVWaoUF4l2omQLko9vbK8bvc",
  authDomain: "gen-lang-client-0575100100.firebaseapp.com",
  storageBucket: "gen-lang-client-0575100100.firebasestorage.app",
  messagingSenderId: "255243577629"
};

const app = initializeApp(firebaseConfig);
export const auth = getAuth(app);
export const storage = getStorage(app);

// FIX B815: Memory Cache for React 19 compatibility.
// Database: (default) as specified in GEMINI.md Module 3.
export const db = initializeFirestore(app, {
  localCache: memoryLocalCache()
});
