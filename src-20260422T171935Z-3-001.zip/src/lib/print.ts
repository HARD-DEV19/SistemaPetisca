export interface PrintRequest {
  pedidoId: string;
  itens: {
    nome: string;
    setor: string;
    quantidade: number;
    observacao?: string;
    preco: number;
  }[];
  imprimirCaixa: boolean;
  tipo: string;
  total: number;
  pagamento?: string;
  mesa: string;
}

/**
 * O agente local só aceita `{ printerName, text }` (ver `scripts/print-agent.js`).
 * A fila `printJobs` + `PrintJobListener` é quem monta ESC/POS e envia ao agente.
 * Aqui: se este dispositivo delega ao agente (auto-print + health OK), não abre o diálogo do navegador.
 */
export const printOrderWithFallback = async (_request: PrintRequest, htmlContent: string) => {
  const autoPrint = localStorage.getItem('enableAutoPrint') === 'true';
  if (autoPrint) {
    const controller = new AbortController();
    const timeoutId = setTimeout(() => controller.abort(), 2000);
    try {
      const res = await fetch('http://localhost:17321/health', { signal: controller.signal });
      clearTimeout(timeoutId);
      if (res.ok) return;
    } catch {
      clearTimeout(timeoutId);
      console.warn('Agente local offline; usando impressão do navegador.');
    }
  }
  printReceipt(htmlContent);
};

export const printReceipt = (content: string) => {
  const printerType = localStorage.getItem('printerType') || '80mm';
  
  let width = '100%';
  let fontSize = '18pt';
  let extraCss = '';
  
  if (printerType === '58mm') {
    fontSize = '14pt';
    extraCss = 'body { font-weight: bold; width: 100%; margin: 0; padding: 0; }';
  } else if (printerType === 'a4') {
    fontSize = '14pt';
    extraCss = 'body { max-width: 210mm; margin: 0 auto; padding: 20px; font-weight: normal; }';
  } else {
    // 80mm default
    fontSize = '18pt';
    extraCss = 'body { font-weight: bold; width: 100%; margin: 0; padding: 0; }';
  }

  const iframe = document.createElement('iframe');
  iframe.style.display = 'none';
  document.body.appendChild(iframe);
  
  const doc = iframe.contentWindow?.document;
  if (doc) {
    doc.open();
    doc.write(`
      <html>
        <head>
          <title>Imprimir Comanda</title>
          <style>
            @media print {
              @page { margin: 0; }
              body { margin: 0; padding: 2mm; }
            }
            body { 
              font-family: 'Courier New', Courier, monospace; 
              color: #000; 
              width: ${width};
              font-size: ${fontSize};
              line-height: 1.2;
              -webkit-print-color-adjust: exact;
            }
            ${extraCss}
            h1, h2, h3, p { margin: 0 0 2px 0; padding: 0; }
            .text-center { text-align: center; }
            .text-right { text-align: right; }
            .flex { display: flex; justify-content: space-between; align-items: flex-start; }
            .border-b { border-bottom: 2px dashed #000; margin-bottom: 6px; padding-bottom: 6px; }
            .border-t { border-top: 2px dashed #000; margin-top: 6px; padding-top: 6px; }
            .bold { font-weight: 900; }
            .text-lg { font-size: 1.3em; font-weight: 900; }
            .text-xl { font-size: 1.6em; font-weight: 900; }
            .mb-1 { margin-bottom: 4px; }
            .mb-2 { margin-bottom: 8px; }
            .w-full { width: 100%; }
            table { width: 100%; border-collapse: collapse; margin-bottom: 8px; }
            td { vertical-align: top; padding: 4px 0; font-weight: 700; }
            .qty { width: 35px; font-weight: 900; font-size: 1.1em; }
            .price { text-align: right; width: 85px; font-weight: 900; }
          </style>
        </head>
        <body>${content}</body>
      </html>
    `);
    doc.close();
    
    setTimeout(() => {
      iframe.contentWindow?.focus();
      iframe.contentWindow?.print();
      setTimeout(() => {
        document.body.removeChild(iframe);
      }, 1000);
    }, 250);
  }
};
