import { ref, uploadBytes, getDownloadURL, deleteObject } from 'firebase/storage';
import { storage } from './firebase';

const MAX_BYTES = 2 * 1024 * 1024;

function looksLikeImageFile(file: File): boolean {
  if (file.type.startsWith('image/')) return true;
  if (file.type !== '' && file.type !== 'application/octet-stream') return false;
  return /\.(jpe?g|png|gif|webp|bmp|heic|heif)$/i.test(file.name);
}

/** MIME para upload (alguns SOs deixam type vazio no input file). */
export function guessImageContentType(file: File): string {
  if (file.type.startsWith('image/')) return file.type;
  const n = file.name.toLowerCase();
  if (n.endsWith('.png')) return 'image/png';
  if (n.endsWith('.gif')) return 'image/gif';
  if (n.endsWith('.webp')) return 'image/webp';
  if (n.endsWith('.bmp')) return 'image/bmp';
  if (n.endsWith('.heic') || n.endsWith('.heif')) return 'image/heic';
  return 'image/jpeg';
}

export function validateImageFile(file: File): string | null {
  if (file.size > MAX_BYTES) {
    return 'Imagem muito grande. Máximo 2 MB.';
  }
  if (!looksLikeImageFile(file)) {
    return 'Selecione um arquivo de imagem (JPG, PNG, WebP, GIF, etc.).';
  }
  return null;
}

export async function uploadProductImage(productId: string, file: File): Promise<string> {
  const err = validateImageFile(file);
  if (err) throw new Error(err);
  const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, '_').slice(0, 80);
  const path = `product-images/${productId}/${Date.now()}_${safe}`;
  const r = ref(storage, path);
  const contentType = guessImageContentType(file);
  await uploadBytes(r, file, { contentType });
  return getDownloadURL(r);
}

function storageRefFromDownloadUrl(imageUrl: string) {
  const m = imageUrl.match(/\/o\/([^?]+)/);
  if (!m) return null;
  const path = decodeURIComponent(m[1].replace(/\+/g, '%20'));
  return ref(storage, path);
}

export async function deleteProductImageIfStored(imageUrl: string | undefined): Promise<void> {
  if (!imageUrl || !imageUrl.includes('firebasestorage')) return;
  try {
    const r = storageRefFromDownloadUrl(imageUrl);
    if (r) await deleteObject(r);
  } catch {
    // URL antiga, bucket diferente ou arquivo já removido
  }
}
