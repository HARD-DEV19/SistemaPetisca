/** Nome exibido em cupons térmicos e comprovantes HTML */
export const BUSINESS_DISPLAY_NAME = 'PetiscaPeixe';
