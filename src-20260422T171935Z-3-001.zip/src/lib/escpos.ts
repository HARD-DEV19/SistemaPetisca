/**
 * MOTOR DE LAYOUT GDI MULTI-FONT - PetiscaPeixe
 * Layout otimizado para 80mm (38 colunas) sem margens artificiais.
 */

function removeAccents(str: string) {
  return str.normalize("NFD").replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\x20-\x7E\n\r]/g, "?");
}

function sanitize(text: string) {
  return removeAccents(String(text ?? "")).trimEnd();
}

export const formatLine = (width: number, char: string = '-') => char.repeat(width);

export const formatTwoColumns = (width: number, left: string, right: string) => {
  const leftStr = String(left);
  const rightStr = String(right);
  const space = width - leftStr.length - rightStr.length;
  
  if (space <= 0) {
    return leftStr.substring(0, Math.max(0, width - rightStr.length - 1)) + " " + rightStr;
  }
  return leftStr + ' '.repeat(space) + rightStr;
};

export const generate80mmLayout = (job: any, businessName: string, forcedTitle?: string, printerWidth: number = 38) => {
  // Ajuste equilibrado: 36 colunas para 80mm evita corte físico na direita em drivers GDI
  const widthNormal = printerWidth === 38 ? 36 : printerWidth;
  const widthBig = Math.floor(widthNormal * 0.55); 
  
  const lines: string[] = [];
  const isReceipt = job.tipo === 'preconta' || job.tipo === 'venda_parcial' || !forcedTitle;

  const empresa = String(businessName || "PETISCAPEIXE").toUpperCase();
  const defaultTitle = job.tipo === "preconta" ? "CONFERENCIA DE MESA" : 
                 job.tipo === "comanda" ? "COMANDA DE PEDIDO" : "CUPOM DE VENDA";
  
  const titulo = forcedTitle || defaultTitle;

  lines.push("");
  lines.push(" ".repeat(Math.max(0, Math.floor((widthNormal - empresa.length) / 2))) + empresa);
  lines.push(formatLine(widthNormal, "="));
  lines.push(" ".repeat(Math.max(0, Math.floor((widthNormal - titulo.length) / 2))) + titulo);
  lines.push(formatLine(widthNormal, "="));
  
  lines.push(`MESA: ${job.mesa || "-"}`);
  lines.push(`PEDIDO: #${job.pedidoId || "-"}`);
  if (job.waiterName) {
    lines.push(`GARCOM: ${String(job.waiterName).split(' ')[0].toUpperCase()}`);
  }
  lines.push(`DATA: ${new Date().toLocaleString("pt-BR")}`);
  lines.push(formatLine(widthNormal, "-"));

  if (isReceipt) {
    lines.push("QTD  ITEM".padEnd(widthNormal - 11) + "TOTAL".padStart(11));
    lines.push(formatLine(widthNormal, "-"));
  }

  let subtotalCalculado = 0;
  if (Array.isArray(job.itens)) {
    job.itens.forEach((item: any) => {
      const nome = String(item.nome || "ITEM").toUpperCase().trim();
      const qtd = Number(item.quantity || item.quantidade || 1);
      const priceVal = Number(item.price || item.preco || 0);
      const totalItem = qtd * priceVal;
      subtotalCalculado += totalItem;

      const qtyPart = `${qtd}x `;

      if (isReceipt) {
        const pricePart = `R$ ${totalItem.toFixed(2)}`.padStart(11);
        const nameLimit = widthNormal - qtyPart.length - pricePart.length - 1;
        
        if (nome.length <= nameLimit) {
          lines.push(qtyPart + nome.padEnd(nameLimit) + pricePart);
        } else {
          const firstPart = nome.substring(0, nameLimit);
          lines.push(qtyPart + firstPart.padEnd(nameLimit) + pricePart);
          
          let remaining = nome.substring(nameLimit);
          const subLimit = widthNormal - qtyPart.length;
          while (remaining.length > 0) {
            const part = remaining.substring(0, subLimit);
            lines.push(" ".repeat(qtyPart.length) + part);
            remaining = remaining.substring(subLimit);
          }
        }
      } else {
        const fullName = `${qtyPart}${nome}`;
        if (fullName.length <= widthBig) {
          lines.push(`[BIG]${fullName}`);
        } else {
          lines.push(`[BIG]${fullName.substring(0, widthBig)}`);
          let remaining = fullName.substring(widthBig);
          while (remaining.length > 0) {
            lines.push(`[BIG]${" ".repeat(qtyPart.length)}${remaining.substring(0, widthBig - qtyPart.length)}`);
            remaining = remaining.substring(widthBig - qtyPart.length);
          }
        }
      }

      if (item.observacao) {
        lines.push(`  (!) OBS: ${item.observacao.toUpperCase()}`);
      }
    });
  }

  lines.push(formatLine(widthNormal, "-"));

  if (isReceipt) {
    const subtotal = (Number(job.subtotal) > 0) ? Number(job.subtotal) : 
                     (Number(job.total) > 0) ? Number(job.total) : subtotalCalculado;
    
    const taxa = (job.taxa !== undefined) ? Number(job.taxa) : subtotal * 0.1;
    const totalGeral = subtotal + taxa;

    lines.push(formatTwoColumns(widthNormal, "SUBTOTAL:", `R$ ${subtotal.toFixed(2)}`));
    lines.push(formatTwoColumns(widthNormal, "TAXA SERVICO:", `R$ ${taxa.toFixed(2)}`));
    lines.push(formatLine(widthNormal, "="));
    lines.push(formatTwoColumns(widthNormal, "TOTAL:", `R$ ${totalGeral.toFixed(2)}`));
    
    if (job.pagamento) {
      lines.push("");
      lines.push(`FORMA PAGTO: ${job.pagamento.toUpperCase()}`);
    }

    lines.push("");
    const footerMsg = "OBRIGADO PELA PREFERENCIA!";
    lines.push(" ".repeat(Math.max(0, Math.floor((widthNormal - footerMsg.length) / 2))) + footerMsg);
  }

  lines.push("\n\n\n\n\n\n\n\n"); 
  return sanitize(lines.join("\n"));
};
