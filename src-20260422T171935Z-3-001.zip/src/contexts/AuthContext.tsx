import React, { createContext, useContext, useEffect, useState } from 'react';
import { auth, db } from '../lib/firebase';
import { onAuthStateChanged, signInWithPopup, GoogleAuthProvider, signOut, User as FirebaseUser, signInAnonymously } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, where, getDocs, deleteDoc } from 'firebase/firestore';
import { toast } from 'sonner';
import { isAdminBootstrapEmail } from '../config/adminBootstrap';

export type Role = 'admin' | 'manager' | 'waiter' | 'kitchen' | 'bar' | 'cashier';

export interface UserData {
  uid: string;
  name: string;
  email: string;
  role: Role;
  pin?: string;
  createdAt: string;
}

interface AuthContextType {
  user: FirebaseUser | null;
  userData: UserData | null;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);
export const WAITER_SESSION_KEY = 'waiter_session_v3';

function readWaiterSession(): any | null {
  if (typeof window === 'undefined') return null;
  try {
    const raw = localStorage.getItem(WAITER_SESSION_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch {
    return null;
  }
}

export function AuthProvider({ children }: { children: React.ReactNode }) {
  const [user, setUser] = useState<FirebaseUser | null>(null);
  const [userData, setUserData] = useState<UserData | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      // 1. Check for Waiter Session first (Sovereign)
      const waiterSession = readWaiterSession();
      
      if (waiterSession) {
        setUser(firebaseUser);
        setUserData({
          uid: waiterSession.uid,
          name: waiterSession.name,
          role: 'waiter',
          email: '',
          createdAt: waiterSession.createdAt
        });
        
        // If there's a session but Firebase is logged out, sign in anonymously silently
        if (!firebaseUser) {
          try { await signInAnonymously(auth); } catch (e) { console.error(e); }
        }
        
        setLoading(false);
        return;
      }

      if (!firebaseUser) {
        setUser(null);
        setUserData(null);
        setLoading(false);
        return;
      }

      setUser(firebaseUser);

      // SuperAdmin Bypass
      if (firebaseUser.email && (firebaseUser.email === 'harddisk1911@gmail.com' || firebaseUser.email === 'pedrohardsolu2025@gmail.com' || firebaseUser.email === 'bsr.salvador2022@gmail.com')) {
        setUserData({
          uid: firebaseUser.uid,
          name: 'Super Admin',
          role: 'admin',
          email: firebaseUser.email,
          createdAt: new Date().toISOString()
        });
        setLoading(false);
        return;
      }

      try {
        const isAdminEmail = isAdminBootstrapEmail(firebaseUser.email);
        const userDoc = await getDoc(doc(db, 'users', firebaseUser.uid));
        
        if (userDoc.exists()) {
          setUserData(userDoc.data() as UserData);
        } else if (firebaseUser.email) {
          const q = query(collection(db, 'users'), where('email', '==', firebaseUser.email));
          const querySnapshot = await getDocs(q);
          
          if (!querySnapshot.empty) {
            const pendingDoc = querySnapshot.docs[0];
            const pendingData = pendingDoc.data();
            const newUserData: UserData = {
              uid: firebaseUser.uid,
              name: firebaseUser.displayName || 'User',
              email: firebaseUser.email,
              role: isAdminEmail ? 'admin' : pendingData.role,
              createdAt: new Date().toISOString(),
            };
            await setDoc(doc(db, 'users', firebaseUser.uid), newUserData);
            await deleteDoc(doc(db, 'users', pendingDoc.id));
            setUserData(newUserData);
          } else if (isAdminEmail) {
            const newUserData: UserData = {
              uid: firebaseUser.uid,
              name: firebaseUser.displayName || 'Admin',
              email: firebaseUser.email,
              role: 'admin',
              createdAt: new Date().toISOString(),
            };
            await setDoc(doc(db, 'users', firebaseUser.uid), newUserData);
            setUserData(newUserData);
          }
        }
      } catch (error) {
        console.error("Auth error:", error);
      } finally {
        setLoading(false);
      }
    });

    return () => unsubscribe();
  }, []);

  const loginWithGoogle = async () => {
    try {
      const provider = new GoogleAuthProvider();
      await signInWithPopup(auth, provider);
    } catch (error: any) {
      if (error.code !== 'auth/popup-closed-by-user') {
        toast.error(`Erro: ${error.message}`);
      }
    }
  };

  const logout = async () => {
    localStorage.removeItem(WAITER_SESSION_KEY);
    await signOut(auth);
    window.location.href = '/login';
  };

  return (
    <AuthContext.Provider value={{ user, userData, loading, loginWithGoogle, logout }}>
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth() {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
}
